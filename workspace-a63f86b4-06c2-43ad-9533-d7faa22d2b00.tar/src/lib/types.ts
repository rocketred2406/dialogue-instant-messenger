export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  status: 'online' | 'offline' | 'idle';
  friends: string[];
  serverIds: string[];
  createdAt: number;
  isAdmin: boolean;
  gradient?: string; // CSS gradient for Dialogue Plus usernames
  gradientColors?: string[]; // Array of hex colors for custom gradient
  bio?: string; // User bio for profile page
  memberRoleIds?: Record<string, string[]>; // serverId -> roleIds
  dialoguePlus?: boolean; // User-level Dialogue Plus
  profileBackground?: string; // Profile background URL for Plus users
  lastActivity?: number; // Timestamp of last activity
  timeoutUntil?: number; // Timestamp when timeout expires (0 = not timed out)
  timeoutReason?: string; // Reason for timeout
}

export interface Category {
  id: string;
  name: string;
  serverId: string;
  order: number;
}

export interface Server {
  id: string;
  name: string;
  icon: string;
  ownerId: string;
  roles: Role[];
  channels: Channel[];
  members: string[];
  maxMembers: number;
  isPublic: boolean;
  createdAt: number;
  dialogueBoost: boolean; // RENAMED from dialoguePlus (server tier)
  customEmojis: CustomEmoji[];
  discoverImage?: string; // Custom discover page image for Boost servers
  messageCooldown?: number; // Message cooldown in ms, default 1000
  bio?: string; // Server bio for discover page
  categories?: Category[]; // Custom channel categories
}

export interface Role {
  id: string;
  name: string;
  color: string;
  permissions: string[];
}

export interface Channel {
  id: string;
  name: string;
  type: 'text' | 'announcement' | 'forum' | 'rules';
  iconType?: 'default' | 'announcement' | 'forum' | 'rules'; // Custom icon type
  serverId: string;
  createdAt: number;
  permissions?: ChannelPermissions; // Per-channel permission overrides
  order?: number; // Sort order for drag-and-drop reordering
  categoryId?: string; // Category this channel belongs to
}

export interface ChannelPermissions {
  [roleId: string]: string[]; // roleId -> allowed permissions
  _default?: string[]; // Default permissions for members without a role
}

export interface Message {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderGradient?: string;
  channelId: string;
  serverId: string;
  type: 'text' | 'image' | 'video' | 'system';
  mediaUrl: string;
  createdAt: number;
  replyTo?: ReplyReference;
  editedAt?: number;
  pinned?: boolean;
  reactions?: Record<string, string[]>; // emoji -> userId[]
}

export interface DMMessage {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderGradient?: string;
  conversationId: string;
  type: 'text' | 'image' | 'video';
  mediaUrl: string;
  createdAt: number;
  replyTo?: ReplyReference;
  editedAt?: number;
  reactions?: Record<string, string[]>; // emoji -> userId[]
}

export interface ReplyReference {
  messageId: string;
  senderId: string;
  senderName: string;
  content: string;
}

export interface CustomEmoji {
  id: string;
  name: string;
  imageUrl: string;
  createdBy: string;
  createdAt: number;
}

export interface FriendRequest {
  id: string;
  fromId: string;
  fromName: string;
  toId: string;
  toName: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: number;
}

export interface Notification {
  id: string;
  userId: string;
  targetId: string; // serverId or dmConversationId
  type: 'server' | 'dm';
  count: number;
  updatedAt: number;
}

export interface DMConversation {
  id: string;
  participants: string[];
  createdAt: number;
}

export type ViewMode = 'server' | 'dm' | 'discover' | 'friends';

export interface AppState {
  currentView: ViewMode;
  currentServerId: string | null;
  currentChannelId: string | null;
  currentDMConversationId: string | null;
  showServerSettings: boolean;
  showCreateServer: boolean;
  showMediaViewer: boolean;
  mediaViewerUrl: string;
  mediaViewerType: 'image' | 'video';
  showUserSettings: boolean;
  replyingTo: ReplyReference | null;
  editingMessageId: string | null;
  editingMessageContent: string;
  showProfileUserId: string | null;
  showAdminPanel: boolean;
}

export const ALL_PERMISSIONS = [
  'send_messages',
  'read_messages',
  'manage_channels',
  'move_channels',
  'manage_roles',
  'kick_members',
  'ban_members',
  'manage_server',
  'edit_messages',
  'delete_messages',
  'manage_emojis',
  'mention_everyone',
  'pin_messages',
] as const;

export type Permission = typeof ALL_PERMISSIONS[number];

/**
 * Check if a user has a specific permission in a server context.
 * Uses the user's assigned roles (via memberRoleIds) instead of ALL roles on the server.
 * Falls back to channel-level _default permissions for users without a specific role override.
 */
export function hasPermission(
  server: Server | null,
  user: {id: string; isAdmin: boolean; memberRoleIds?: Record<string, string[]>} | null,
  permission: string,
  channel?: Channel | null
): boolean {
  if (!server || !user) return false;
  if (user.isAdmin) return true;
  if (server.ownerId === user.id) return true;

  // Get user's role IDs for this server
  const userRoleIds = user.memberRoleIds?.[server.id] || [];

  // Check channel-level permissions first (overrides)
  if (channel?.permissions) {
    // Check role-specific channel permissions
    for (const roleId of userRoleIds) {
      const channelPerms = channel.permissions[roleId];
      if (channelPerms && channelPerms.includes(permission)) {
        return true;
      }
    }
    // Check _default channel permissions for users without a specific role override
    const hasChannelOverride = userRoleIds.some(rid => channel.permissions![rid] !== undefined);
    if (!hasChannelOverride && channel.permissions._default) {
      if (channel.permissions._default.includes(permission)) return true;
    }
    // If user has role overrides but none match, deny (don't fall through to server-level)
    if (hasChannelOverride) return false;
  }

  // Check server-level role permissions
  for (const role of server.roles || []) {
    if (userRoleIds.includes(role.id) && role.permissions.includes(permission)) {
      return true;
    }
  }

  // Fall back to channel _default if no roles assigned
  if (userRoleIds.length === 0 && channel?.permissions?._default) {
    if (channel.permissions._default.includes(permission)) return true;
  }

  return false;
}

export const GRADIENT_PRESETS = [
  { name: 'Sunset', colors: ['#FF6B6B', '#FF8E53'], gradient: 'linear-gradient(135deg, #FF6B6B, #FF8E53)' },
  { name: 'Ocean', colors: ['#4ECDC4', '#556270'], gradient: 'linear-gradient(135deg, #4ECDC4, #556270)' },
  { name: 'Royal', colors: ['#C33764', '#1D2671'], gradient: 'linear-gradient(135deg, #C33764, #1D2671)' },
  { name: 'Cyan', colors: ['#00B4DB', '#0083B0'], gradient: 'linear-gradient(135deg, #00B4DB, #0083B0)' },
  { name: 'Gold', colors: ['#F7971E', '#FFD200'], gradient: 'linear-gradient(135deg, #F7971E, #FFD200)' },
  { name: 'Purple', colors: ['#8E2DE2', '#4A00E0'], gradient: 'linear-gradient(135deg, #8E2DE2, #4A00E0)' },
  { name: 'Mint', colors: ['#11998E', '#38EF7D'], gradient: 'linear-gradient(135deg, #11998E, #38EF7D)' },
  { name: 'Fire', colors: ['#EE0979', '#FF6A00'], gradient: 'linear-gradient(135deg, #EE0979, #FF6A00)' },
  { name: 'Violet', colors: ['#7F00FF', '#E100FF'], gradient: 'linear-gradient(135deg, #7F00FF, #E100FF)' },
  { name: 'Berry', colors: ['#FC466B', '#3F5EFB'], gradient: 'linear-gradient(135deg, #FC466B, #3F5EFB)' },
  { name: 'Steel', colors: ['#3498DB', '#2C3E50'], gradient: 'linear-gradient(135deg, #3498DB, #2C3E50)' },
  { name: 'Rose', colors: ['#F953C6', '#B91D73'], gradient: 'linear-gradient(135deg, #F953C6, #B91D73)' },
  { name: 'Neon', colors: ['#00FF87', '#60EFFF'], gradient: 'linear-gradient(135deg, #00FF87, #60EFFF)' },
  { name: 'Aurora', colors: ['#667EEA', '#764BA2'], gradient: 'linear-gradient(135deg, #667EEA, #764BA2)' },
  { name: 'Candy', colors: ['#FF758C', '#FF7EB3'], gradient: 'linear-gradient(135deg, #FF758C, #FF7EB3)' },
  { name: 'Midnight', colors: ['#232526', '#414345'], gradient: 'linear-gradient(135deg, #232526, #414345)' },
];

// Standard emoji list for reactions
export const EMOJI_CATEGORIES: { name: string; emojis: string[] }[] = [
  {
    name: 'Smileys',
    emojis: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🫣','🫢','🤐','🫡','🤨','😐','😑','😶','🫥','😏','😒','🙄','😬','😮‍💨','🤥','🫨','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','🫤','😟','🙁','☹️','😮','😯','😲','😳','🥺','🥹','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖'],
  },
  {
    name: 'Gestures',
    emojis: ['👋','🤚','🖐','✋','🖖','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','🫵','👍','👎','✊','👊','🤛','🤜','👏','🙌','🫶','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁','👅','👄','🫦','💋','🩸'],
  },
  {
    name: 'Hearts',
    emojis: ['❤️','🧡','💛','💚','💙','💜','🤎','🖤','🤍','💔','❤️‍🔥','❤️‍🩹','❣️','💕','💞','💓','💗','💖','💘','💝','💟','♥️'],
  },
  {
    name: 'Objects',
    emojis: ['⭐','🌟','✨','💫','🔥','💥','💢','💦','💨','🌈','☀️','🌤','⛅','🌥','☁️','🌦','🌧','⛈','🌩','🌨','❄️','☃️','⛄','🌬','💨','💧','☔','☂️','🌊','🎉','🎊','🎈','🎁','🎀','🎗','🏅','🎖','🏆','🥇','🥈','🥉','⚽','⚾','🥎','🏀','🏐','🏈','🏉','🎾','🥏','🎳','🏏','🏑','🏒','🥍','🏓','🏸','🥊','🥋','🥅','⛳','⛸','🎣','🤿','🎽','🎿','🛷','🥌','🎯','🪀','🪁','🎱','🔮','🪄','🎮','🕹','🎰','🎲','🧩','🧸','🪅','🪩','🪆','♠️','♥️','♦️','♣️','♟','🃏','🀄','🎴','🎭','🖼','🎨','🧵','🪡','🧶','🪢'],
  },
];
