import { initializeApp, getApps } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyDgZkxAbISow3x0kvJ7eRFy5jWvgmwWzB0",
  authDomain: "jackson-box-fbd43.firebaseapp.com",
  databaseURL: "https://jackson-box-fbd43-default-rtdb.firebaseio.com",
  projectId: "jackson-box-fbd43",
  storageBucket: "jackson-box-fbd43.firebasestorage.app",
  messagingSenderId: "708310235954",
  appId: "1:708310235954:web:bc3bff9daf65eca021f52b",
  measurementId: "G-V77SZBY6ZD"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
export const db = getFirestore(app);
export default app;
