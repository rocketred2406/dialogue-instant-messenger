'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  query,
  where,
  updateDoc,
  arrayUnion,
  addDoc,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { User } from '@/lib/types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  firebaseReady: boolean;
  firebaseError: string;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (username: string, password: string, displayName: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => Promise<void>;
  changePassword: (oldPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  allUsers: User[];
  getUserById: (id: string) => User | undefined;
}

const AuthContext = createContext<AuthContextType | null>(null);

const MAX_USERS = 20;
const ADMIN_USERNAME = 'Little_Timmy';

function getFirebaseErrorMessage(err: unknown): string {
  if (err && typeof err === 'object' && 'code' in err) {
    const code = (err as { code: string }).code;
    if (code === 'permission-denied') {
      return 'Firebase permission denied. Your Firestore security rules are blocking writes. Please update your Firestore rules to allow read/write access.';
    }
    if (code === 'unavailable') {
      return 'Firebase service is unavailable. Please check your internet connection.';
    }
    if (code === 'not-found') {
      return 'Firebase database not found. Please create a Firestore database in your Firebase Console first.';
    }
    if (code === 'unauthenticated') {
      return 'Firebase requires authentication. Please update your Firestore rules to allow unauthenticated access.';
    }
  }
  if (err instanceof Error && err.message.includes('timed out')) {
    return 'Connection timed out. Please make sure Firebase Firestore is created in your Firebase Console and your security rules allow access.';
  }
  return 'An unexpected error occurred. Please try again.';
}

function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Operation timed out. Firebase may not be configured yet.')), ms)
    ),
  ]);
}

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + 'dialogue_salt_2024');
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function getStoredUser(): User | null {
  if (typeof window === 'undefined') return null;
  const storedUser = localStorage.getItem('dialogue_user');
  if (storedUser) {
    try {
      return JSON.parse(storedUser);
    } catch {
      localStorage.removeItem('dialogue_user');
    }
  }
  return null;
}

async function ensureDialogueIMServer(userId: string) {
  try {
    const q = query(collection(db, 'servers'), where('name', '==', 'Dialogue IM'));
    const snapshot = await withTimeout(getDocs(q), 8000);

    let serverId: string;

    if (snapshot.empty) {
      const docRef = await addDoc(collection(db, 'servers'), {
        name: 'Dialogue IM',
        icon: '',
        ownerId: 'system',
        roles: [
          { id: 'role_admin', name: 'Admin', color: '#ED4245', permissions: ['send_messages', 'read_messages', 'manage_channels', 'move_channels', 'manage_roles', 'kick_members', 'ban_members', 'manage_server', 'edit_messages', 'delete_messages', 'manage_emojis', 'mention_everyone', 'pin_messages'] },
          { id: 'role_member', name: 'Member', color: '#5865F2', permissions: ['send_messages', 'read_messages'] },
        ],
        members: [userId],
        maxMembers: 1000,
        isPublic: true,
        createdAt: Date.now(),
        dialogueBoost: true, // RENAMED from dialoguePlus
        customEmojis: [],
        messageCooldown: 1000,
        categories: [],
      });
      serverId = docRef.id;

      await addDoc(collection(db, 'channels'), {
        name: 'general',
        type: 'text',
        serverId: serverId,
        createdAt: Date.now(),
        permissions: { _default: ['send_messages', 'read_messages'] },
        order: 0,
      });
    } else {
      serverId = snapshot.docs[0].id;
      const serverData = snapshot.docs[0].data();
      if (!serverData.members?.includes(userId)) {
        await updateDoc(doc(db, 'servers', serverId), {
          members: arrayUnion(userId),
        });
      }
      // Ensure the server has dialogueBoost field set (migration from old dialoguePlus)
      if (serverData.dialogueBoost === undefined && serverData.dialoguePlus !== undefined) {
        await updateDoc(doc(db, 'servers', serverId), {
          dialogueBoost: serverData.dialoguePlus,
        });
      } else if (serverData.dialogueBoost === undefined) {
        await updateDoc(doc(db, 'servers', serverId), {
          dialogueBoost: true,
        });
      }
    }

    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      const currentServerIds = userDoc.data().serverIds || [];
      if (!currentServerIds.includes(serverId)) {
        await updateDoc(doc(db, 'users', userId), {
          serverIds: arrayUnion(serverId),
        });
      }
    }

    return serverId;
  } catch (err) {
    console.error('Failed to ensure Dialogue IM server:', err);
    return null;
  }
}

// Update all messages sent by a user when their profile changes
// Process in chunks of 500 (Firestore batch limit)
async function updateUserMessages(userId: string, updates: { senderName?: string; senderAvatar?: string; senderGradient?: string }) {
  try {
    const updateData: Record<string, string> = {};
    if (updates.senderName !== undefined) updateData.senderName = updates.senderName;
    if (updates.senderAvatar !== undefined) updateData.senderAvatar = updates.senderAvatar;
    if (updates.senderGradient !== undefined) updateData.senderGradient = updates.senderGradient;

    if (Object.keys(updateData).length === 0) return;

    // Update server messages
    try {
      const messagesQuery = query(collection(db, 'messages'), where('senderId', '==', userId));
      const messagesSnapshot = await getDocs(messagesQuery);
      const BATCH_SIZE = 500;
      const docs = messagesSnapshot.docs;
      for (let i = 0; i < docs.length; i += BATCH_SIZE) {
        const batch = writeBatch(db);
        const chunk = docs.slice(i, i + BATCH_SIZE);
        chunk.forEach((d) => {
          batch.update(d.ref, updateData);
        });
        await batch.commit();
      }
    } catch (err) {
      console.error('Failed to update server messages (may need Firestore index):', err);
    }

    // Update DM messages
    try {
      const dmQuery = query(collection(db, 'dmMessages'), where('senderId', '==', userId));
      const dmSnapshot = await getDocs(dmQuery);
      const BATCH_SIZE = 500;
      const docs = dmSnapshot.docs;
      for (let i = 0; i < docs.length; i += BATCH_SIZE) {
        const batch = writeBatch(db);
        const chunk = docs.slice(i, i + BATCH_SIZE);
        chunk.forEach((d) => {
          batch.update(d.ref, updateData);
        });
        await batch.commit();
      }
    } catch (err) {
      console.error('Failed to update DM messages (may need Firestore index):', err);
    }
  } catch (err) {
    console.error('Failed to update user messages:', err);
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(getStoredUser);
  const [loading] = useState(false);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [firebaseReady, setFirebaseReady] = useState(true);
  const [firebaseError, setFirebaseError] = useState('');
  const lastActivityRef = useRef<number>(Date.now());
  const activityTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const fetchAllUsers = async () => {
      try {
        const usersSnapshot = await withTimeout(getDocs(collection(db, 'users')), 8000);
        const users: User[] = [];
        usersSnapshot.forEach((d) => {
          users.push({ id: d.id, ...d.data() } as User);
        });
        setAllUsers(users);
        setFirebaseReady(true);
        setFirebaseError('');
      } catch (err) {
        console.error('Failed to fetch users:', err);
        setFirebaseReady(false);
        setFirebaseError(getFirebaseErrorMessage(err));
      }
    };
    fetchAllUsers();
    const interval = setInterval(fetchAllUsers, 30000);
    return () => clearInterval(interval);
  }, []);

  // Real-time listener for all users
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
      const users: User[] = [];
      snapshot.forEach((d) => {
        users.push({ id: d.id, ...d.data() } as User);
      });
      setAllUsers(users);
    }, () => {
      // ignore errors - fallback to polling
    });
    return () => unsub();
  }, []);

  // Activity tracking for online/idle/offline status
  useEffect(() => {
    if (!user) return;

    const updateActivity = () => {
      lastActivityRef.current = Date.now();
    };

    // Track user activity
    const events = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'] as const;
    events.forEach(event => {
      window.addEventListener(event, updateActivity, { passive: true });
    });

    // Update status in Firestore every 30 seconds
    const updateStatus = async () => {
      if (!user) return;
      const now = Date.now();
      const timeSinceActivity = now - lastActivityRef.current;
      let newStatus: 'online' | 'idle' | 'offline';

      if (timeSinceActivity < 2 * 60 * 1000) {
        // Active within last 2 minutes
        newStatus = 'online';
      } else if (timeSinceActivity < 10 * 60 * 1000) {
        // Idle for 2-10 minutes
        newStatus = 'idle';
      } else {
        // Idle for more than 10 minutes
        newStatus = 'offline';
      }

      try {
        await updateDoc(doc(db, 'users', user.id), {
          status: newStatus,
          lastActivity: lastActivityRef.current,
        });
      } catch {
        // Non-critical
      }
    };

    activityTimerRef.current = setInterval(updateStatus, 30000);
    // Set initial online status
    updateStatus();

    // Set offline on page unload
    const handleUnload = () => {
      if (user) {
        // Use sendBeacon for reliability on page unload
        navigator.sendBeacon?.(`/api/offline?userId=${user.id}`);
        // Also try direct Firestore update
        try {
          updateDoc(doc(db, 'users', user.id), { status: 'offline' });
        } catch {
          // Best effort
        }
      }
    };
    window.addEventListener('beforeunload', handleUnload);

    return () => {
      events.forEach(event => {
        window.removeEventListener(event, updateActivity);
      });
      window.removeEventListener('beforeunload', handleUnload);
      if (activityTimerRef.current) {
        clearInterval(activityTimerRef.current);
      }
    };
  }, [user]);

  const getUserById = useCallback((id: string) => {
    return allUsers.find(u => u.id === id);
  }, [allUsers]);

  const login = useCallback(async (username: string, password: string) => {
    try {
      const hashedPassword = await hashPassword(password);
      const q = query(collection(db, 'users'), where('username', '==', username));
      const snapshot = await withTimeout(getDocs(q), 10000);

      if (snapshot.empty) {
        return { success: false, error: 'User not found' };
      }

      const userDoc = snapshot.docs[0];
      const userData = userDoc.data();

      if (userData.password !== hashedPassword) {
        return { success: false, error: 'Invalid password' };
      }

      const loggedInUser: User = {
        id: userDoc.id,
        username: userData.username,
        displayName: userData.displayName,
        avatar: userData.avatar || '',
        status: 'online',
        friends: userData.friends || [],
        serverIds: userData.serverIds || [],
        createdAt: userData.createdAt,
        isAdmin: userData.isAdmin || false,
        gradient: userData.gradient || '',
        gradientColors: userData.gradientColors || [],
        bio: userData.bio || '',
        memberRoleIds: userData.memberRoleIds || {},
        dialoguePlus: userData.dialoguePlus || false,
        profileBackground: userData.profileBackground || '',
        lastActivity: Date.now(),
        timeoutUntil: userData.timeoutUntil || 0,
        timeoutReason: userData.timeoutReason || '',
      };

      try {
        await withTimeout(updateDoc(doc(db, 'users', userDoc.id), { status: 'online', lastActivity: Date.now() }), 5000);
      } catch {
        // Non-critical
      }

      const dialogueServerId = await ensureDialogueIMServer(loggedInUser.id);
      const refreshedDoc = await getDoc(doc(db, 'users', userDoc.id));
      if (refreshedDoc.exists()) {
        loggedInUser.serverIds = refreshedDoc.data().serverIds || loggedInUser.serverIds;
      }

      setUser(loggedInUser);
      lastActivityRef.current = Date.now();
      localStorage.setItem('dialogue_user', JSON.stringify(loggedInUser));

      // Navigate to Dialogue IM server after login
      if (dialogueServerId) {
        // We'll use a custom event to notify AppContext
        window.dispatchEvent(new CustomEvent('dialogue-login-navigate', { detail: { serverId: dialogueServerId } }));
      }

      return { success: true };
    } catch (err) {
      console.error('Login error:', err);
      return { success: false, error: getFirebaseErrorMessage(err) };
    }
  }, []);

  const register = useCallback(async (username: string, password: string, displayName: string) => {
    try {
      const usersSnapshot = await withTimeout(getDocs(collection(db, 'users')), 10000);
      if (usersSnapshot.size >= MAX_USERS) {
        return { success: false, error: `Maximum number of accounts (${MAX_USERS}) reached.` };
      }

      const q = query(collection(db, 'users'), where('username', '==', username));
      const existingSnapshot = await withTimeout(getDocs(q), 10000);
      if (!existingSnapshot.empty) {
        return { success: false, error: 'Username already taken' };
      }

      const hashedPassword = await hashPassword(password);
      const userId = doc(collection(db, 'users')).id;
      const isAdmin = username === ADMIN_USERNAME;

      const newUser: User = {
        id: userId,
        username,
        displayName,
        avatar: '',
        status: 'online',
        friends: [],
        serverIds: [],
        createdAt: Date.now(),
        isAdmin,
        gradient: '',
        gradientColors: [],
        bio: '',
        memberRoleIds: {},
        dialoguePlus: false,
        profileBackground: '',
        lastActivity: Date.now(),
        timeoutUntil: 0,
        timeoutReason: '',
      };

      await withTimeout(setDoc(doc(db, 'users', userId), {
        ...newUser,
        password: hashedPassword,
      }), 10000);

      const dialogueServerId = await ensureDialogueIMServer(userId);
      if (dialogueServerId) {
        newUser.serverIds = [dialogueServerId];
      }

      setUser(newUser);
      lastActivityRef.current = Date.now();
      localStorage.setItem('dialogue_user', JSON.stringify(newUser));

      // Navigate to Dialogue IM server after registration
      if (dialogueServerId) {
        window.dispatchEvent(new CustomEvent('dialogue-login-navigate', { detail: { serverId: dialogueServerId } }));
      }

      return { success: true };
    } catch (err) {
      console.error('Register error:', err);
      return { success: false, error: getFirebaseErrorMessage(err) };
    }
  }, []);

  const logout = useCallback(async () => {
    if (user) {
      try {
        await updateDoc(doc(db, 'users', user.id), { status: 'offline' });
      } catch (err) {
        console.error('Logout status update failed:', err);
      }
    }
    setUser(null);
    localStorage.removeItem('dialogue_user');
  }, [user]);

  const updateUser = useCallback(async (updates: Partial<User>) => {
    if (!user) return;
    try {
      await setDoc(doc(db, 'users', user.id), updates, { merge: true });
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('dialogue_user', JSON.stringify(updatedUser));

      // Update all messages sent by this user
      const messageUpdates: { senderName?: string; senderAvatar?: string; senderGradient?: string } = {};
      if (updates.displayName !== undefined) messageUpdates.senderName = updates.displayName;
      if (updates.avatar !== undefined) messageUpdates.senderAvatar = updates.avatar;
      if (updates.gradient !== undefined) messageUpdates.senderGradient = updates.gradient;

      if (Object.keys(messageUpdates).length > 0) {
        // Run in background - don't block the UI
        updateUserMessages(user.id, messageUpdates);
      }
    } catch (err) {
      console.error('Update user failed:', err);
    }
  }, [user]);

  const changePassword = useCallback(async (oldPassword: string, newPassword: string) => {
    if (!user) return { success: false, error: 'Not logged in' };

    try {
      const userDoc = await getDoc(doc(db, 'users', user.id));
      if (!userDoc.exists()) return { success: false, error: 'User not found' };

      const oldHashed = await hashPassword(oldPassword);
      if (userDoc.data().password !== oldHashed) {
        return { success: false, error: 'Current password is incorrect' };
      }

      const newHashed = await hashPassword(newPassword);
      await updateDoc(doc(db, 'users', user.id), { password: newHashed });
      return { success: true };
    } catch (err) {
      console.error('Change password failed:', err);
      return { success: false, error: 'Failed to change password' };
    }
  }, [user]);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUser, changePassword, allUsers, firebaseReady, firebaseError, getUserById }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
