'use client';

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { AppState, ViewMode, ReplyReference, Notification } from '@/lib/types';
import { collection, onSnapshot, query, where, doc, setDoc, getDoc, deleteDoc, getDocs, addDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuth } from './AuthContext';

interface AppContextType {
  appState: AppState;
  setCurrentView: (view: ViewMode) => void;
  setCurrentServerId: (id: string | null) => void;
  setCurrentChannelId: (id: string | null) => void;
  setCurrentDMConversationId: (id: string | null) => void;
  setShowServerSettings: (show: boolean) => void;
  setShowCreateServer: (show: boolean) => void;
  setShowMediaViewer: (show: boolean) => void;
  setMediaViewer: (url: string, type: 'image' | 'video') => void;
  closeMediaViewer: () => void;
  setShowUserSettings: (show: boolean) => void;
  setReplyingTo: (ref: ReplyReference | null) => void;
  setEditingMessage: (id: string | null, content: string) => void;
  setShowProfileUserId: (id: string | null) => void;
  setShowAdminPanel: (show: boolean) => void;
  // Custom dialog state
  confirmDialog: { open: boolean; title: string; message: string; onConfirm: () => void };
  showConfirmDialog: (title: string, message: string, onConfirm: () => void) => void;
  closeConfirmDialog: () => void;
  promptDialog: { open: boolean; title: string; placeholder: string; onSubmit: (value: string) => void; defaultValue: string };
  showPromptDialog: (title: string, placeholder: string, onSubmit: (value: string) => void, defaultValue?: string) => void;
  closePromptDialog: () => void;
  alertDialog: { open: boolean; title: string; message: string };
  showAlertDialog: (title: string, message: string) => void;
  closeAlertDialog: () => void;
  // Notifications
  notifications: Notification[];
  clearNotifications: (targetId: string) => void;
  incrementNotification: (userId: string, targetId: string, type: 'server' | 'dm') => Promise<void>;
}

const defaultAppState: AppState = {
  currentView: 'server',
  currentServerId: null,
  currentChannelId: null,
  currentDMConversationId: null,
  showServerSettings: false,
  showCreateServer: false,
  showMediaViewer: false,
  mediaViewerUrl: '',
  mediaViewerType: 'image',
  showUserSettings: false,
  replyingTo: null,
  editingMessageId: null,
  editingMessageContent: '',
  showProfileUserId: null,
  showAdminPanel: false,
};

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [appState, setAppState] = useState<AppState>(defaultAppState);
  const [confirmDialog, setConfirmDialog] = useState<AppContextType['confirmDialog']>({
    open: false, title: '', message: '', onConfirm: () => {},
  });
  const [promptDialog, setPromptDialog] = useState<AppContextType['promptDialog']>({
    open: false, title: '', placeholder: '', onSubmit: () => {}, defaultValue: '',
  });
  const [alertDialog, setAlertDialog] = useState<AppContextType['alertDialog']>({
    open: false, title: '', message: '',
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);

  // Listen for notifications for the current user
  useEffect(() => {
    if (!user) {
      return;
    }
    const q = query(collection(db, 'notifications'), where('userId', '==', user.id));
    const unsub = onSnapshot(q, (snapshot) => {
      const notifs: Notification[] = [];
      snapshot.forEach((d) => {
        notifs.push({ id: d.id, ...d.data() } as Notification);
      });
      setNotifications(notifs);
    }, () => {
      // ignore errors
    });
    return () => unsub();
  }, [user]);

  const clearNotifications = useCallback(async (targetId: string) => {
    if (!user) return;
    const notif = notifications.find(n => n.targetId === targetId && n.userId === user.id);
    if (notif && notif.count > 0) {
      try {
        await deleteDoc(doc(db, 'notifications', notif.id));
      } catch {
        // Best effort
      }
    }
  }, [user, notifications]);

  const incrementNotification = useCallback(async (userId: string, targetId: string, type: 'server' | 'dm') => {
    try {
      // Find existing notification
      const q = query(collection(db, 'notifications'),
        where('userId', '==', userId),
        where('targetId', '==', targetId));
      const snapshot = await getDocs(q);

      if (!snapshot.empty) {
        const existingDoc = snapshot.docs[0];
        await setDoc(doc(db, 'notifications', existingDoc.id), {
          count: (existingDoc.data().count || 0) + 1,
          updatedAt: Date.now(),
        }, { merge: true });
      } else {
        await addDoc(collection(db, 'notifications'), {
          userId,
          targetId,
          type,
          count: 1,
          updatedAt: Date.now(),
        });
      }
    } catch (err) {
      console.error('Failed to increment notification:', err);
    }
  }, []);

  const setCurrentView = useCallback((view: ViewMode) => {
    setAppState(prev => ({ ...prev, currentView: view, currentServerId: view !== 'server' ? null : prev.currentServerId, currentChannelId: view !== 'server' ? null : prev.currentChannelId, currentDMConversationId: view !== 'dm' ? null : prev.currentDMConversationId }));
  }, []);

  const setCurrentServerId = useCallback((id: string | null) => {
    setAppState(prev => ({ ...prev, currentServerId: id, currentView: 'server' }));
  }, []);

  const setCurrentChannelId = useCallback((id: string | null) => {
    setAppState(prev => ({ ...prev, currentChannelId: id }));
  }, []);

  const setCurrentDMConversationId = useCallback((id: string | null) => {
    setAppState(prev => ({ ...prev, currentDMConversationId: id, currentView: 'dm' }));
  }, []);

  const setShowServerSettings = useCallback((show: boolean) => {
    setAppState(prev => ({ ...prev, showServerSettings: show }));
  }, []);

  const setShowCreateServer = useCallback((show: boolean) => {
    setAppState(prev => ({ ...prev, showCreateServer: show }));
  }, []);

  const setShowMediaViewer = useCallback((show: boolean) => {
    setAppState(prev => ({ ...prev, showMediaViewer: show }));
  }, []);

  const setMediaViewer = useCallback((url: string, type: 'image' | 'video') => {
    setAppState(prev => ({ ...prev, showMediaViewer: true, mediaViewerUrl: url, mediaViewerType: type }));
  }, []);

  const closeMediaViewer = useCallback(() => {
    setAppState(prev => ({ ...prev, showMediaViewer: false, mediaViewerUrl: '', mediaViewerType: 'image' }));
  }, []);

  const setShowUserSettings = useCallback((show: boolean) => {
    setAppState(prev => ({ ...prev, showUserSettings: show }));
  }, []);

  const setReplyingTo = useCallback((ref: ReplyReference | null) => {
    setAppState(prev => ({ ...prev, replyingTo: ref }));
  }, []);

  const setEditingMessage = useCallback((id: string | null, content: string) => {
    setAppState(prev => ({ ...prev, editingMessageId: id, editingMessageContent: content }));
  }, []);

  const setShowProfileUserId = useCallback((id: string | null) => {
    setAppState(prev => ({ ...prev, showProfileUserId: id }));
  }, []);

  const setShowAdminPanel = useCallback((show: boolean) => {
    setAppState(prev => ({ ...prev, showAdminPanel: show }));
  }, []);

  const showConfirmDialog = useCallback((title: string, message: string, onConfirm: () => void) => {
    setConfirmDialog({ open: true, title, message, onConfirm });
  }, []);

  const closeConfirmDialog = useCallback(() => {
    setConfirmDialog(prev => ({ ...prev, open: false }));
  }, []);

  const showPromptDialog = useCallback((title: string, placeholder: string, onSubmit: (value: string) => void, defaultValue?: string) => {
    setPromptDialog({ open: true, title, placeholder, onSubmit, defaultValue: defaultValue || '' });
  }, []);

  const closePromptDialog = useCallback(() => {
    setPromptDialog(prev => ({ ...prev, open: false }));
  }, []);

  const showAlertDialog = useCallback((title: string, message: string) => {
    setAlertDialog({ open: true, title, message });
  }, []);

  const closeAlertDialog = useCallback(() => {
    setAlertDialog(prev => ({ ...prev, open: false }));
  }, []);

  // Listen for login navigation event from AuthContext
  useEffect(() => {
    const handleLoginNavigate = (e: Event) => {
      const { serverId } = (e as CustomEvent).detail;
      if (serverId) {
        setCurrentServerId(serverId);
      }
    };
    window.addEventListener('dialogue-login-navigate', handleLoginNavigate);
    return () => window.removeEventListener('dialogue-login-navigate', handleLoginNavigate);
  }, [setCurrentServerId]);

  // Clear notifications when viewing a server or DM
  useEffect(() => {
    if (appState.currentServerId && user) {
      clearNotifications(appState.currentServerId);
    }
  }, [appState.currentServerId, user, clearNotifications]);

  useEffect(() => {
    if (appState.currentDMConversationId && user) {
      clearNotifications(appState.currentDMConversationId);
    }
  }, [appState.currentDMConversationId, user, clearNotifications]);

  return (
    <AppContext.Provider value={{
      appState,
      setCurrentView,
      setCurrentServerId,
      setCurrentChannelId,
      setCurrentDMConversationId,
      setShowServerSettings,
      setShowCreateServer,
      setShowMediaViewer,
      setMediaViewer,
      closeMediaViewer,
      setShowUserSettings,
      setReplyingTo,
      setEditingMessage,
      setShowProfileUserId,
      setShowAdminPanel,
      confirmDialog,
      showConfirmDialog,
      closeConfirmDialog,
      promptDialog,
      showPromptDialog,
      closePromptDialog,
      alertDialog,
      showAlertDialog,
      closeAlertDialog,
      notifications,
      clearNotifications,
      incrementNotification,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
