'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Server, Channel, DMConversation, User, Category, hasPermission } from '@/lib/types';
import { collection, onSnapshot, query, where, doc, getDoc, addDoc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Users, Plus, ChevronDown, Settings, LogOut, GripVertical } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Image from 'next/image';

// SVG icons for channel types
function HashIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="4" y1="9" x2="20" y2="9" />
      <line x1="4" y1="15" x2="20" y2="15" />
      <line x1="10" y1="3" x2="8" y2="21" />
      <line x1="16" y1="3" x2="14" y2="21" />
    </svg>
  );
}

function AnnouncementIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.73 21a2 2 0 0 1-3.46 0" />
      <path d="M2 8c0-2.2.7-4.3 2-6" />
      <path d="M22 8a10 10 0 0 0-2-6" />
      <circle cx="12" cy="3" r="1" fill="currentColor" />
    </svg>
  );
}

function ForumIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
      <line x1="8" y1="9" x2="16" y2="9" />
      <line x1="8" y1="13" x2="13" y2="13" />
    </svg>
  );
}

function RulesIcon({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="8" y1="13" x2="16" y2="13" />
      <line x1="8" y1="17" x2="13" y2="17" />
      <line x1="8" y1="9" x2="10" y2="9" />
    </svg>
  );
}

function ChannelIcon({ channel, className = '' }: { channel: Channel; className?: string }) {
  const iconType = channel.iconType || (channel.type === 'announcement' ? 'announcement' : channel.type === 'forum' ? 'forum' : channel.type === 'rules' ? 'rules' : 'default');

  switch (iconType) {
    case 'announcement':
      return <AnnouncementIcon className={className} />;
    case 'forum':
      return <ForumIcon className={className} />;
    case 'rules':
      return <RulesIcon className={className} />;
    default:
      return <HashIcon className={className} />;
  }
}

function CreateChannelDialog({ serverId, categories, onClose, canCreate }: { serverId: string; categories: Category[]; onClose: () => void; canCreate: boolean }) {
  const [channelName, setChannelName] = useState('');
  const [channelType, setChannelType] = useState<'text' | 'announcement' | 'forum' | 'rules'>('text');
  const [categoryId, setCategoryId] = useState<string>('');
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async () => {
    if (!channelName.trim() || !canCreate) return;
    setIsCreating(true);
    try {
      await addDoc(collection(db, 'channels'), {
        name: channelName.trim().toLowerCase().replace(/\s+/g, '-'),
        type: channelType,
        iconType: channelType === 'text' ? 'default' : channelType,
        serverId: serverId,
        createdAt: Date.now(),
        permissions: { _default: ['send_messages', 'read_messages'] },
        order: Date.now(),
        categoryId: categoryId || null,
      });
      onClose();
    } catch (err) {
      console.error('Failed to create channel:', err);
    }
    setIsCreating(false);
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">Create Channel</DialogTitle>
          <DialogDescription className="text-gray-400">Add a new channel to your server</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Channel Type</Label>
            <div className="space-y-1.5">
              {[
                { type: 'text' as const, label: 'Text Channel', desc: 'Send messages, images, and links', icon: <HashIcon className="w-5 h-5" /> },
                { type: 'announcement' as const, label: 'Announcement Channel', desc: 'Important updates and announcements', icon: <AnnouncementIcon className="w-5 h-5" /> },
                { type: 'forum' as const, label: 'Forum Channel', desc: 'Organized discussions with threads', icon: <ForumIcon className="w-5 h-5" /> },
                { type: 'rules' as const, label: 'Rules Channel', desc: 'Server rules and guidelines', icon: <RulesIcon className="w-5 h-5" /> },
              ].map(opt => (
                <button
                  key={opt.type}
                  onClick={() => setChannelType(opt.type)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg border transition-colors cursor-pointer ${
                    channelType === opt.type
                      ? 'bg-[#5865F2]/20 border-[#5865F2]/50 text-white'
                      : 'bg-[#2B2D31] border-[#3F4147] text-gray-300 hover:border-[#5865F2]/30'
                  }`}
                >
                  <div className={channelType === opt.type ? 'text-[#5865F2]' : 'text-gray-400'}>{opt.icon}</div>
                  <div className="text-left">
                    <div className="text-sm font-medium">{opt.label}</div>
                    <div className="text-xs text-gray-500">{opt.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Channel Name</Label>
            <div className="flex items-center bg-[#1E1F22] border border-[#3F4147] rounded-md px-3">
              <ChannelIcon channel={{ id: '', name: channelName, type: channelType, iconType: channelType === 'text' ? 'default' : channelType, serverId, createdAt: 0 }} className="w-4 h-4 text-gray-500 mr-2 shrink-0" />
              <input
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                className="flex-1 bg-transparent text-gray-100 outline-none py-2 text-sm"
                placeholder="new-channel"
              />
            </div>
          </div>
          {categories.length > 0 && (
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase text-gray-300">Category</Label>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger className="bg-[#1E1F22] border-[#3F4147] text-gray-100">
                  <SelectValue placeholder="Uncategorized" />
                </SelectTrigger>
                <SelectContent className="bg-[#2B2D31] border-[#3F4147]">
                  <SelectItem value="none" className="text-gray-300 cursor-pointer">Uncategorized</SelectItem>
                  {categories.sort((a, b) => a.order - b.order).map(cat => (
                    <SelectItem key={cat.id} value={cat.id} className="text-gray-300 cursor-pointer">{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <Button onClick={handleCreate} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isCreating || !channelName.trim()}>
            {isCreating ? 'Creating...' : 'Create Channel'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ChannelSettingsDialog({ channel, server, onClose }: { channel: Channel; server: Server; onClose: () => void }) {
  const [channelName, setChannelName] = useState(channel.name);
  const [permissions, setPermissions] = useState<Record<string, string[]>>(channel.permissions || { _default: ['send_messages', 'read_messages'] });
  const [iconType, setIconType] = useState<'default' | 'announcement' | 'forum' | 'rules'>(channel.iconType || 'default');
  const [categoryId, setCategoryId] = useState<string>(channel.categoryId || 'none');
  const [isSaving, setIsSaving] = useState(false);

  const ALL_CHANNEL_PERMS = ['send_messages', 'read_messages'];
  const categories = server.categories || [];

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await updateDoc(doc(db, 'channels', channel.id), {
        name: channelName.trim().toLowerCase().replace(/\s+/g, '-'),
        iconType,
        permissions,
        categoryId: categoryId === 'none' ? null : categoryId,
      });
      onClose();
    } catch (err) {
      console.error('Failed to save channel settings:', err);
    }
    setIsSaving(false);
  };

  const togglePerm = (roleId: string, perm: string) => {
    setPermissions(prev => {
      const current = prev[roleId] || [];
      return {
        ...prev,
        [roleId]: current.includes(perm) ? current.filter(p => p !== perm) : [...current, perm],
      };
    });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-white flex items-center gap-2">
            <ChannelIcon channel={{ ...channel, iconType }} className="w-5 h-5 text-gray-400" /> Channel Settings
          </DialogTitle>
          <DialogDescription className="text-gray-400">Configure #{channel.name}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Channel Name</Label>
            <div className="flex items-center bg-[#1E1F22] border border-[#3F4147] rounded-md px-3">
              <ChannelIcon channel={{ ...channel, iconType }} className="w-4 h-4 text-gray-500 mr-2 shrink-0" />
              <input
                value={channelName}
                onChange={(e) => setChannelName(e.target.value)}
                className="flex-1 bg-transparent text-gray-100 outline-none py-2 text-sm"
                placeholder="channel-name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Channel Icon</Label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { type: 'default' as const, label: 'Text', icon: <HashIcon className="w-5 h-5" /> },
                { type: 'announcement' as const, label: 'Alert', icon: <AnnouncementIcon className="w-5 h-5" /> },
                { type: 'forum' as const, label: 'Forum', icon: <ForumIcon className="w-5 h-5" /> },
                { type: 'rules' as const, label: 'Rules', icon: <RulesIcon className="w-5 h-5" /> },
              ].map(opt => (
                <button
                  key={opt.type}
                  onClick={() => setIconType(opt.type)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-lg border transition-colors cursor-pointer ${
                    iconType === opt.type
                      ? 'bg-[#5865F2]/20 border-[#5865F2]/50 text-white'
                      : 'bg-[#2B2D31] border-[#3F4147] text-gray-400 hover:border-[#5865F2]/30'
                  }`}
                >
                  {opt.icon}
                  <span className="text-[10px]">{opt.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Category selector */}
          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Category</Label>
            <Select value={categoryId} onValueChange={setCategoryId}>
              <SelectTrigger className="bg-[#1E1F22] border-[#3F4147] text-gray-100">
                <SelectValue placeholder="Uncategorized" />
              </SelectTrigger>
              <SelectContent className="bg-[#2B2D31] border-[#3F4147]">
                <SelectItem value="none" className="text-gray-300 cursor-pointer">Uncategorized</SelectItem>
                {categories.sort((a, b) => a.order - b.order).map(cat => (
                  <SelectItem key={cat.id} value={cat.id} className="text-gray-300 cursor-pointer">{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator className="bg-[#3F4147]" />

          <div className="space-y-2">
            <Label className="text-xs font-bold uppercase text-gray-300">Permissions</Label>
            <p className="text-xs text-gray-500">Control who can do what in this channel</p>

            <div className="bg-[#2B2D31] rounded-lg p-3">
              <div className="text-sm text-gray-300 font-medium mb-2">Default (everyone)</div>
              <div className="flex gap-4">
                {ALL_CHANNEL_PERMS.map(perm => (
                  <label key={perm} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={(permissions._default || []).includes(perm)}
                      onChange={() => togglePerm('_default', perm)}
                      className="rounded border-gray-600 accent-[#5865F2]"
                    />
                    <span className="text-xs">{perm.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                  </label>
                ))}
              </div>
            </div>

            {(server.roles || []).map(role => (
              <div key={role.id} className="bg-[#2B2D31] rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: role.color }} />
                  <span className="text-sm text-gray-300 font-medium">{role.name}</span>
                </div>
                <div className="flex gap-4">
                  {ALL_CHANNEL_PERMS.map(perm => (
                    <label key={perm} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={(permissions[role.id] || []).includes(perm)}
                        onChange={() => togglePerm(role.id, perm)}
                        className="rounded border-gray-600 accent-[#5865F2]"
                      />
                      <span className="text-xs">{perm.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <Button onClick={handleSave} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSaving}>
            {isSaving ? 'Saving...' : 'Save Channel Settings'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ServerSidebarContent({ serverId }: { serverId: string }) {
  const { user } = useAuth();
  const { appState, setCurrentChannelId, setShowServerSettings } = useApp();
  const [currentServer, setCurrentServer] = useState<Server | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [settingsChannel, setSettingsChannel] = useState<Channel | null>(null);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [dragCategoryKey, setDragCategoryKey] = useState<string | null>(null);
  const [dragOverCategoryKey, setDragOverCategoryKey] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'servers', serverId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        setCurrentServer({ id: snap.id, ...data, dialogueBoost: isBoost } as Server);
      }
    });
    return () => unsub();
  }, [serverId]);

  useEffect(() => {
    const q = query(collection(db, 'channels'), where('serverId', '==', serverId));
    const unsub = onSnapshot(q, (snapshot) => {
      const channelList: Channel[] = [];
      snapshot.forEach((d) => {
        channelList.push({ id: d.id, ...d.data() } as Channel);
      });
      // Sort by order first, then by createdAt as fallback
      channelList.sort((a, b) => {
        if (a.order !== undefined && b.order !== undefined) return a.order - b.order;
        if (a.order !== undefined) return -1;
        if (b.order !== undefined) return 1;
        return a.createdAt - b.createdAt;
      });
      setChannels(channelList);
      if (channelList.length > 0 && !appState.currentChannelId) {
        setCurrentChannelId(channelList[0].id);
      }
    });
    return () => unsub();
  }, [serverId, setCurrentChannelId, appState.currentChannelId]);

  const isServerOwner = currentServer && user && currentServer.ownerId === user.id;
  const isAdmin = user?.isAdmin;
  const canManageChannels = isAdmin || isServerOwner || hasPermission(currentServer, user, 'manage_channels');
  const canMoveChannels = isAdmin || isServerOwner || hasPermission(currentServer, user, 'move_channels');

  const categories = currentServer?.categories || [];

  // Build channel groups
  // If server has custom categories, group by categoryId
  // Otherwise, group by type (original behavior)
  const hasCustomCategories = categories.length > 0;

  interface ChannelGroup {
    key: string;
    label: string;
    channels: Channel[];
  }

  let channelGroups: ChannelGroup[] = [];

  if (hasCustomCategories) {
    // Group by custom categories
    const sortedCategories = [...categories].sort((a, b) => a.order - b.order);
    for (const cat of sortedCategories) {
      const catChannels = channels.filter(c => c.categoryId === cat.id);
      if (catChannels.length > 0) {
        channelGroups.push({ key: cat.id, label: cat.name, channels: catChannels });
      }
    }
    // Uncategorized channels
    const uncategorized = channels.filter(c => !c.categoryId);
    if (uncategorized.length > 0) {
      channelGroups.push({ key: '__uncategorized__', label: 'Uncategorized', channels: uncategorized });
    }
  } else {
    // Original grouping by type
    const textChannels = channels.filter(c => c.type === 'text' || (!c.type && !c.iconType) || c.iconType === 'default' || c.iconType === 'rules');
    const announcementChannels = channels.filter(c => c.type === 'announcement' || c.iconType === 'announcement');
    const forumChannels = channels.filter(c => c.type === 'forum' || c.iconType === 'forum');

    if (announcementChannels.length > 0) {
      channelGroups.push({ key: '__announcements__', label: 'Announcements', channels: announcementChannels });
    }
    if (textChannels.length > 0) {
      channelGroups.push({ key: '__text__', label: 'Text Channels', channels: textChannels });
    }
    if (forumChannels.length > 0) {
      channelGroups.push({ key: '__forums__', label: 'Forums', channels: forumChannels });
    }
  }

  // Drag and drop handlers for channels within a group
  const handleChannelDragStart = (index: number, categoryKey: string) => {
    setDragIndex(index);
    setDragCategoryKey(categoryKey);
  };

  const handleChannelDragOver = (e: React.DragEvent, index: number, categoryKey: string) => {
    e.preventDefault();
    setDragOverIndex(index);
    setDragOverCategoryKey(categoryKey);
  };

  const handleChannelDragEnd = () => {
    setDragIndex(null);
    setDragOverIndex(null);
    setDragCategoryKey(null);
    setDragOverCategoryKey(null);
  };

  const handleChannelDrop = async (dropIndex: number, dropCategoryKey: string) => {
    if (dragIndex === null || dragCategoryKey === null) return;
    if (dragIndex === dropIndex && dragCategoryKey === dropCategoryKey) {
      handleChannelDragEnd();
      return;
    }

    // Find the source and target groups
    const sourceGroup = channelGroups.find(g => g.key === dragCategoryKey);
    const targetGroup = channelGroups.find(g => g.key === dropCategoryKey);
    if (!sourceGroup || !targetGroup) {
      handleChannelDragEnd();
      return;
    }

    const draggedChannel = sourceGroup.channels[dragIndex];
    if (!draggedChannel) {
      handleChannelDragEnd();
      return;
    }

    // If dropping in a different category, update the channel's categoryId
    const newCategoryId = dropCategoryKey === '__uncategorized__' || dropCategoryKey.startsWith('__')
      ? null
      : dropCategoryKey;

    // Build new ordered list for the target group
    let newTargetChannels: Channel[];
    if (dragCategoryKey === dropCategoryKey) {
      // Same group - reorder
      newTargetChannels = [...targetGroup.channels];
      newTargetChannels.splice(dragIndex, 1);
      newTargetChannels.splice(dropIndex, 0, draggedChannel);
    } else {
      // Different group - insert into target
      newTargetChannels = [...targetGroup.channels];
      newTargetChannels.splice(dropIndex, 0, draggedChannel);
    }

    // Update order values for all channels in the target group
    try {
      for (let i = 0; i < newTargetChannels.length; i++) {
        const updateData: Record<string, unknown> = { order: i };
        if (newTargetChannels[i].id === draggedChannel.id) {
          updateData.categoryId = newCategoryId;
        }
        await updateDoc(doc(db, 'channels', newTargetChannels[i].id), updateData);
      }
    } catch (err) {
      console.error('Failed to reorder channels:', err);
    }

    handleChannelDragEnd();
  };

  return (
    <div className="w-60 bg-[#2B2D31] flex flex-col shrink-0">
      {/* Server Header */}
      <button
        className="h-12 px-4 flex items-center justify-between border-b border-[#1E1F22] hover:bg-[#35373C] transition-colors cursor-pointer"
        onClick={() => (isServerOwner || isAdmin) && setShowServerSettings(true)}
      >
        <span className="font-semibold text-white truncate">{currentServer?.name || 'Server'}</span>
        {(isServerOwner || isAdmin) && <Settings className="w-4 h-4 text-gray-400" />}
      </button>

      {/* Dialogue Boost badge */}
      {currentServer?.dialogueBoost && (
        <div className="px-4 py-1.5 bg-gradient-to-r from-[#5865F2]/20 to-[#EB459E]/20 border-b border-[#3F4147]">
          <span className="text-xs font-semibold bg-gradient-to-r from-[#5865F2] to-[#EB459E] bg-clip-text text-transparent">
            ✨ Dialogue Boost
          </span>
        </div>
      )}

      {/* Channels */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {channels.length === 0 ? (
            /* No channels yet - show create prompt */
            <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
              <div className="w-12 h-12 rounded-full bg-[#3F4147] flex items-center justify-center mb-3">
                <HashIcon className="w-6 h-6 text-gray-400" />
              </div>
              <p className="text-sm text-gray-300 font-medium mb-1">No channels yet</p>
              <p className="text-xs text-gray-500 mb-3">Create your first channel to start chatting</p>
              {canManageChannels && (
                <Button onClick={() => setShowCreateChannel(true)} className="bg-[#5865F2] hover:bg-[#4752C4] text-white text-xs cursor-pointer" size="sm">
                  <Plus className="w-3 h-3 mr-1" /> Create Channel
                </Button>
              )}
            </div>
          ) : (
            <>
              {channelGroups.map((group) => (
                <div key={group.key} className={group.key !== channelGroups[0]?.key ? 'mt-3' : ''}>
                  <div className="flex items-center justify-between px-1 mb-1">
                    <div className="flex items-center">
                      <ChevronDown className="w-3 h-3 text-gray-400 mr-0.5" />
                      <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wide">{group.label}</span>
                    </div>
                    {canManageChannels && (
                      <button onClick={() => setShowCreateChannel(true)} className="text-gray-400 hover:text-gray-200 cursor-pointer" title="Add Channel">
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  {group.channels.map((channel, index) => (
                    <ChannelItem
                      key={channel.id}
                      channel={channel}
                      isActive={appState.currentChannelId === channel.id}
                      canManage={canManageChannels}
                      canMove={canMoveChannels}
                      isDragging={dragIndex === index && dragCategoryKey === group.key}
                      isDragOver={dragOverIndex === index && dragOverCategoryKey === group.key}
                      onSelect={() => setCurrentChannelId(channel.id)}
                      onSettings={() => setSettingsChannel(channel)}
                      onDragStart={() => handleChannelDragStart(index, group.key)}
                      onDragOver={(e) => handleChannelDragOver(e, index, group.key)}
                      onDragEnd={handleChannelDragEnd}
                      onDrop={() => handleChannelDrop(index, group.key)}
                    />
                  ))}
                </div>
              ))}
            </>
          )}
        </div>
      </ScrollArea>

      {/* Server Members Count */}
      <div className="p-2 border-t border-[#1E1F22]">
        <div className="flex items-center px-2 py-1 text-xs text-gray-400">
          <Users className="w-3 h-3 mr-1.5" />
          <span>{currentServer?.members?.length || 0} Members</span>
        </div>
      </div>

      {/* Channel Settings Dialog */}
      {settingsChannel && currentServer && (
        <ChannelSettingsDialog
          channel={settingsChannel}
          server={currentServer}
          onClose={() => setSettingsChannel(null)}
        />
      )}

      {/* Create Channel Dialog */}
      {showCreateChannel && (
        <CreateChannelDialog
          serverId={serverId}
          categories={categories}
          onClose={() => setShowCreateChannel(false)}
          canCreate={canManageChannels}
        />
      )}
    </div>
  );
}

function ChannelItem({ channel, isActive, canManage, canMove, isDragging, isDragOver, onSelect, onSettings, onDragStart, onDragOver, onDragEnd, onDrop }: {
  channel: Channel;
  isActive: boolean;
  canManage: boolean;
  canMove: boolean;
  isDragging: boolean;
  isDragOver: boolean;
  onSelect: () => void;
  onSettings: () => void;
  onDragStart: () => void;
  onDragOver: (e: React.DragEvent) => void;
  onDragEnd: () => void;
  onDrop: () => void;
}) {
  return (
    <div
      draggable={canMove}
      onDragStart={canMove ? onDragStart : undefined}
      onDragOver={canMove ? onDragOver : undefined}
      onDragEnd={canMove ? onDragEnd : undefined}
      onDrop={canMove ? onDrop : undefined}
      className={`group flex items-center rounded text-sm transition-colors ${
        isDragging ? 'opacity-50' : ''
      } ${
        isDragOver ? 'border-t-2 border-[#5865F2]' : ''
      } ${
        isActive
          ? 'bg-[#404249] text-white'
          : 'text-gray-400 hover:text-gray-200 hover:bg-[#35373C]'
      }`}
    >
      {canMove && (
        <div className="pl-1 opacity-0 group-hover:opacity-50 transition-opacity cursor-grab active:cursor-grabbing">
          <GripVertical className="w-3 h-3" />
        </div>
      )}
      <button
        onClick={onSelect}
        className="flex-1 flex items-center px-2 py-1.5 cursor-pointer"
      >
        <ChannelIcon channel={channel} className="w-4 h-4 mr-1.5 shrink-0" />
        <span className="truncate">{channel.name}</span>
      </button>
      {canManage && (
        <div className="flex items-center pr-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => { e.stopPropagation(); onSettings(); }}
            className="p-0.5 hover:text-gray-200 cursor-pointer"
            title="Settings"
          >
            <Settings className="w-3 h-3" />
          </button>
        </div>
      )}
    </div>
  );
}

function DMSidebarContent({ userId }: { userId: string }) {
  const { user, logout } = useAuth();
  const { appState, setCurrentView, setCurrentDMConversationId, setShowUserSettings, setShowProfileUserId, notifications } = useApp();
  const [dmConversations, setDmConversations] = useState<DMConversation[]>([]);
  const [dmUsers, setDmUsers] = useState<Record<string, User>>({});

  useEffect(() => {
    const q = query(collection(db, 'dmConversations'), where('participants', 'array-contains', userId));
    const unsub = onSnapshot(q, (snapshot) => {
      const convos: DMConversation[] = [];
      snapshot.forEach((d) => {
        convos.push({ id: d.id, ...d.data() } as DMConversation);
      });
      convos.sort((a, b) => a.createdAt - b.createdAt);
      setDmConversations(convos);
    });
    return () => unsub();
  }, [userId]);

  useEffect(() => {
    const fetchDmUsers = async () => {
      const usersMap: Record<string, User> = {};
      for (const convo of dmConversations) {
        const otherUserId = convo.participants.find(id => id !== userId);
        if (otherUserId) {
          try {
            const userDoc = await getDoc(doc(db, 'users', otherUserId));
            if (userDoc.exists()) {
              usersMap[convo.id] = { id: userDoc.id, ...userDoc.data() } as User;
            }
          } catch (e) {
            console.error('Failed to fetch DM user:', e);
          }
        }
      }
      setDmUsers(usersMap);
    };
    fetchDmUsers();
  }, [dmConversations, userId]);

  // Get notification count for a DM conversation
  const getDmNotificationCount = (convoId: string): number => {
    const notif = notifications.find(n => n.targetId === convoId && n.type === 'dm');
    return notif?.count || 0;
  };

  return (
    <div className="w-60 bg-[#2B2D31] flex flex-col shrink-0">
      {/* DM Header */}
      <div className="h-12 px-4 flex items-center border-b border-[#1E1F22]">
        <span className="font-semibold text-white">Direct Messages</span>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2">
          {/* Friends Button */}
          <button
            onClick={() => setCurrentView('friends')}
            className={`w-full flex items-center px-2 py-1.5 rounded text-sm mb-1 transition-colors cursor-pointer ${
              appState.currentView === 'friends'
                ? 'bg-[#404249] text-white'
                : 'text-gray-300 hover:text-white hover:bg-[#35373C]'
            }`}
          >
            <Users className="w-4 h-4 mr-1.5" />
            <span>Friends</span>
          </button>

          <Separator className="my-2 bg-[#3F4147]" />

          {/* DM Conversations */}
          <div className="flex items-center px-1 mb-1">
            <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wide">Direct Messages</span>
          </div>
          {dmConversations.map((convo) => {
            const otherUser = dmUsers[convo.id];
            const notifCount = getDmNotificationCount(convo.id);
            return (
              <div key={convo.id} className="relative">
                <button
                  onClick={() => setCurrentDMConversationId(convo.id)}
                  className={`w-full flex items-center px-2 py-1.5 rounded text-sm group transition-colors cursor-pointer ${
                    appState.currentDMConversationId === convo.id
                      ? 'bg-[#404249] text-white'
                      : 'text-gray-300 hover:text-white hover:bg-[#35373C]'
                  }`}
                >
                  <div className="relative w-6 h-6 mr-2 shrink-0">
                    {otherUser?.avatar ? (
                      <Image src={otherUser.avatar} alt="" fill className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-[10px] text-white font-semibold">
                        {otherUser?.displayName?.[0]?.toUpperCase() || '?'}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#2B2D31] ${
                      otherUser?.status === 'online' ? 'bg-[#23A559]' : otherUser?.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
                    }`} />
                  </div>
                  <span
                    className="truncate"
                    style={otherUser?.gradient && otherUser.dialoguePlus ? { backgroundImage: otherUser.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
                  >
                    {otherUser?.displayName || 'Unknown User'}
                  </span>
                </button>
                {/* DM notification badge */}
                {notifCount > 0 && appState.currentDMConversationId !== convo.id && (
                  <div className="absolute top-0.5 left-0.5 min-w-[14px] h-[14px] bg-red-500 rounded-full flex items-center justify-center z-10">
                    <span className="text-[8px] font-bold text-white">{notifCount > 9 ? '9+' : notifCount}</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </ScrollArea>

      {/* User Panel */}
      {user && (
        <div className="h-12 bg-[#232428] flex items-center px-2 border-t border-[#1E1F22]">
          <div
            className="relative w-8 h-8 mr-2 cursor-pointer"
            onClick={() => setShowProfileUserId(user.id)}
          >
            {user.avatar ? (
              <Image src={user.avatar} alt="" fill className="rounded-full object-cover" unoptimized />
            ) : (
              <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-sm text-white font-semibold">
                {user.displayName[0].toUpperCase()}
              </div>
            )}
            <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#232428] ${
              user.status === 'online' ? 'bg-[#23A559]' : user.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
            }`} />
          </div>
          <div className="flex-1 min-w-0">
            <div
              className="text-sm font-semibold text-white truncate"
              style={user.gradient && user.dialoguePlus ? { backgroundImage: user.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
            >
              {user.displayName}
            </div>
            <div className="text-[10px] text-gray-400 truncate">{user.username}</div>
          </div>
          <button onClick={() => setShowUserSettings(true)} className="text-gray-400 hover:text-gray-200 ml-1 cursor-pointer" title="User Settings">
            <Settings className="w-4 h-4" />
          </button>
          <button onClick={logout} className="text-gray-400 hover:text-red-400 ml-1 cursor-pointer" title="Log out">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}

export default function ChannelSidebar() {
  const { user } = useAuth();
  const { appState } = useApp();

  if (appState.currentView === 'server' && appState.currentServerId) {
    return <ServerSidebarContent key={appState.currentServerId} serverId={appState.currentServerId} />;
  }

  if (user) {
    return <DMSidebarContent key={user.id} userId={user.id} />;
  }

  return null;
}
