'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Server } from '@/lib/types';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Separator } from '@/components/ui/separator';
import { Compass, Plus, MessageCircle, Settings, Shield } from 'lucide-react';
import Image from 'next/image';

export default function ServerSidebar() {
  const { user } = useAuth();
  const { appState, setCurrentServerId, setCurrentView, setShowCreateServer, setShowServerSettings, setShowAdminPanel, notifications } = useApp();
  const [servers, setServers] = useState<Server[]>([]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'servers'), where('members', 'array-contains', user.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const serverList: Server[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        // Backwards compatibility: check both dialogueBoost and dialoguePlus
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        serverList.push({ id: doc.id, ...data, dialogueBoost: isBoost } as Server);
      });
      serverList.sort((a, b) => a.createdAt - b.createdAt);
      setServers(serverList);
    });
    return () => unsubscribe();
  }, [user]);

  const handleDMClick = () => {
    setCurrentView('dm');
  };

  const handleDiscoverClick = () => {
    setCurrentView('discover');
  };

  // Get notification count for a server
  const getServerNotificationCount = (serverId: string): number => {
    const notif = notifications.find(n => n.targetId === serverId && n.type === 'server');
    return notif?.count || 0;
  };

  // Get total DM notification count
  const dmNotificationCount = notifications
    .filter(n => n.type === 'dm')
    .reduce((sum, n) => sum + (n.count || 0), 0);

  return (
    <TooltipProvider delayDuration={100}>
      <div className="w-[72px] bg-[#1E1F22] flex flex-col items-center py-3 gap-2 overflow-y-auto shrink-0"
        style={{ scrollbarWidth: 'none' }}
      >
        {/* DM Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="relative">
              <button
                onClick={handleDMClick}
                className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center group cursor-pointer ${
                  appState.currentView === 'dm' || appState.currentView === 'friends' ? 'rounded-[16px] bg-[#5865F2]' : 'bg-[#313338] hover:bg-[#5865F2]'
                }`}
              >
                <MessageCircle className="w-6 h-6 text-white" />
              </button>
              {/* DM notification badge */}
              {dmNotificationCount > 0 && (
                <div className="absolute -top-1 -left-1 min-w-[18px] h-[18px] bg-red-500 rounded-full flex items-center justify-center notification-badge z-10">
                  <span className="text-[10px] font-bold text-white">{dmNotificationCount > 99 ? '99+' : dmNotificationCount}</span>
                </div>
              )}
            </div>
          </TooltipTrigger>
          <TooltipContent side="right" className="bg-[#111214] text-white border-none">Direct Messages</TooltipContent>
        </Tooltip>

        {/* Discover Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={handleDiscoverClick}
              className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center cursor-pointer ${
                appState.currentView === 'discover' ? 'rounded-[16px] bg-[#5865F2]' : 'bg-[#313338] hover:bg-[#5865F2]'
              }`}
            >
              <Compass className="w-6 h-6 text-white" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="bg-[#111214] text-white border-none">Discover Servers</TooltipContent>
        </Tooltip>

        <Separator className="w-8 bg-gray-600 my-1" />

        {/* Server List */}
        {servers.map((server) => {
          const notifCount = getServerNotificationCount(server.id);
          return (
            <Tooltip key={server.id}>
              <TooltipTrigger asChild>
                <div className="relative">
                  <button
                    onClick={() => {
                      setCurrentServerId(server.id);
                    }}
                    className={`w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center relative group cursor-pointer ${
                      appState.currentServerId === server.id ? 'rounded-[16px]' : 'bg-[#313338]'
                    }`}
                  >
                    {server.icon ? (
                      <div className="relative w-full h-full rounded-inherit overflow-hidden">
                        <Image
                          src={server.icon}
                          alt={server.name}
                          fill
                          className="object-cover"
                          unoptimized
                        />
                      </div>
                    ) : (
                      <span className="text-white font-semibold text-sm">
                        {server.name.split(' ').map(w => w[0]).join('').substring(0, 3)}
                      </span>
                    )}
                    {/* Active pill */}
                    {appState.currentServerId === server.id && (
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-[4px] w-2 h-10 bg-white rounded-r-full" />
                    )}
                    {/* Hover pill */}
                    {appState.currentServerId !== server.id && (
                      <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-[4px] w-2 h-0 group-hover:h-5 bg-white rounded-r-full transition-all" />
                    )}
                  </button>
                  {/* Notification badge */}
                  {notifCount > 0 && appState.currentServerId !== server.id && (
                    <div className="absolute -top-1 -left-1 min-w-[18px] h-[18px] bg-red-500 rounded-full flex items-center justify-center notification-badge z-10">
                      <span className="text-[10px] font-bold text-white">{notifCount > 99 ? '99+' : notifCount}</span>
                    </div>
                  )}
                </div>
              </TooltipTrigger>
              <TooltipContent side="right" className="bg-[#111214] text-white border-none">{server.name}</TooltipContent>
            </Tooltip>
          );
        })}

        {/* Add Server Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => setShowCreateServer(true)}
              className="w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center bg-[#313338] hover:bg-[#23A559] text-[#23A559] hover:text-white cursor-pointer"
            >
              <Plus className="w-6 h-6" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="bg-[#111214] text-white border-none">Add a Server</TooltipContent>
        </Tooltip>

        {/* Admin Panel for Little_Timmy - different from server settings */}
        {user?.isAdmin && (
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => setShowAdminPanel(true)}
                className="w-12 h-12 rounded-[24px] hover:rounded-[16px] transition-all duration-200 flex items-center justify-center bg-[#313338] hover:bg-[#ED4245] text-[#ED4245] hover:text-white mt-auto cursor-pointer"
              >
                <Shield className="w-6 h-6" />
              </button>
            </TooltipTrigger>
            <TooltipContent side="right" className="bg-[#111214] text-white border-none">Admin Panel</TooltipContent>
          </Tooltip>
        )}
      </div>
    </TooltipProvider>
  );
}
