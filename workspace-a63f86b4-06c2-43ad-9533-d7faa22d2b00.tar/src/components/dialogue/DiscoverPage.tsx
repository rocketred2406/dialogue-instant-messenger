'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Server } from '@/lib/types';
import { collection, onSnapshot, query, where, doc, setDoc, updateDoc, arrayUnion, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Users, Globe, Lock, Rocket } from 'lucide-react';
import Image from 'next/image';

export default function DiscoverPage() {
  const { user, updateUser, allUsers } = useAuth();
  const { appState, setCurrentServerId, showAlertDialog } = useApp();
  const [servers, setServers] = useState<Server[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [joiningServer, setJoiningServer] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'servers'), where('isPublic', '==', true));
    const unsub = onSnapshot(q, (snapshot) => {
      const serverList: Server[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        // Backwards compatibility
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        serverList.push({ id: d.id, ...data, dialogueBoost: isBoost } as Server);
      });
      serverList.sort((a, b) => b.createdAt - a.createdAt);
      setServers(serverList);
    });
    return () => unsub();
  }, []);

  const filteredServers = servers.filter(s =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleJoinServer = async (server: Server) => {
    if (!user) return;
    if (server.members?.includes(user.id)) {
      setCurrentServerId(server.id);
      return;
    }
    if ((server.members?.length || 0) >= server.maxMembers) {
      showAlertDialog('Server Full', 'This server has reached its maximum member count.');
      return;
    }
    setJoiningServer(server.id);
    try {
      await updateDoc(doc(db, 'servers', server.id), {
        members: arrayUnion(user.id),
      });
      const updatedServerIds = [...(user.serverIds || []), server.id];
      await setDoc(doc(db, 'users', user.id), { serverIds: updatedServerIds }, { merge: true });
      await updateUser({ serverIds: updatedServerIds });
      setCurrentServerId(server.id);
    } catch (err) {
      console.error('Failed to join server:', err);
    }
    setJoiningServer(null);
  };

  // Get online count for a server by checking member statuses
  const getOnlineCount = (server: Server): number => {
    const memberIds = server.members || [];
    return memberIds.filter(id => {
      const member = allUsers.find(u => u.id === id);
      return member && (member.status === 'online' || member.status === 'idle');
    }).length;
  };

  return (
    <div className="flex-1 bg-[#313338] flex flex-col">
      {/* Header */}
      <div className="h-12 px-4 flex items-center border-b border-[#1E1F22] shrink-0">
        <Globe className="w-5 h-5 mr-2 text-gray-400" />
        <span className="font-semibold text-white">Discover Servers</span>
      </div>

      {/* Search */}
      <div className="px-4 py-3 border-b border-[#3F4147] shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for servers..."
            className="bg-[#1E1F22] border-[#3F4147] text-gray-100 pl-9"
          />
        </div>
      </div>

      {/* Server Grid */}
      <ScrollArea className="flex-1">
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredServers.length === 0 ? (
            <div className="col-span-full text-center py-12 text-gray-500">
              <Globe className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p className="text-lg font-medium">No servers found</p>
              <p className="text-sm">Be the first to create one!</p>
            </div>
          ) : (
            filteredServers.map((server) => {
              const isMember = server.members?.includes(user?.id || '');
              const hasDiscoverImage = server.dialogueBoost && server.discoverImage;
              const onlineCount = getOnlineCount(server);
              const totalMembers = server.members?.length || 0;
              return (
                <div
                  key={server.id}
                  className="bg-[#2B2D31] rounded-lg overflow-hidden hover:ring-1 hover:ring-[#5865F2] transition-all"
                >
                  {/* Server Banner - larger Y axis */}
                  <div className="h-36 relative">
                    {hasDiscoverImage ? (
                      <Image src={server.discoverImage!} alt="" fill className="object-cover" unoptimized />
                    ) : (
                      <div className={`w-full h-full ${server.dialogueBoost ? 'bg-gradient-to-br from-[#5865F2] to-[#EB459E]' : 'bg-gradient-to-br from-[#5865F2] to-[#4752C4]'}`} />
                    )}
                    {server.dialogueBoost && (
                      <div className="absolute top-2 right-2 bg-black/40 backdrop-blur-sm rounded-full px-2 py-0.5 flex items-center gap-1 z-10">
                        <Rocket className="w-3 h-3 text-yellow-400" />
                        <span className="text-[10px] text-yellow-300 font-semibold">Boost</span>
                      </div>
                    )}
                  </div>
                  {/* Server Icon - in front of banner */}
                  {server.icon && (
                    <div className="relative -mt-8 left-4 z-20 w-fit">
                      <div className="relative w-16 h-16">
                        <Image src={server.icon} alt="" width={64} height={64} className="rounded-xl object-cover border-4 border-[#2B2D31]" unoptimized />
                      </div>
                    </div>
                  )}
                  <div className={`${server.icon ? 'pt-2' : 'pt-4'} px-4 pb-4`}>
                    <h3 className="font-semibold text-white text-lg mb-1 flex items-center gap-1">
                      {server.name}
                      {server.dialogueBoost && <Rocket className="w-4 h-4 text-yellow-400" />}
                    </h3>
                    {/* Server Bio */}
                    {server.bio && (
                      <p className="text-sm text-gray-400 mb-2 line-clamp-2">{server.bio}</p>
                    )}
                    {/* Total and Online users like Discord */}
                    <div className="flex items-center gap-3 text-gray-400 text-sm mb-3">
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-[#23A559] shrink-0" />
                        {onlineCount} Online
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="w-3.5 h-3.5" />
                        {totalMembers} Members
                      </span>
                    </div>
                    <Button
                      onClick={() => handleJoinServer(server)}
                      className="w-full cursor-pointer"
                      variant={isMember ? 'outline' : 'default'}
                      disabled={joiningServer === server.id}
                      style={isMember ? {} : { backgroundColor: '#5865F2' }}
                    >
                      {joiningServer === server.id ? 'Joining...' : isMember ? 'Joined' : 'Join Server'}
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
