'use client';

import React from 'react';
import { useApp } from '@/contexts/AppContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

export function ConfirmDialog() {
  const { confirmDialog, closeConfirmDialog } = useApp();

  return (
    <Dialog open={confirmDialog.open} onOpenChange={(open) => { if (!open) closeConfirmDialog(); }}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-white">{confirmDialog.title}</DialogTitle>
          <DialogDescription className="text-gray-400">{confirmDialog.message}</DialogDescription>
        </DialogHeader>
        <div className="flex gap-3 mt-4">
          <Button variant="outline" onClick={closeConfirmDialog} className="flex-1 border-[#3F4147] text-gray-300 hover:text-white hover:bg-[#35373C] cursor-pointer">
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={() => {
              confirmDialog.onConfirm();
              closeConfirmDialog();
            }}
            className="flex-1 cursor-pointer"
          >
            Confirm
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function PromptDialog() {
  const { promptDialog, closePromptDialog } = useApp();
  const [value, setValue] = React.useState(promptDialog.defaultValue);

  React.useEffect(() => {
    setValue(promptDialog.defaultValue);
  }, [promptDialog.defaultValue, promptDialog.open]);

  return (
    <Dialog open={promptDialog.open} onOpenChange={(open) => { if (!open) closePromptDialog(); }}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-white">{promptDialog.title}</DialogTitle>
        </DialogHeader>
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder={promptDialog.placeholder}
          className="w-full bg-[#1E1F22] border border-[#3F4147] rounded-md px-3 py-2 text-gray-100 outline-none focus:border-[#5865F2] text-sm"
          onKeyDown={(e) => {
            if (e.key === 'Enter' && value.trim()) {
              promptDialog.onSubmit(value.trim());
              closePromptDialog();
            }
          }}
          autoFocus
        />
        <div className="flex gap-3 mt-2">
          <Button variant="outline" onClick={closePromptDialog} className="flex-1 border-[#3F4147] text-gray-300 hover:text-white hover:bg-[#35373C] cursor-pointer">
            Cancel
          </Button>
          <Button
            onClick={() => {
              if (value.trim()) {
                promptDialog.onSubmit(value.trim());
                closePromptDialog();
              }
            }}
            className="flex-1 bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer"
            disabled={!value.trim()}
          >
            Submit
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function AlertDialog() {
  const { alertDialog, closeAlertDialog } = useApp();

  return (
    <Dialog open={alertDialog.open} onOpenChange={(open) => { if (!open) closeAlertDialog(); }}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-white">{alertDialog.title}</DialogTitle>
          <DialogDescription className="text-gray-400">{alertDialog.message}</DialogDescription>
        </DialogHeader>
        <Button onClick={closeAlertDialog} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white mt-2 cursor-pointer">
          OK
        </Button>
      </DialogContent>
    </Dialog>
  );
}
