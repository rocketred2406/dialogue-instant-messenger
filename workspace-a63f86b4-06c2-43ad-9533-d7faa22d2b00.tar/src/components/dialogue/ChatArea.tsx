'use client';

import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Message, DMMessage, Server, Channel, CustomEmoji, EMOJI_CATEGORIES, hasPermission } from '@/lib/types';
import { collection, onSnapshot, query, where, doc, getDoc, addDoc, orderBy, limit, updateDoc, deleteDoc, setDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Hash, Users, Image as ImageIcon, Send, Reply, Pencil, Trash2, X, Smile, Link, Pin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Image from 'next/image';

const MAX_MESSAGE_LENGTH = 500;

function isImageUrl(url: string): boolean {
  // Check for base64 data URIs first
  if (url.startsWith('data:image/')) return true;
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    return /\.(jpg|jpeg|png|gif|webp|bmp|svg|ico)(\?.*)?$/.test(pathname);
  } catch {
    return false;
  }
}

function isVideoUrl(url: string): boolean {
  // Check for base64 data URIs first
  if (url.startsWith('data:video/')) return true;
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    return /\.(mp4|webm|mov|avi|mkv|ogg)(\?.*)?$/.test(pathname);
  } catch {
    return false;
  }
}

function detectMediaType(url: string): 'image' | 'video' | null {
  if (isImageUrl(url)) return 'image';
  if (isVideoUrl(url)) return 'video';
  return null;
}

function extractUrls(text: string): string[] {
  const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`\]]+|data:image\/[^;\s]+;base64,[^\s]+|data:video\/[^;\s]+;base64,[^\s]+)/g;
  return text.match(urlRegex) || [];
}

// Parse markdown: **bold**, *italic*, ~~strikethrough~~, `code`, # heading
function parseMarkdown(text: string): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const lines = text.split('\n');
  lines.forEach((line, lineIdx) => {
    if (lineIdx > 0) parts.push(<br key={`br-${lineIdx}`} />);

    const headingMatch = line.match(/^#\s+(.+)$/);
    if (headingMatch) {
      parts.push(<strong key={`h-${lineIdx}`} className="text-lg font-bold block mt-1">{parseInlineMarkdown(headingMatch[1])}</strong>);
      return;
    }
    const heading2Match = line.match(/^##\s+(.+)$/);
    if (heading2Match) {
      parts.push(<strong key={`h2-${lineIdx}`} className="text-base font-bold block mt-0.5">{parseInlineMarkdown(heading2Match[1])}</strong>);
      return;
    }

    parts.push(...parseInlineMarkdown(line));
  });
  return parts;
}

function parseInlineMarkdown(text: string): React.ReactNode[] {
  const result: React.ReactNode[] = [];
  const regex = /(\*\*(.+?)\*\*|\*(.+?)\*|~~(.+?)~~|`(.+?)`)/g;
  let lastIndex = 0;
  let match;
  let key = 0;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      result.push(<span key={`t-${key++}`}>{text.slice(lastIndex, match.index)}</span>);
    }

    const fullMatch = match[0];
    if (fullMatch.startsWith('**') && fullMatch.endsWith('**')) {
      result.push(<strong key={`b-${key++}`} className="font-bold">{match[2]}</strong>);
    } else if (fullMatch.startsWith('*') && fullMatch.endsWith('*') && !fullMatch.startsWith('**')) {
      result.push(<em key={`i-${key++}`} className="italic">{match[3]}</em>);
    } else if (fullMatch.startsWith('~~') && fullMatch.endsWith('~~')) {
      result.push(<s key={`s-${key++}`} className="line-through">{match[4]}</s>);
    } else if (fullMatch.startsWith('`') && fullMatch.endsWith('`')) {
      result.push(<code key={`c-${key++}`} className="bg-[#1E1F22] px-1 py-0.5 rounded text-sm font-mono">{match[5]}</code>);
    }

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    result.push(<span key={`t-${key++}`}>{text.slice(lastIndex)}</span>);
  }

  return result;
}

// Highlight @mentions in text
function parseMentions(text: string, members: {id: string; displayName: string; username: string}[]): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  const mentionRegex = /@(\w+)/g;
  let lastIndex = 0;
  let match;
  let key = 0;

  while ((match = mentionRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      parts.push(...parseMarkdown(text.slice(lastIndex, match.index)));
    }

    const mentionedName = match[1];
    const mentionedMember = members.find(m => m.username.toLowerCase() === mentionedName.toLowerCase() || m.displayName.toLowerCase() === mentionedName.toLowerCase());

    if (mentionedMember) {
      parts.push(
        <span key={`mention-${key++}`} className="bg-[#5865F2]/30 text-[#C9CDFB] px-0.5 rounded hover:bg-[#5865F2]/50">
          @{mentionedMember.displayName}
        </span>
      );
    } else {
      parts.push(<span key={`mention-${key++}`}>@{mentionedName}</span>);
    }

    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < text.length) {
    parts.push(...parseMarkdown(text.slice(lastIndex)));
  }

  if (parts.length === 0) {
    parts.push(...parseMarkdown(text));
  }

  return parts;
}

// Emoji Picker Component with search bar and server emojis tab
function EmojiPicker({ onEmojiSelect, customEmojis, onClose, showServerTab = true }: { onEmojiSelect: (emoji: string) => void; customEmojis: CustomEmoji[]; onClose: () => void; showServerTab?: boolean }) {
  const [activeCategory, setActiveCategory] = useState(EMOJI_CATEGORIES[0]?.name || 'Smileys');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter emojis based on search query
  const filteredCategories = searchQuery
    ? EMOJI_CATEGORIES.map(cat => ({
        ...cat,
        emojis: cat.emojis.filter(e => e.includes(searchQuery) || cat.name.toLowerCase().includes(searchQuery.toLowerCase()))
      })).filter(cat => cat.emojis.length > 0)
    : EMOJI_CATEGORIES;

  const filteredCustomEmojis = searchQuery
    ? customEmojis.filter(e => e.name.toLowerCase().includes(searchQuery.toLowerCase()))
    : customEmojis;

  // If searching, show a flat list
  if (searchQuery) {
    return (
      <div className="bg-[#2B2D31] border border-[#3F4147] rounded-lg shadow-xl w-80 max-h-80 overflow-hidden flex flex-col">
        <div className="p-2 border-b border-[#3F4147]">
          <div className="flex items-center gap-2">
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search emojis..."
              className="flex-1 bg-[#1E1F22] border border-[#3F4147] rounded-md px-2 py-1 text-xs text-gray-100 outline-none focus:border-[#5865F2]"
              autoFocus
            />
            <button onClick={onClose} className="text-gray-400 hover:text-white cursor-pointer shrink-0">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="overflow-y-auto flex-1 p-1.5" style={{ scrollbarWidth: 'thin' }}>
          {filteredCustomEmojis.length > 0 && (
            <div className="mb-2">
              <div className="text-[10px] font-semibold text-gray-400 uppercase px-1 mb-1">Server Emojis</div>
              <div className="grid grid-cols-8 gap-0.5">
                {filteredCustomEmojis.map(emoji => (
                  <button
                    key={emoji.id}
                    onClick={() => onEmojiSelect(`:${emoji.name}:`)}
                    className="w-8 h-8 flex items-center justify-center hover:bg-[#35373C] rounded cursor-pointer"
                    title={emoji.name}
                  >
                    <img src={emoji.imageUrl} alt={emoji.name} className="w-6 h-6 object-contain" />
                  </button>
                ))}
              </div>
            </div>
          )}
          {filteredCategories.map(cat => (
            <div key={cat.name} className="mb-2">
              <div className="text-[10px] font-semibold text-gray-400 uppercase px-1 mb-1">{cat.name}</div>
              <div className="grid grid-cols-8 gap-0.5">
                {cat.emojis.map((emoji, i) => (
                  <button
                    key={`${cat.name}-${i}`}
                    onClick={() => onEmojiSelect(emoji)}
                    className="w-8 h-8 flex items-center justify-center hover:bg-[#35373C] rounded text-lg cursor-pointer"
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          ))}
          {filteredCategories.length === 0 && filteredCustomEmojis.length === 0 && (
            <div className="text-center py-4 text-gray-500 text-xs">No emojis found</div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#2B2D31] border border-[#3F4147] rounded-lg shadow-xl w-80 max-h-80 overflow-hidden flex flex-col">
      {/* Search bar */}
      <div className="p-2 border-b border-[#3F4147]">
        <div className="flex items-center gap-2">
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search emojis..."
            className="flex-1 bg-[#1E1F22] border border-[#3F4147] rounded-md px-2 py-1 text-xs text-gray-100 outline-none focus:border-[#5865F2]"
          />
          <button onClick={onClose} className="text-gray-400 hover:text-white cursor-pointer shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
      <Tabs value={activeCategory} onValueChange={setActiveCategory}>
        <TabsList className="bg-[#1E1F22] w-full justify-start rounded-none border-b border-[#3F4147] overflow-x-auto flex-nowrap p-0 h-8">
          {EMOJI_CATEGORIES.map(cat => (
            <TabsTrigger key={cat.name} value={cat.name} className="text-[10px] px-2 py-0.5 h-7 shrink-0 text-gray-400 data-[state=active]:text-white data-[state=active]:bg-[#404249] cursor-pointer whitespace-nowrap">
              {cat.name}
            </TabsTrigger>
          ))}
          {customEmojis.length > 0 && showServerTab && (
            <TabsTrigger value="custom" className="text-[10px] px-2 py-0.5 h-7 shrink-0 text-gray-400 data-[state=active]:text-white data-[state=active]:bg-[#404249] cursor-pointer whitespace-nowrap">
              Server
            </TabsTrigger>
          )}
        </TabsList>
        {EMOJI_CATEGORIES.map(cat => (
          <TabsContent key={cat.name} value={cat.name} className="mt-0 overflow-y-auto max-h-56 p-1.5" style={{ scrollbarWidth: 'thin' }}>
            <div className="grid grid-cols-8 gap-0.5">
              {cat.emojis.map((emoji, i) => (
                <button
                  key={i}
                  onClick={() => onEmojiSelect(emoji)}
                  className="w-8 h-8 flex items-center justify-center hover:bg-[#35373C] rounded text-lg cursor-pointer"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </TabsContent>
        ))}
        {customEmojis.length > 0 && (
          <TabsContent value="custom" className="mt-0 overflow-y-auto max-h-56 p-1.5" style={{ scrollbarWidth: 'thin' }}>
            <div className="grid grid-cols-6 gap-1">
              {customEmojis.map(emoji => (
                <button
                  key={emoji.id}
                  onClick={() => onEmojiSelect(`:${emoji.name}:`)}
                  className="p-1 hover:bg-[#35373C] rounded cursor-pointer flex items-center justify-center"
                  title={emoji.name}
                >
                  <img src={emoji.imageUrl} alt={emoji.name} className="w-7 h-7 object-contain" />
                </button>
              ))}
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

function MessageItem({
  message,
  onMediaClick,
  onReply,
  onEdit,
  onDelete,
  onPin,
  canEditOthers,
  canDeleteOthers,
  canPin,
  isOwn,
  members,
  allMessages,
  customEmojis,
  onUsernameClick,
  onToggleReaction,
  onReactToMessage,
  currentUser,
}: {
  message: Message | DMMessage;
  onMediaClick: (url: string, type: 'image' | 'video') => void;
  onReply: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onPin?: () => void;
  canEditOthers: boolean;
  canDeleteOthers: boolean;
  canPin: boolean;
  isOwn: boolean;
  members: {id: string; displayName: string; username: string}[];
  allMessages: (Message | DMMessage)[];
  customEmojis: CustomEmoji[];
  onUsernameClick: (userId: string) => void;
  onToggleReaction: (messageId: string, emoji: string) => void;
  onReactToMessage: (messageId: string) => void;
  currentUser: {id: string; dialoguePlus?: boolean} | null;
}) {
  const timeStr = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const [showActions, setShowActions] = useState(false);
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  const replyMessage = message.replyTo
    ? allMessages.find(m => m.id === message.replyTo!.messageId)
    : null;

  const processContent = (content: string): string => {
    if (customEmojis.length === 0) return content;
    return content.replace(/:([\w]+):/g, (match, name) => {
      const emoji = customEmojis.find(e => e.name.toLowerCase() === name.toLowerCase());
      return emoji ? `⟨emoji:${emoji.imageUrl}⟩` : match;
    });
  };

  const renderContent = () => {
    const processedContent = processContent(message.content);
    const urls = extractUrls(processedContent);

    const emojiOnlyMatch = processedContent.match(/^⟨emoji:([^⟩]+)⟩$/);
    if (emojiOnlyMatch) {
      return (
        <div className="mt-1">
          <img src={emojiOnlyMatch[1]} alt="Custom emoji" className="w-16 h-16 object-contain" />
        </div>
      );
    }

    if (urls.length === 0) {
      const parsed = parseMentions(processedContent, members);
      const withEmojis = replaceCustomEmojisInline(parsed, customEmojis);
      return <div>{withEmojis}</div>;
    }

    const parts: React.ReactNode[] = [];
    let remaining = processedContent;

    urls.forEach((url, idx) => {
      if (url.startsWith('⟨emoji:') || url.includes('⟨emoji:')) return;

      const urlIndex = remaining.indexOf(url);
      if (urlIndex > 0) {
        const beforeText = remaining.substring(0, urlIndex);
        parts.push(<span key={`text-${idx}`}>{parseMentions(beforeText, members)}</span>);
      }

      const mediaType = detectMediaType(url);
      if (mediaType === 'image') {
        parts.push(
          <div key={`media-${idx}`} className="mt-1 max-w-md">
            <img
              src={url}
              alt="Shared image"
              className="max-w-full max-h-80 rounded-lg cursor-pointer hover:opacity-90 transition-opacity object-contain"
              onClick={() => onMediaClick(url, 'image')}
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          </div>
        );
      } else if (mediaType === 'video') {
        parts.push(
          <div key={`media-${idx}`} className="mt-1 max-w-md">
            <video
              src={url}
              controls
              className="max-w-full max-h-80 rounded-lg"
              preload="metadata"
            >
              Your browser does not support the video tag.
            </video>
          </div>
        );
      } else {
        parts.push(
          <a key={`link-${idx}`} href={url} target="_blank" rel="noopener noreferrer" className="text-[#00A8FC] hover:underline">
            {url}
          </a>
        );
      }

      remaining = remaining.substring(urlIndex + url.length);
    });

    if (remaining) {
      parts.push(<span key="text-end">{parseMentions(remaining, members)}</span>);
    }

    return <div>{parts}</div>;
  };

  const senderGradient = message.senderGradient || '';
  const reactions = message.reactions || {};

  return (
    <div
      className={`flex items-start px-4 py-1 hover:bg-[#2E3035] group relative ${senderGradient ? 'msg-row-gradient-hover' : ''}`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => { if (!showReactionPicker) setShowActions(false); }}
    >
      <div className="w-10 h-10 mr-4 mt-0.5 shrink-0 cursor-pointer" onClick={() => onUsernameClick(message.senderId)}>
        {message.senderAvatar ? (
          <Image src={message.senderAvatar} alt="" width={40} height={40} className="rounded-full object-cover" unoptimized />
        ) : (
          <div className="w-10 h-10 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-semibold">
            {message.senderName?.[0]?.toUpperCase() || '?'}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        {/* Reply reference */}
        {message.replyTo && (
          <div className="flex items-center gap-1 mb-0.5 pl-0.5">
            <Reply className="w-3 h-3 text-gray-500 shrink-0 rotate-180" />
            <span className="text-xs text-gray-400 truncate">
              Replying to <span className="text-[#C9CDFB] font-medium">{message.replyTo.senderName}</span>
              {replyMessage && <span className="text-gray-500 ml-1">— {replyMessage.content.substring(0, 50)}{replyMessage.content.length > 50 ? '...' : ''}</span>}
            </span>
          </div>
        )}
        <div className="flex items-baseline gap-2">
          <span
            className={`font-medium hover:underline cursor-pointer ${senderGradient ? 'gradient-username' : 'text-white'}`}
            style={senderGradient ? { backgroundImage: senderGradient } : {}}
            onClick={() => onUsernameClick(message.senderId)}
          >
            {message.senderName}
          </span>
          <span className="text-[10px] text-gray-500">{timeStr}</span>
          {message.editedAt && <span className="text-[10px] text-gray-600">(edited)</span>}
          {message.pinned && <Pin className="w-3 h-3 text-yellow-500 ml-1" />}
        </div>
        <div className="text-gray-200 text-[15px] leading-[1.375rem] break-words">
          {renderContent()}
        </div>

        {/* Reactions */}
        {Object.keys(reactions).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1">
            {Object.entries(reactions).map(([emoji, userIds]) => {
              const hasReacted = userIds.includes(currentUser?.id || '');
              return (
                <button
                  key={emoji}
                  onClick={() => onToggleReaction(message.id, emoji)}
                  className={`flex items-center gap-1 px-1.5 py-0.5 rounded-full text-xs border cursor-pointer transition-colors ${
                    hasReacted
                      ? 'bg-[#5865F2]/20 border-[#5865F2]/50 text-[#C9CDFB]'
                      : 'bg-[#2B2D31] border-[#3F4147] text-gray-300 hover:border-[#5865F2]/50'
                  }`}
                >
                  <span className="text-sm">{emoji}</span>
                  <span className="text-[11px]">{userIds.length}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Message Actions */}
      {showActions && (
        <div className="absolute -top-3 right-4 flex items-center bg-[#2B2D31] border border-[#3F4147] rounded-md shadow-lg z-10">
          {/* React button */}
          <Popover open={showReactionPicker} onOpenChange={(open) => { if (!open && !showReactionPicker) return; setShowReactionPicker(open); }}>
            <PopoverTrigger asChild>
              <button className="p-1.5 hover:bg-[#35373C] text-gray-400 hover:text-gray-200 cursor-pointer" title="Add Reaction">
                <Smile className="w-4 h-4" />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 border-none shadow-none bg-transparent" side="top" align="end" onInteractOutside={(e) => { /* Only close on Escape or X button, not on outside clicks within the picker */ e.preventDefault(); setShowReactionPicker(false); }}>
              <EmojiPicker
                onEmojiSelect={(emoji) => {
                  onToggleReaction(message.id, emoji);
                  // Don't close after selecting - user may want to add more
                }}
                customEmojis={customEmojis}
                onClose={() => setShowReactionPicker(false)}
                showServerTab={true}
              />
            </PopoverContent>
          </Popover>
          <button onClick={onReply} className="p-1.5 hover:bg-[#35373C] text-gray-400 hover:text-gray-200 cursor-pointer" title="Reply">
            <Reply className="w-4 h-4" />
          </button>
          {canPin && onPin && (
            <button onClick={onPin} className="p-1.5 hover:bg-[#35373C] text-gray-400 hover:text-gray-200 cursor-pointer" title="Pin message">
              <Pin className="w-4 h-4" />
            </button>
          )}
          {(isOwn || canEditOthers) && (
            <button onClick={onEdit} className="p-1.5 hover:bg-[#35373C] text-gray-400 hover:text-gray-200 cursor-pointer" title="Edit">
              <Pencil className="w-4 h-4" />
            </button>
          )}
          {(isOwn || canDeleteOthers) && (
            <button onClick={onDelete} className="p-1.5 hover:bg-[#35373C] text-gray-400 hover:text-red-400 cursor-pointer" title="Delete">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function replaceCustomEmojisInline(nodes: React.ReactNode[], customEmojis: CustomEmoji[]): React.ReactNode[] {
  if (customEmojis.length === 0) return nodes;
  return nodes.map((node, idx) => {
    if (typeof node === 'string') {
      const parts: React.ReactNode[] = [];
      const regex = /⟨emoji:([^⟩]+)⟩/g;
      let lastIndex = 0;
      let match;
      let key = 0;
      while ((match = regex.exec(node)) !== null) {
        if (match.index > lastIndex) {
          parts.push(<span key={`e-${idx}-${key++}`}>{node.slice(lastIndex, match.index)}</span>);
        }
        parts.push(<img key={`eimg-${idx}-${key++}`} src={match[1]} alt="" className="w-5 h-5 inline-block object-contain mx-0.5" />);
        lastIndex = match.index + match[0].length;
      }
      if (lastIndex < node.length) {
        parts.push(<span key={`e-${idx}-${key++}`}>{node.slice(lastIndex)}</span>);
      }
      return parts.length > 0 ? <React.Fragment key={`efrag-${idx}`}>{parts}</React.Fragment> : node;
    }
    return node;
  });
}

export default function ChatArea() {
  const { user } = useAuth();
  const {
    appState, setMediaViewer, setReplyingTo, setEditingMessage,
    showConfirmDialog, setShowProfileUserId, incrementNotification,
  } = useApp();
  const [messages, setMessages] = useState<(Message | DMMessage)[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [dmOtherUser, setDmOtherUser] = useState<{displayName: string; status: string; username: string} | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const [showMediaUpload, setShowMediaUpload] = useState(false);
  const [mediaUrl, setMediaUrl] = useState('');

  const [showMentionList, setShowMentionList] = useState(false);
  const [mentionFilter, setMentionFilter] = useState('');
  const [mentionStartIndex, setMentionStartIndex] = useState(-1);

  const [currentServer, setCurrentServer] = useState<Server | null>(null);
  const [serverMembers, setServerMembers] = useState<{id: string; displayName: string; username: string}[]>([]);
  const [currentChannel, setCurrentChannel] = useState<Channel | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Cooldown state
  const [lastMessageTime, setLastMessageTime] = useState(0);
  const [cooldownRemaining, setCooldownRemaining] = useState(0);

  // Get server cooldown (default 1000ms)
  const serverCooldown = currentServer?.messageCooldown || 1000;

  // Cooldown timer
  useEffect(() => {
    if (cooldownRemaining <= 0) return;
    const timer = setTimeout(() => {
      setCooldownRemaining(Math.max(0, serverCooldown - (Date.now() - lastMessageTime)));
    }, 100);
    return () => clearTimeout(timer);
  }, [cooldownRemaining, lastMessageTime, serverCooldown]);

  // Fetch current server data
  useEffect(() => {
    if (!appState.currentServerId) return;
    const unsub = onSnapshot(doc(db, 'servers', appState.currentServerId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        // Backwards compatibility: check both dialogueBoost and dialoguePlus
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        setCurrentServer({ id: snap.id, ...data, dialogueBoost: isBoost } as Server);
      }
    });
    return () => unsub();
  }, [appState.currentServerId]);

  // Fetch server members
  useEffect(() => {
    if (!currentServer?.members?.length) return;
    const fetchMembers = async () => {
      const memberList: {id: string; displayName: string; username: string}[] = [];
      for (const memberId of currentServer.members!) {
        try {
          const userDoc = await getDoc(doc(db, 'users', memberId));
          if (userDoc.exists()) {
            const data = userDoc.data();
            memberList.push({ id: userDoc.id, displayName: data.displayName, username: data.username });
          }
        } catch (e) {
          console.error('Failed to fetch member:', e);
        }
      }
      setServerMembers(memberList);
    };
    fetchMembers();
  }, [currentServer?.members]);

  // Fetch current channel data
  useEffect(() => {
    if (!appState.currentChannelId) return;
    const unsub = onSnapshot(doc(db, 'channels', appState.currentChannelId), (snap) => {
      if (snap.exists()) {
        setCurrentChannel({ id: snap.id, ...snap.data() } as Channel);
      }
    });
    return () => unsub();
  }, [appState.currentChannelId]);

  // Fetch DM other user info
  useEffect(() => {
    if (!appState.currentDMConversationId || !user) return;
    const fetchDmUser = async () => {
      const convoDoc = await getDoc(doc(db, 'dmConversations', appState.currentDMConversationId!));
      if (convoDoc.exists()) {
        const participants = convoDoc.data().participants as string[];
        const otherUserId = participants.find(id => id !== user.id);
        if (otherUserId) {
          const userDoc = await getDoc(doc(db, 'users', otherUserId));
          if (userDoc.exists()) {
            setDmOtherUser({
              displayName: userDoc.data().displayName,
              status: userDoc.data().status,
              username: userDoc.data().username,
            });
          }
        }
      }
    };
    fetchDmUser();
  }, [appState.currentDMConversationId, user]);

  // Fetch messages for channel
  useEffect(() => {
    if (!appState.currentChannelId) return;
    const q = query(
      collection(db, 'messages'),
      where('channelId', '==', appState.currentChannelId),
      orderBy('createdAt', 'asc'),
      limit(200)
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const msgs: (Message | DMMessage)[] = [];
      snapshot.forEach((d) => {
        msgs.push({ id: d.id, ...d.data() } as Message);
      });
      setMessages(msgs);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }, () => {
      const q2 = query(collection(db, 'messages'), where('channelId', '==', appState.currentChannelId), limit(200));
      const unsub2 = onSnapshot(q2, (snapshot2) => {
        const msgs: (Message | DMMessage)[] = [];
        snapshot2.forEach((d) => { msgs.push({ id: d.id, ...d.data() } as Message); });
        msgs.sort((a, b) => a.createdAt - b.createdAt);
        setMessages(msgs);
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
      });
      return () => unsub2();
    });
    return () => unsub();
  }, [appState.currentChannelId]);

  // Fetch messages for DM
  useEffect(() => {
    if (!appState.currentDMConversationId) return;
    const q = query(
      collection(db, 'dmMessages'),
      where('conversationId', '==', appState.currentDMConversationId),
      orderBy('createdAt', 'asc'),
      limit(200)
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const msgs: (Message | DMMessage)[] = [];
      snapshot.forEach((d) => { msgs.push({ id: d.id, ...d.data() } as DMMessage); });
      setMessages(msgs);
      setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }, () => {
      const q2 = query(collection(db, 'dmMessages'), where('conversationId', '==', appState.currentDMConversationId), limit(200));
      const unsub2 = onSnapshot(q2, (snapshot2) => {
        const msgs: (Message | DMMessage)[] = [];
        snapshot2.forEach((d) => { msgs.push({ id: d.id, ...d.data() } as DMMessage); });
        msgs.sort((a, b) => a.createdAt - b.createdAt);
        setMessages(msgs);
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
      });
      return () => unsub2();
    });
    return () => unsub();
  }, [appState.currentDMConversationId]);

  // Reset messages when switching
  useEffect(() => {
    return () => { setMessages([]); };
  }, [appState.currentChannelId, appState.currentDMConversationId]);

  // Clear editing/replying state when switching
  useEffect(() => {
    setReplyingTo(null);
    setEditingMessage(null, '');
  }, [appState.currentChannelId, appState.currentDMConversationId, setReplyingTo, setEditingMessage]);

  // Permission checks - uses fixed hasPermission with channel context
  const isServerOwner = currentServer?.ownerId === user?.id;
  const isAdmin = user?.isAdmin;
  const canEditOthers = isAdmin || isServerOwner || hasPermission(currentServer, user, 'edit_messages', currentChannel);
  const canDeleteOthers = isAdmin || isServerOwner || hasPermission(currentServer, user, 'delete_messages', currentChannel);
  const canPin = isAdmin || isServerOwner || hasPermission(currentServer, user, 'pin_messages', currentChannel);
  const canSendMessages = appState.currentView === 'dm' || isAdmin || isServerOwner || hasPermission(currentServer, user, 'send_messages', currentChannel);
  const canReadMessages = appState.currentView === 'dm' || isAdmin || isServerOwner || hasPermission(currentServer, user, 'read_messages', currentChannel);
  const canKickMembers = appState.currentView === 'server' && (isAdmin || isServerOwner || hasPermission(currentServer, user, 'kick_members', currentChannel));
  const canBanMembers = appState.currentView === 'server' && (isAdmin || isServerOwner || hasPermission(currentServer, user, 'ban_members', currentChannel));

  // Custom emojis: available if server has dialogueBoost, or user has dialoguePlus (can use on other servers/DMs)
  const serverEmojis = (currentServer?.dialogueBoost ? (currentServer?.customEmojis || []) : []);
  const customEmojis = user?.dialoguePlus ? serverEmojis : (appState.currentView === 'server' ? serverEmojis : []);

  // Parse chat commands (?kick, ?permban, ?timeout)
  const parseCommand = (content: string): { command: string; args: string[] } | null => {
    const trimmed = content.trim();
    if (!trimmed.startsWith('?')) return null;
    const parts = trimmed.slice(1).split(/\s+/);
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);
    return { command, args };
  };

  const parseTimeoutDuration = (timeStr: string): number | null => {
    const match = timeStr.match(/^(\d+)(s|m|h|d)?$/i);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit = (match[2] || 's').toLowerCase();
    switch (unit) {
      case 's': return value * 1000;
      case 'm': return value * 60 * 1000;
      case 'h': return value * 60 * 60 * 1000;
      case 'd': return value * 24 * 60 * 60 * 1000;
      default: return null;
    }
  };

  const executeCommand = async (command: string, args: string[]): Promise<string | null> => {
    if (!user || !currentServer) return 'No server context';

    const targetUsername = args[0];
    if (!targetUsername) return 'Usage: ?' + command + ' [username] [reason/time]';

    // Find the target user by username or displayName
    const targetMember = serverMembers.find(m =>
      m.username.toLowerCase() === targetUsername.toLowerCase() ||
      m.displayName.toLowerCase() === targetUsername.toLowerCase()
    );
    if (!targetMember) return `User "${targetUsername}" not found in this server`;

    // Can't target server owner or admin
    const targetDoc = await getDoc(doc(db, 'users', targetMember.id));
    if (!targetDoc.exists()) return 'User not found';
    const targetData = targetDoc.data();
    if (targetData.isAdmin) return 'Cannot perform this action on an admin';
    if (currentServer.ownerId === targetMember.id) return 'Cannot perform this action on the server owner';

    try {
      if (command === 'kick') {
        if (!canKickMembers) return 'You don\'t have permission to kick members';
        const reason = args.slice(1).join(' ') || 'No reason provided';
        // Remove from server members
        await updateDoc(doc(db, 'servers', currentServer.id), {
          members: (currentServer.members || []).filter(id => id !== targetMember.id),
        });
        // Remove server from user's serverIds
        const targetServerIds = (targetData.serverIds || []).filter((id: string) => id !== currentServer.id);
        await updateDoc(doc(db, 'users', targetMember.id), { serverIds: targetServerIds });
        // Post system message
        if (appState.currentChannelId) {
          await addDoc(collection(db, 'messages'), {
            content: `👢 **${targetMember.displayName}** was kicked by **${user.displayName}**. Reason: ${reason}`,
            senderId: 'system',
            senderName: 'System',
            senderAvatar: '',
            channelId: appState.currentChannelId,
            serverId: currentServer.id,
            type: 'system',
            mediaUrl: '',
            createdAt: Date.now(),
            reactions: {},
          });
        }
        return null; // Success
      }

      if (command === 'permban') {
        if (!canBanMembers) return 'You don\'t have permission to ban members';
        const reason = args.slice(1).join(' ') || 'No reason provided';
        // Remove from server members
        await updateDoc(doc(db, 'servers', currentServer.id), {
          members: (currentServer.members || []).filter(id => id !== targetMember.id),
        });
        const targetServerIds = (targetData.serverIds || []).filter((id: string) => id !== currentServer.id);
        await updateDoc(doc(db, 'users', targetMember.id), { serverIds: targetServerIds });
        if (appState.currentChannelId) {
          await addDoc(collection(db, 'messages'), {
            content: `🔨 **${targetMember.displayName}** was banned by **${user.displayName}**. Reason: ${reason}`,
            senderId: 'system',
            senderName: 'System',
            senderAvatar: '',
            channelId: appState.currentChannelId,
            serverId: currentServer.id,
            type: 'system',
            mediaUrl: '',
            createdAt: Date.now(),
            reactions: {},
          });
        }
        return null;
      }

      if (command === 'timeout') {
        if (!canKickMembers) return 'You don\'t have permission to timeout members';
        const timeStr = args[1];
        if (!timeStr) return 'Usage: ?timeout [username] [time] (e.g., 30s, 5m, 1h, 1d)';
        const duration = parseTimeoutDuration(timeStr);
        if (!duration) return 'Invalid time format. Use: 30s, 5m, 1h, 1d';
        const reason = args.slice(2).join(' ') || 'No reason provided';
        const timeoutUntil = Date.now() + duration;
        await updateDoc(doc(db, 'users', targetMember.id), {
          timeoutUntil,
          timeoutReason: reason,
        });
        if (appState.currentChannelId) {
          await addDoc(collection(db, 'messages'), {
            content: `⏳ **${targetMember.displayName}** was timed out by **${user.displayName}** for ${timeStr}. Reason: ${reason}`,
            senderId: 'system',
            senderName: 'System',
            senderAvatar: '',
            channelId: appState.currentChannelId,
            serverId: currentServer.id,
            type: 'system',
            mediaUrl: '',
            createdAt: Date.now(),
            reactions: {},
          });
        }
        return null;
      }

      return `Unknown command: ?${command}`;
    } catch (err) {
      console.error('Command execution failed:', err);
      return 'Failed to execute command';
    }
  };

  // Check if user is timed out in this server
  const isTimedOut = user?.timeoutUntil && user.timeoutUntil > Date.now();

  const sendMessage = async () => {
    if (!user || !inputValue.trim()) return;
    if (!canSendMessages && appState.currentView === 'server') return;
    if (isTimedOut && appState.currentView === 'server') return;

    // Check cooldown
    const now = Date.now();
    if (now - lastMessageTime < serverCooldown) return;

    // Check message length
    const content = inputValue.trim();
    if (content.length > MAX_MESSAGE_LENGTH) return;

    setInputValue('');
    setLastMessageTime(now);
    setCooldownRemaining(serverCooldown);

    // Check for chat commands
    if (appState.currentView === 'server') {
      const cmd = parseCommand(content);
      if (cmd) {
        const error = await executeCommand(cmd.command, cmd.args);
        if (error) {
          // Show error as a system-like message inline
          try {
            if (appState.currentChannelId) {
              await addDoc(collection(db, 'messages'), {
                content: `⚠️ ${error}`,
                senderId: 'system',
                senderName: 'System',
                senderAvatar: '',
                channelId: appState.currentChannelId,
                serverId: appState.currentServerId,
                type: 'system',
                mediaUrl: '',
                createdAt: Date.now(),
                reactions: {},
              });
            }
          } catch (err) {
            console.error('Failed to send command error:', err);
          }
        }
        return;
      }
    }

    const replyRef = appState.replyingTo;
    setReplyingTo(null);

    try {
      if (appState.currentView === 'server' && appState.currentChannelId) {
        await addDoc(collection(db, 'messages'), {
          content,
          senderId: user.id,
          senderName: user.displayName,
          senderAvatar: user.avatar || '',
          senderGradient: user.gradient || '',
          channelId: appState.currentChannelId,
          serverId: appState.currentServerId,
          type: 'text',
          mediaUrl: '',
          createdAt: Date.now(),
          replyTo: replyRef || null,
          reactions: {},
        });

        // Check for @mentions and replies - send notifications
        if (appState.currentServerId) {
          const mentionRegex = /@(\w+)/g;
          let match;
          while ((match = mentionRegex.exec(content)) !== null) {
            const mentionedName = match[1];
            const mentionedMember = serverMembers.find(m =>
              m.username.toLowerCase() === mentionedName.toLowerCase() ||
              m.displayName.toLowerCase() === mentionedName.toLowerCase()
            );
            if (mentionedMember && mentionedMember.id !== user.id) {
              incrementNotification(mentionedMember.id, appState.currentServerId, 'server');
            }
          }
          // Reply notification
          if (replyRef && replyRef.senderId !== user.id) {
            incrementNotification(replyRef.senderId, appState.currentServerId, 'server');
          }
        }
      } else if (appState.currentView === 'dm' && appState.currentDMConversationId) {
        await addDoc(collection(db, 'dmMessages'), {
          content,
          senderId: user.id,
          senderName: user.displayName,
          senderAvatar: user.avatar || '',
          senderGradient: user.gradient || '',
          conversationId: appState.currentDMConversationId,
          type: 'text',
          mediaUrl: '',
          createdAt: Date.now(),
          replyTo: replyRef || null,
          reactions: {},
        });

        // DM notification for reply
        if (replyRef && replyRef.senderId !== user.id) {
          incrementNotification(replyRef.senderId, appState.currentDMConversationId, 'dm');
        }
      }
    } catch (err) {
      console.error('Failed to send message:', err);
    }
  };

  const sendMediaMessage = async () => {
    if (!user || !mediaUrl.trim()) return;
    const url = mediaUrl.trim();
    setMediaUrl('');
    setShowMediaUpload(false);

    const mediaType = detectMediaType(url);
    const replyRef = appState.replyingTo;
    setReplyingTo(null);

    try {
      if (appState.currentView === 'server' && appState.currentChannelId) {
        await addDoc(collection(db, 'messages'), {
          content: url,
          senderId: user.id,
          senderName: user.displayName,
          senderAvatar: user.avatar || '',
          senderGradient: user.gradient || '',
          channelId: appState.currentChannelId,
          serverId: appState.currentServerId,
          type: mediaType || 'text',
          mediaUrl: url,
          createdAt: Date.now(),
          replyTo: replyRef || null,
          reactions: {},
        });
      } else if (appState.currentView === 'dm' && appState.currentDMConversationId) {
        await addDoc(collection(db, 'dmMessages'), {
          content: url,
          senderId: user.id,
          senderName: user.displayName,
          senderAvatar: user.avatar || '',
          senderGradient: user.gradient || '',
          conversationId: appState.currentDMConversationId,
          type: mediaType || 'text',
          mediaUrl: url,
          createdAt: Date.now(),
          replyTo: replyRef || null,
          reactions: {},
        });
      }
    } catch (err) {
      console.error('Failed to send media message:', err);
    }
  };

  const handleEditMessage = async (messageId: string) => {
    const msg = messages.find(m => m.id === messageId);
    if (msg) {
      setEditingMessage(messageId, msg.content);
    }
  };

  const saveEditMessage = async () => {
    if (!appState.editingMessageId || !appState.editingMessageContent.trim()) return;
    const collectionName = appState.currentView === 'server' ? 'messages' : 'dmMessages';
    try {
      await updateDoc(doc(db, collectionName, appState.editingMessageId), {
        content: appState.editingMessageContent.trim().substring(0, MAX_MESSAGE_LENGTH),
        editedAt: Date.now(),
      });
    } catch (err) {
      console.error('Failed to edit message:', err);
    }
    setEditingMessage(null, '');
  };

  const handleDeleteMessage = async (messageId: string) => {
    showConfirmDialog('Delete Message', 'Are you sure you want to delete this message? This cannot be undone.', async () => {
      const collectionName = appState.currentView === 'server' ? 'messages' : 'dmMessages';
      try {
        await deleteDoc(doc(db, collectionName, messageId));
      } catch (err) {
        console.error('Failed to delete message:', err);
      }
    });
  };

  const handlePinMessage = async (messageId: string) => {
    const collectionName = appState.currentView === 'server' ? 'messages' : 'dmMessages';
    const msg = messages.find(m => m.id === messageId);
    try {
      await updateDoc(doc(db, collectionName, messageId), { pinned: !msg?.pinned });
    } catch (err) {
      console.error('Failed to pin message:', err);
    }
  };

  const handleToggleReaction = async (messageId: string, emoji: string) => {
    if (!user) return;
    const collectionName = appState.currentView === 'server' ? 'messages' : 'dmMessages';
    const msg = messages.find(m => m.id === messageId);
    if (!msg) return;

    const reactions = { ...(msg.reactions || {}) };
    const userIds = reactions[emoji] || [];

    if (userIds.includes(user.id)) {
      // Remove reaction
      const filtered = userIds.filter(id => id !== user.id);
      if (filtered.length === 0) {
        delete reactions[emoji];
      } else {
        reactions[emoji] = filtered;
      }
    } else {
      // Add reaction
      reactions[emoji] = [...userIds, user.id];
    }

    try {
      await updateDoc(doc(db, collectionName, messageId), { reactions });
    } catch (err) {
      console.error('Failed to toggle reaction:', err);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (appState.editingMessageId) {
        saveEditMessage();
      } else {
        sendMessage();
      }
    }
    // Shift+Enter naturally adds a newline in textarea
    if (e.key === 'Escape') {
      setEditingMessage(null, '');
      setReplyingTo(null);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    if (value.length > MAX_MESSAGE_LENGTH) return; // Enforce max length
    setInputValue(value);

    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 5 * 24) + 'px'; // max ~5 lines

    const lastAtIndex = value.lastIndexOf('@');
    if (lastAtIndex !== -1) {
      const textAfterAt = value.substring(lastAtIndex + 1);
      if (!textAfterAt.includes(' ') && textAfterAt.length <= 20) {
        setMentionFilter(textAfterAt.toLowerCase());
        setMentionStartIndex(lastAtIndex);
        setShowMentionList(true);
      } else {
        setShowMentionList(false);
      }
    } else {
      setShowMentionList(false);
    }
  };

  const selectMention = (member: {id: string; displayName: string; username: string}) => {
    if (mentionStartIndex === -1) return;
    const before = inputValue.substring(0, mentionStartIndex);
    setInputValue(`${before}@${member.displayName} `);
    setShowMentionList(false);
    setMentionStartIndex(-1);
    inputRef.current?.focus();
  };

  const handleMediaClick = (url: string, type: 'image' | 'video') => {
    setMediaViewer(url, type);
  };

  const insertEmoji = (emoji: string) => {
    setInputValue(prev => (prev + emoji + ' ').substring(0, MAX_MESSAGE_LENGTH));
    // Don't close emoji picker when inserting
    inputRef.current?.focus();
  };

  const insertCustomEmoji = (emoji: CustomEmoji) => {
    setInputValue(prev => (prev + `:${emoji.name}: `).substring(0, MAX_MESSAGE_LENGTH));
    // Don't close emoji picker when inserting
    inputRef.current?.focus();
  };

  const getChannelIcon = (channel: Channel) => {
    const iconType = channel.iconType || (channel.type === 'announcement' ? 'announcement' : channel.type === 'forum' ? 'forum' : channel.type === 'rules' ? 'rules' : 'default');
    switch (iconType) {
      case 'announcement': return <svg className="w-5 h-5 mr-2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.73 21a2 2 0 0 1-3.46 0" /></svg>;
      case 'forum': return <svg className="w-5 h-5 mr-2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="13" y2="13" /></svg>;
      case 'rules': return <svg className="w-5 h-5 mr-2 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="8" y1="13" x2="16" y2="13" /><line x1="8" y1="17" x2="13" y2="17" /></svg>;
      default: return <Hash className="w-5 h-5 mr-2 text-gray-400" />;
    }
  };

  const header = useMemo(() => {
    if (appState.currentView === 'server' && currentChannel) {
      return { icon: getChannelIcon(currentChannel), title: currentChannel.name, subtitle: '' };
    }
    if (appState.currentView === 'dm' && appState.currentDMConversationId && dmOtherUser) {
      return {
        icon: <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-xs text-white font-semibold mr-2">{dmOtherUser.displayName[0]}</div>,
        title: dmOtherUser.displayName,
        subtitle: dmOtherUser.status === 'online' ? 'Online' : dmOtherUser.status === 'idle' ? 'Idle' : 'Offline',
      };
    }
    if (appState.currentView === 'friends') {
      return { icon: <Users className="w-5 h-5 mr-2 text-gray-400" />, title: 'Friends', subtitle: '' };
    }
    if (appState.currentView === 'discover') {
      return { icon: <Hash className="w-5 h-5 mr-2 text-gray-400" />, title: 'Discover', subtitle: '' };
    }
    return { icon: null, title: 'Dialogue', subtitle: '' };
  }, [appState, currentChannel, dmOtherUser]);

  const showInput = (appState.currentView === 'server' && appState.currentChannelId) ||
                    (appState.currentView === 'dm' && appState.currentDMConversationId);

  const mentionSuggestions = useMemo(() => {
    if (!mentionFilter) return serverMembers.slice(0, 8);
    return serverMembers.filter(m =>
      m.displayName.toLowerCase().includes(mentionFilter) ||
      m.username.toLowerCase().includes(mentionFilter)
    ).slice(0, 8);
  }, [mentionFilter, serverMembers]);

  const isEditing = !!appState.editingMessageId;
  const isOnCooldown = cooldownRemaining > 0;
  const charCount = (isEditing ? appState.editingMessageContent : inputValue).length;

  return (
    <div className="flex-1 flex flex-col bg-[#313338] min-w-0">
      {/* Header */}
      <div className="h-12 px-4 flex items-center border-b border-[#1E1F22] shrink-0">
        {header.icon}
        <span className="font-semibold text-white">{header.title}</span>
        {header.subtitle && <span className="text-xs text-gray-400 ml-2">{header.subtitle}</span>}
      </div>

      {/* No permission check */}
      {appState.currentView === 'server' && !canReadMessages && currentChannel && (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center px-8">
            <div className="w-16 h-16 rounded-full bg-[#3F4147] flex items-center justify-center mx-auto mb-4">
              <Hash className="w-8 h-8 text-gray-500" />
            </div>
            <p className="text-lg font-semibold text-gray-300 mb-1">No Access</p>
            <p className="text-sm text-gray-500">You don&apos;t have permission to read messages in #{currentChannel.name}</p>
          </div>
        </div>
      )}

      {/* Messages */}
      <div className={`flex-1 overflow-y-auto ${!canReadMessages && appState.currentView === 'server' ? 'hidden' : ''}`} style={{ scrollbarWidth: 'thin', scrollbarColor: '#1E1F22 transparent' }}>
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <div className="text-4xl mb-2">👋</div>
              <p className="text-lg font-medium">No messages yet</p>
              <p className="text-sm">Be the first to say something!</p>
            </div>
          </div>
        )}
        {messages.map((msg) => (
          <MessageItem
            key={msg.id}
            message={msg}
            onMediaClick={handleMediaClick}
            onReply={() => setReplyingTo({
              messageId: msg.id,
              senderId: msg.senderId,
              senderName: msg.senderName,
              content: msg.content.substring(0, 100),
            })}
            onEdit={() => handleEditMessage(msg.id)}
            onDelete={() => handleDeleteMessage(msg.id)}
            onPin={canPin ? () => handlePinMessage(msg.id) : undefined}
            canEditOthers={canEditOthers}
            canDeleteOthers={canDeleteOthers}
            canPin={canPin}
            isOwn={msg.senderId === user?.id}
            members={serverMembers}
            allMessages={messages}
            customEmojis={customEmojis}
            onUsernameClick={setShowProfileUserId}
            onToggleReaction={handleToggleReaction}
            onReactToMessage={() => {}}
            currentUser={user ? { id: user.id, dialoguePlus: user.dialoguePlus } : null}
          />
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input - hidden if no read permission */}
      {showInput && canReadMessages && (
        <div className="px-4 pb-6 pt-0 shrink-0">
          {/* Reply bar */}
          {appState.replyingTo && !isEditing && (
            <div className="bg-[#2B2D31] rounded-t-lg px-4 py-2 flex items-center justify-between border border-b-0 border-[#3F4147]">
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Reply className="w-4 h-4" />
                <span>Replying to <span className="text-[#C9CDFB] font-medium">{appState.replyingTo.senderName}</span></span>
              </div>
              <button onClick={() => setReplyingTo(null)} className="text-gray-400 hover:text-gray-200 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Edit bar */}
          {isEditing && (
            <div className="bg-[#2B2D31] rounded-t-lg px-4 py-2 flex items-center justify-between border border-b-0 border-[#3F4147]">
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Pencil className="w-4 h-4" />
                <span>Editing message</span>
              </div>
              <button onClick={() => setEditingMessage(null, '')} className="text-gray-400 hover:text-gray-200 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className={`bg-[#383A40] ${appState.replyingTo || isEditing ? 'rounded-b-lg' : 'rounded-lg'} flex items-center px-4 relative`}>
            {/* Media upload button */}
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-200 shrink-0 h-10 w-10 cursor-pointer" onClick={() => setShowMediaUpload(true)}>
              <ImageIcon className="w-5 h-5" />
            </Button>

            {/* Emoji picker button */}
            <Popover open={showEmojiPicker} onOpenChange={setShowEmojiPicker}>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-200 shrink-0 h-10 w-10 cursor-pointer">
                  <Smile className="w-5 h-5" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 border-none shadow-none bg-transparent" align="start" side="top">
                <EmojiPicker
                  onEmojiSelect={insertEmoji}
                  customEmojis={customEmojis}
                  onClose={() => setShowEmojiPicker(false)}
                  showServerTab={true}
                />
              </PopoverContent>
            </Popover>

            <textarea
              ref={inputRef}
              value={isEditing ? appState.editingMessageContent : inputValue}
              onChange={(e) => {
                if (isEditing) {
                  const val = e.target.value;
                  if (val.length <= MAX_MESSAGE_LENGTH) {
                    setEditingMessage(appState.editingMessageId, val);
                  }
                } else {
                  handleInputChange(e);
                }
              }}
              onKeyDown={handleKeyDown}
              placeholder={
                isEditing ? 'Edit your message...' :
                isTimedOut && appState.currentView === 'server' ? 'You are timed out' :
                !canSendMessages && appState.currentView === 'server' ? 'You don\'t have permission to send messages' :
                isOnCooldown ? 'Slow down! Wait for cooldown...' :
                appState.currentView === 'server' ? `Message #${currentChannel?.name || ''}` : 'Message'
              }
              className="flex-1 bg-transparent text-gray-100 placeholder-gray-500 outline-none py-2.5 text-[15px] resize-none overflow-y-auto"
              disabled={(!canSendMessages && appState.currentView === 'server' && !isEditing) || isOnCooldown || (!!isTimedOut && appState.currentView === 'server')}
              maxLength={MAX_MESSAGE_LENGTH}
              rows={1}
              style={{ minHeight: '24px', maxHeight: '120px' }}
            />

            {/* Character count and cooldown indicator */}
            <div className="flex items-center gap-2 shrink-0">
              {charCount > 400 && (
                <span className={`text-[10px] ${charCount >= 490 ? 'text-red-400' : charCount >= 450 ? 'text-yellow-400' : 'text-gray-500'}`}>
                  {charCount}/{MAX_MESSAGE_LENGTH}
                </span>
              )}
              {isOnCooldown && !isEditing && (
                <div className="flex items-center text-yellow-400 text-[10px]">
                  <Clock className="w-3 h-3 mr-0.5" />
                  <span>{Math.ceil(cooldownRemaining / 1000)}s</span>
                </div>
              )}
            </div>

            {/* Mention autocomplete dropdown */}
            {showMentionList && mentionSuggestions.length > 0 && appState.currentView === 'server' && (
              <div className="absolute bottom-full left-0 right-0 mb-1 bg-[#2B2D31] border border-[#3F4147] rounded-lg shadow-xl overflow-hidden z-20">
                <div className="text-xs text-gray-400 px-3 py-1.5 uppercase font-semibold">Members</div>
                {mentionSuggestions.map(member => (
                  <button
                    key={member.id}
                    onClick={() => selectMention(member)}
                    className="w-full flex items-center gap-2 px-3 py-1.5 hover:bg-[#35373C] text-left cursor-pointer"
                  >
                    <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-xs font-semibold shrink-0">
                      {member.displayName[0]?.toUpperCase()}
                    </div>
                    <div>
                      <div className="text-sm text-white">{member.displayName}</div>
                      <div className="text-[10px] text-gray-400">@{member.username}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}

            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-gray-200 shrink-0 h-10 w-10 cursor-pointer"
              onClick={isEditing ? saveEditMessage : sendMessage}
              disabled={isEditing ? !appState.editingMessageContent.trim() : !inputValue.trim() || isOnCooldown}
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      )}

      {/* Media Upload Dialog */}
      <Dialog open={showMediaUpload} onOpenChange={setShowMediaUpload}>
        <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Link className="w-5 h-5" /> Share Media
            </DialogTitle>
            <DialogDescription className="text-gray-400">Paste a link to an image or video to share in chat</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              value={mediaUrl}
              onChange={(e) => setMediaUrl(e.target.value)}
              className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
              placeholder="https://example.com/image.png or data:image/png;base64,..."
              onKeyDown={(e) => { if (e.key === 'Enter' && mediaUrl.trim()) sendMediaMessage(); }}
            />
            {mediaUrl && (
              <div className="bg-[#2B2D31] rounded-lg p-2">
                {detectMediaType(mediaUrl) === 'image' && (
                  <img src={mediaUrl} alt="Preview" className="max-w-full max-h-40 rounded object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                )}
                {detectMediaType(mediaUrl) === 'video' && (
                  <video src={mediaUrl} className="max-w-full max-h-40 rounded" preload="metadata" />
                )}
                {detectMediaType(mediaUrl) === null && (
                  <span className="text-gray-400 text-sm">Link will be shared as text</span>
                )}
              </div>
            )}
            <Button onClick={sendMediaMessage} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={!mediaUrl.trim()}>
              <Send className="w-4 h-4 mr-2" /> Send Media
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// hasPermission is now imported from @/lib/types
