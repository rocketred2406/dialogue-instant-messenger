'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { Server, Role, CustomEmoji, Category, Channel, ALL_PERMISSIONS, hasPermission } from '@/lib/types';
import { doc, onSnapshot, setDoc, deleteDoc, updateDoc, arrayRemove, addDoc, collection, query, where, writeBatch } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Trash2, Shield, LogOut, Smile, Rocket, UserPlus, X as XIcon, Users, ChevronDown, GripVertical, Pencil, Hash, Megaphone, MessageSquare, FileText } from 'lucide-react';

export default function ServerSettings() {
  const { user } = useAuth();
  const { appState, setShowServerSettings, setCurrentServerId, showConfirmDialog } = useApp();
  const [server, setServer] = useState<Server | null>(null);
  const [serverName, setServerName] = useState('');
  const [serverIcon, setServerIcon] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [maxMembers, setMaxMembers] = useState(100);
  const [roles, setRoles] = useState<Role[]>([]);
  const [newRoleName, setNewRoleName] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  // Emoji management
  const [newEmojiName, setNewEmojiName] = useState('');
  const [newEmojiUrl, setNewEmojiUrl] = useState('');

  // Discover image, message cooldown, and bio for servers
  const [discoverImage, setDiscoverImage] = useState('');
  const [messageCooldown, setMessageCooldown] = useState(1);
  const [serverBio, setServerBio] = useState('');

  // Category management
  const [categories, setCategories] = useState<Category[]>([]);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Channel management
  const [channels, setChannels] = useState<Channel[]>([]);
  const [editingChannelId, setEditingChannelId] = useState<string | null>(null);
  const [editingChannelName, setEditingChannelName] = useState('');

  // Category editing
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editingCatName, setEditingCatName] = useState('');

  // Role drag-and-drop
  const [roleDragIndex, setRoleDragIndex] = useState<number | null>(null);
  const [roleDragOverIndex, setRoleDragOverIndex] = useState<number | null>(null);

  // Category drag-and-drop
  const [catDragIndex, setCatDragIndex] = useState<number | null>(null);
  const [catDragOverIndex, setCatDragOverIndex] = useState<number | null>(null);

  useEffect(() => {
    if (!appState.currentServerId) return;
    const unsub = onSnapshot(doc(db, 'servers', appState.currentServerId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        const s = { id: snap.id, ...data, dialogueBoost: isBoost } as Server;
        setServer(s);
        setServerName(s.name);
        setServerIcon(s.icon);
        setIsPublic(s.isPublic);
        setMaxMembers(s.maxMembers);
        setRoles(s.roles || []);
        setDiscoverImage(s.discoverImage || '');
        setMessageCooldown(Math.round((s.messageCooldown || 1000) / 1000));
        setServerBio(s.bio || '');
        setCategories(s.categories || []);
      }
    });
    return () => unsub();
  }, [appState.currentServerId]);

  // Listen for channels
  useEffect(() => {
    if (!appState.currentServerId) return;
    const q = query(collection(db, 'channels'), where('serverId', '==', appState.currentServerId));
    const unsub = onSnapshot(q, (snapshot) => {
      const channelList: Channel[] = [];
      snapshot.forEach((d) => {
        channelList.push({ id: d.id, ...d.data() } as Channel);
      });
      channelList.sort((a, b) => {
        if (a.order !== undefined && b.order !== undefined) return a.order - b.order;
        if (a.order !== undefined) return -1;
        if (b.order !== undefined) return 1;
        return a.createdAt - b.createdAt;
      });
      setChannels(channelList);
    });
    return () => unsub();
  }, [appState.currentServerId]);

  const canManage = user?.isAdmin || server?.ownerId === user?.id;
  const canManageRoles = canManage || hasPermission(server, user, 'manage_roles');
  const canManageEmojis = canManage || hasPermission(server, user, 'manage_emojis');

  const handleSaveGeneral = async () => {
    if (!server || !canManage) return;
    setIsSaving(true);
    try {
      await setDoc(doc(db, 'servers', server.id), {
        name: serverName,
        icon: serverIcon,
        isPublic,
        maxMembers,
        bio: serverBio,
        discoverImage: server.dialogueBoost ? discoverImage : '',
        messageCooldown: Math.max(1, messageCooldown) * 1000,
      }, { merge: true });
    } catch (err) {
      console.error('Failed to save server settings:', err);
    }
    setIsSaving(false);
  };

  const handleSaveRoles = async () => {
    if (!server || !canManage) return;
    setIsSaving(true);
    try {
      await setDoc(doc(db, 'servers', server.id), { roles }, { merge: true });
    } catch (err) {
      console.error('Failed to save roles:', err);
    }
    setIsSaving(false);
  };

  const addRole = () => {
    if (!newRoleName.trim()) return;
    setRoles([...roles, {
      id: `role_${Date.now()}`,
      name: newRoleName.trim(),
      color: '#5865F2',
      permissions: ['send_messages', 'read_messages'],
    }]);
    setNewRoleName('');
  };

  const removeRole = (roleId: string) => {
    setRoles(roles.filter(r => r.id !== roleId));
  };

  const updateRoleColor = (roleId: string, color: string) => {
    setRoles(roles.map(r => r.id === roleId ? { ...r, color } : r));
  };

  const updateRoleName = (roleId: string, name: string) => {
    setRoles(roles.map(r => r.id === roleId ? { ...r, name } : r));
  };

  const togglePermission = (roleId: string, permission: string) => {
    setRoles(roles.map(r => {
      if (r.id !== roleId) return r;
      const perms = r.permissions.includes(permission)
        ? r.permissions.filter(p => p !== permission)
        : [...r.permissions, permission];
      return { ...r, permissions: perms };
    }));
  };

  // Role drag-and-drop handlers
  const handleRoleDragStart = (index: number) => {
    setRoleDragIndex(index);
  };

  const handleRoleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setRoleDragOverIndex(index);
  };

  const handleRoleDragEnd = () => {
    setRoleDragIndex(null);
    setRoleDragOverIndex(null);
  };

  const handleRoleDrop = async (dropIndex: number) => {
    if (roleDragIndex === null || roleDragIndex === dropIndex) {
      handleRoleDragEnd();
      return;
    }
    const newRoles = [...roles];
    const [dragged] = newRoles.splice(roleDragIndex, 1);
    newRoles.splice(dropIndex, 0, dragged);
    setRoles(newRoles);
    // Save immediately to Firestore
    try {
      await setDoc(doc(db, 'servers', server!.id), { roles: newRoles }, { merge: true });
    } catch (err) {
      console.error('Failed to reorder roles:', err);
    }
    handleRoleDragEnd();
  };

  // Category management
  const addCategory = async () => {
    if (!newCategoryName.trim() || !server) return;
    const newCat: Category = {
      id: `cat_${Date.now()}`,
      name: newCategoryName.trim(),
      serverId: server.id,
      order: categories.length,
    };
    const updatedCategories = [...categories, newCat];
    setCategories(updatedCategories);
    setNewCategoryName('');
    try {
      await setDoc(doc(db, 'servers', server.id), { categories: updatedCategories }, { merge: true });
    } catch (err) {
      console.error('Failed to add category:', err);
    }
  };

  const removeCategory = async (catId: string) => {
    if (!server) return;
    const updatedCategories = categories.filter(c => c.id !== catId);
    // Re-index order values
    for (let i = 0; i < updatedCategories.length; i++) {
      updatedCategories[i].order = i;
    }
    setCategories(updatedCategories);
    try {
      await setDoc(doc(db, 'servers', server.id), { categories: updatedCategories }, { merge: true });
    } catch (err) {
      console.error('Failed to remove category:', err);
    }
  };

  const updateCategoryName = async (catId: string, name: string) => {
    if (!server) return;
    const updatedCategories = categories.map(c => c.id === catId ? { ...c, name } : c);
    setCategories(updatedCategories);
    try {
      await setDoc(doc(db, 'servers', server.id), { categories: updatedCategories }, { merge: true });
    } catch (err) {
      console.error('Failed to update category:', err);
    }
  };

  // Category drag-and-drop
  const handleCatDragStart = (index: number) => {
    setCatDragIndex(index);
  };

  const handleCatDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setCatDragOverIndex(index);
  };

  const handleCatDragEnd = () => {
    setCatDragIndex(null);
    setCatDragOverIndex(null);
  };

  const handleCatDrop = async (dropIndex: number) => {
    if (catDragIndex === null || catDragIndex === dropIndex) {
      handleCatDragEnd();
      return;
    }
    const newCats = [...categories];
    const [dragged] = newCats.splice(catDragIndex, 1);
    newCats.splice(dropIndex, 0, dragged);
    // Re-index
    for (let i = 0; i < newCats.length; i++) {
      newCats[i].order = i;
    }
    setCategories(newCats);
    try {
      await setDoc(doc(db, 'servers', server!.id), { categories: newCats }, { merge: true });
    } catch (err) {
      console.error('Failed to reorder categories:', err);
    }
    handleCatDragEnd();
  };

  // Channel management
  const handleDeleteChannel = async (channelId: string, channelName: string) => {
    showConfirmDialog('Delete Channel', `Are you sure you want to delete #${channelName}? This cannot be undone.`, async () => {
      try {
        await deleteDoc(doc(db, 'channels', channelId));
      } catch (err) {
        console.error('Failed to delete channel:', err);
      }
    });
  };

  const handleRenameChannel = async (channelId: string) => {
    if (!editingChannelName.trim()) {
      setEditingChannelId(null);
      return;
    }
    try {
      await updateDoc(doc(db, 'channels', channelId), {
        name: editingChannelName.trim().toLowerCase().replace(/\s+/g, '-'),
      });
    } catch (err) {
      console.error('Failed to rename channel:', err);
    }
    setEditingChannelId(null);
    setEditingChannelName('');
  };

  const handleLeaveServer = async () => {
    if (!server || !user) return;
    try {
      await updateDoc(doc(db, 'servers', server.id), {
        members: arrayRemove(user.id),
      });
      setCurrentServerId(null);
      setShowServerSettings(false);
    } catch (err) {
      console.error('Failed to leave server:', err);
    }
  };

  const handleDeleteServer = async () => {
    if (!server || !canManage) return;
    showConfirmDialog('Delete Server', 'Are you sure you want to delete this server? This action cannot be undone.', async () => {
      try {
        await deleteDoc(doc(db, 'servers', server.id));
        setCurrentServerId(null);
        setShowServerSettings(false);
      } catch (err) {
        console.error('Failed to delete server:', err);
      }
    });
  };

  const handleAddEmoji = async () => {
    if (!server || !newEmojiName.trim() || !newEmojiUrl.trim()) return;
    const newEmoji: CustomEmoji = {
      id: `emoji_${Date.now()}`,
      name: newEmojiName.trim().replace(/\s+/g, '_').toLowerCase(),
      imageUrl: newEmojiUrl.trim(),
      createdBy: user?.id || '',
      createdAt: Date.now(),
    };
    try {
      const updatedEmojis = [...(server.customEmojis || []), newEmoji];
      await setDoc(doc(db, 'servers', server.id), { customEmojis: updatedEmojis }, { merge: true });
      setNewEmojiName('');
      setNewEmojiUrl('');
    } catch (err) {
      console.error('Failed to add emoji:', err);
    }
  };

  const handleDeleteEmoji = async (emojiId: string) => {
    if (!server) return;
    try {
      const updatedEmojis = (server.customEmojis || []).filter(e => e.id !== emojiId);
      await setDoc(doc(db, 'servers', server.id), { customEmojis: updatedEmojis }, { merge: true });
    } catch (err) {
      console.error('Failed to delete emoji:', err);
    }
  };

  // Channel type icon helper
  const getChannelTypeIcon = (channel: Channel) => {
    const iconType = channel.iconType || (channel.type === 'announcement' ? 'announcement' : channel.type === 'forum' ? 'forum' : 'default');
    switch (iconType) {
      case 'announcement': return <Megaphone className="w-4 h-4 text-gray-400" />;
      case 'forum': return <MessageSquare className="w-4 h-4 text-gray-400" />;
      default: return <Hash className="w-4 h-4 text-gray-400" />;
    }
  };

  const getChannelCategoryName = (channel: Channel) => {
    if (!channel.categoryId) return 'Uncategorized';
    const cat = categories.find(c => c.id === channel.categoryId);
    return cat?.name || 'Uncategorized';
  };

  if (!appState.currentServerId) return null;

  return (
    <Dialog open={appState.showServerSettings} onOpenChange={setShowServerSettings}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white text-xl flex items-center gap-2">
            Server Settings
            {server?.dialogueBoost && (
              <span className="text-xs font-semibold bg-gradient-to-r from-[#5865F2] to-[#EB459E] bg-clip-text text-transparent flex items-center gap-0.5">
                <Rocket className="w-3 h-3 text-yellow-400" /> Dialogue Boost
              </span>
            )}
          </DialogTitle>
          <DialogDescription className="text-gray-400">{server?.name || 'Server'} settings and management</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="general" className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="bg-[#2B2D31] w-full justify-start rounded-none border-b border-[#3F4147] flex-wrap">
            <TabsTrigger value="general" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">General</TabsTrigger>
            <TabsTrigger value="channels" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Channels</TabsTrigger>
            <TabsTrigger value="roles" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Roles</TabsTrigger>
            <TabsTrigger value="categories" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Categories</TabsTrigger>
            {server?.dialogueBoost && canManageEmojis && (
              <TabsTrigger value="emojis" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
                <Smile className="w-3 h-3 mr-1" /> Emojis
              </TabsTrigger>
            )}
            {canManage && (
              <TabsTrigger value="danger" className="text-red-400 data-[state=active]:bg-red-900/30 data-[state=active]:text-red-300 cursor-pointer">Danger Zone</TabsTrigger>
            )}
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#1E1F22 transparent' }}>
            <TabsContent value="general" className="space-y-4 mt-0">
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Server Name</Label>
                <Input value={serverName} onChange={(e) => setServerName(e.target.value)} className="bg-[#1E1F22] border-[#3F4147] text-gray-100" disabled={!canManage} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Server Icon URL</Label>
                <Input value={serverIcon} onChange={(e) => setServerIcon(e.target.value)} className="bg-[#1E1F22] border-[#3F4147] text-gray-100" disabled={!canManage} />
                {serverIcon && (
                  <div className="relative w-16 h-16 mt-2">
                    <img src={serverIcon} alt="Preview" className="w-16 h-16 rounded-xl object-cover" />
                  </div>
                )}
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Server Bio</Label>
                <textarea
                  value={serverBio}
                  onChange={(e) => setServerBio(e.target.value)}
                  className="w-full bg-[#1E1F22] border border-[#3F4147] rounded-md px-3 py-2 text-gray-100 outline-none focus:border-[#5865F2] text-sm min-h-[60px] resize-y"
                  placeholder="Describe your server..."
                  maxLength={200}
                  disabled={!canManage}
                />
                <p className="text-[10px] text-gray-500 text-right">{serverBio.length}/200</p>
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Max Members</Label>
                <Input type="number" value={maxMembers} onChange={(e) => setMaxMembers(parseInt(e.target.value) || 100)} className="bg-[#1E1F22] border-[#3F4147] text-gray-100" disabled={!canManage} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1">
                  Message Cooldown (seconds)
                  <span className="text-gray-500 text-[10px] font-normal">min 1s</span>
                </Label>
                <Input
                  type="number"
                  value={messageCooldown}
                  onChange={(e) => setMessageCooldown(Math.max(1, parseInt(e.target.value) || 1))}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  min={1}
                  disabled={!canManage}
                />
                <p className="text-xs text-gray-500">Minimum time between messages. Cannot be less than 1 second.</p>
              </div>
              {/* Discover Image - Dialogue Boost only */}
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1">
                  Discover Page Image URL
                  {!server?.dialogueBoost && <span className="text-yellow-400 text-[10px]">(Dialogue Boost only)</span>}
                </Label>
                <Input
                  value={discoverImage}
                  onChange={(e) => setDiscoverImage(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="https://example.com/banner.jpg"
                  disabled={!server?.dialogueBoost || !canManage}
                />
                {server?.dialogueBoost && discoverImage && (
                  <div className="relative w-full h-20 rounded-lg overflow-hidden mt-1">
                    <img src={discoverImage} alt="Discover preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
              {canManage && (
                <Button onClick={handleSaveGeneral} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSaving}>
                  {isSaving ? 'Saving...' : 'Save Changes'}
                </Button>
              )}
            </TabsContent>

            {/* Channels Management Tab */}
            <TabsContent value="channels" className="space-y-4 mt-0">
              <div className="space-y-2">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">
                  All Channels — {channels.length}
                </div>
                {channels.length === 0 && (
                  <div className="text-center py-6 text-gray-500 text-sm">
                    No channels yet. Create one from the channel sidebar.
                  </div>
                )}
                {channels.map((channel) => (
                  <div key={channel.id} className="flex items-center gap-2 bg-[#2B2D31] rounded-lg p-3 group border border-transparent hover:border-[#3F4147]">
                    {getChannelTypeIcon(channel)}
                    {editingChannelId === channel.id ? (
                      <div className="flex-1 flex items-center gap-2">
                        <Input
                          value={editingChannelName}
                          onChange={(e) => setEditingChannelName(e.target.value)}
                          className="bg-[#1E1F22] border-[#3F4147] text-gray-100 h-7 text-sm flex-1"
                          onKeyDown={(e) => e.key === 'Enter' && handleRenameChannel(channel.id)}
                          autoFocus
                        />
                        <Button
                          size="sm"
                          onClick={() => handleRenameChannel(channel.id)}
                          className="bg-[#5865F2] hover:bg-[#4752C4] text-white h-7 text-xs cursor-pointer"
                        >
                          Save
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => { setEditingChannelId(null); setEditingChannelName(''); }}
                          className="text-gray-400 hover:text-white h-7 text-xs cursor-pointer"
                        >
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <>
                        <span className="text-sm text-gray-200 flex-1">#{channel.name}</span>
                        <span className="text-xs text-gray-500">{channel.type}</span>
                        <span className="text-[10px] text-gray-600 bg-[#1E1F22] px-1.5 py-0.5 rounded">{getChannelCategoryName(channel)}</span>
                        {canManage && (
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => { setEditingChannelId(channel.id); setEditingChannelName(channel.name); }}
                              className="p-1 text-gray-400 hover:text-white cursor-pointer"
                              title="Rename"
                            >
                              <Pencil className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => handleDeleteChannel(channel.id, channel.name)}
                              className="p-1 text-gray-400 hover:text-red-400 cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="roles" className="space-y-4 mt-0">
              {(canManage || canManageRoles) && (
                <div className="flex gap-2">
                  <Input
                    value={newRoleName}
                    onChange={(e) => setNewRoleName(e.target.value)}
                    className="bg-[#1E1F22] border-[#3F4147] text-gray-100 flex-1"
                    placeholder="New role name"
                    onKeyDown={(e) => e.key === 'Enter' && addRole()}
                  />
                  <Button onClick={addRole} className="bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer">
                    <Plus className="w-4 h-4 mr-1" /> Add
                  </Button>
                </div>
              )}
              <p className="text-xs text-gray-500">Drag to reorder. Higher roles (shown first) take priority.</p>
              {roles.map((role, index) => (
                <div
                  key={role.id}
                  draggable={canManage || canManageRoles}
                  onDragStart={(canManage || canManageRoles) ? () => handleRoleDragStart(index) : undefined}
                  onDragOver={(canManage || canManageRoles) ? (e) => handleRoleDragOver(e, index) : undefined}
                  onDragEnd={(canManage || canManageRoles) ? handleRoleDragEnd : undefined}
                  onDrop={(canManage || canManageRoles) ? () => handleRoleDrop(index) : undefined}
                  className={`transition-all ${
                    roleDragIndex === index ? 'opacity-50' : ''
                  } ${
                    roleDragOverIndex === index && roleDragIndex !== index ? 'border-t-2 border-[#5865F2]' : ''
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {(canManage || canManageRoles) && (
                      <div className="pt-4 cursor-grab active:cursor-grabbing text-gray-500 hover:text-gray-300">
                        <GripVertical className="w-4 h-4" />
                      </div>
                    )}
                    <div className="flex-1">
                      <RoleCard
                        role={role}
                        server={server!}
                        canManage={canManage || canManageRoles}
                        onUpdateRoleName={updateRoleName}
                        onUpdateRoleColor={updateRoleColor}
                        onTogglePermission={togglePermission}
                        onRemoveRole={removeRole}
                      />
                    </div>
                  </div>
                </div>
              ))}
              {(canManage || canManageRoles) && (
                <Button onClick={handleSaveRoles} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSaving}>
                  {isSaving ? 'Saving...' : 'Save Roles'}
                </Button>
              )}
            </TabsContent>

            {/* Categories Tab */}
            <TabsContent value="categories" className="space-y-4 mt-0">
              <div className="bg-[#2B2D31] rounded-lg p-4">
                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <ChevronDown className="w-4 h-4" /> Custom Categories
                </h3>
                <p className="text-xs text-gray-400 mb-3">
                  Create custom categories to organize your channels. Drag to reorder.
                  Channels without a category go into &quot;Uncategorized&quot;.
                </p>

                {(canManage) && (
                  <div className="flex gap-2 mb-4">
                    <Input
                      value={newCategoryName}
                      onChange={(e) => setNewCategoryName(e.target.value)}
                      className="bg-[#1E1F22] border-[#3F4147] text-gray-100 flex-1 h-8"
                      placeholder="New category name"
                      onKeyDown={(e) => e.key === 'Enter' && addCategory()}
                    />
                    <Button onClick={addCategory} className="bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer h-8" size="sm">
                      <Plus className="w-3 h-3 mr-1" /> Add
                    </Button>
                  </div>
                )}

                <div className="space-y-2">
                  {categories.sort((a, b) => a.order - b.order).map((cat, index) => (
                    <div
                      key={cat.id}
                      draggable={canManage && editingCatId !== cat.id}
                      onDragStart={canManage ? () => handleCatDragStart(index) : undefined}
                      onDragOver={canManage ? (e) => handleCatDragOver(e, index) : undefined}
                      onDragEnd={canManage ? handleCatDragEnd : undefined}
                      onDrop={canManage ? () => handleCatDrop(index) : undefined}
                      className={`flex items-center gap-2 bg-[#1E1F22] rounded-lg p-3 group transition-all ${
                        catDragIndex === index ? 'opacity-50' : ''
                      } ${
                        catDragOverIndex === index && catDragIndex !== index ? 'border-t-2 border-[#5865F2]' : ''
                      }`}
                    >
                      {canManage && editingCatId !== cat.id && (
                        <div className="cursor-grab active:cursor-grabbing text-gray-500 hover:text-gray-300">
                          <GripVertical className="w-4 h-4" />
                        </div>
                      )}
                      <ChevronDown className="w-3 h-3 text-gray-400 shrink-0" />
                      {editingCatId === cat.id ? (
                        <Input
                          value={editingCatName}
                          onChange={(e) => setEditingCatName(e.target.value)}
                          className="bg-[#2B2D31] border-[#3F4147] text-gray-100 flex-1 h-7 text-xs"
                          autoFocus
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              updateCategoryName(cat.id, editingCatName);
                              setEditingCatId(null);
                            }
                            if (e.key === 'Escape') {
                              setEditingCatId(null);
                            }
                          }}
                          onBlur={() => {
                            if (editingCatName.trim()) {
                              updateCategoryName(cat.id, editingCatName);
                            }
                            setEditingCatId(null);
                          }}
                        />
                      ) : (
                        <span className="text-[11px] font-semibold text-gray-300 uppercase tracking-wide flex-1">{cat.name}</span>
                      )}
                      <span className="text-[10px] text-gray-500">{channels.filter(c => c.categoryId === cat.id).length} channels</span>
                      {canManage && editingCatId !== cat.id && (
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => { setEditingCatId(cat.id); setEditingCatName(cat.name); }}
                            className="p-0.5 text-gray-400 hover:text-white cursor-pointer"
                            title="Rename"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => removeCategory(cat.id)}
                            className="p-0.5 text-gray-400 hover:text-red-400 cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {categories.length === 0 && (
                  <div className="text-center py-6 text-gray-500 text-sm">
                    No custom categories yet. Channels will be grouped by type.
                  </div>
                )}
              </div>
            </TabsContent>

            {server?.dialogueBoost && canManageEmojis && (
              <TabsContent value="emojis" className="space-y-4 mt-0">
                <div className="bg-[#2B2D31] rounded-lg p-4">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Smile className="w-4 h-4" /> Custom Emojis
                  </h3>
                  <p className="text-xs text-gray-400 mb-3">Add custom emojis that can be used in this server with :emoji_name:</p>

                  <div className="space-y-2 mb-4">
                    <Input
                      value={newEmojiName}
                      onChange={(e) => setNewEmojiName(e.target.value)}
                      className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                      placeholder="Emoji name (e.g., cool_face)"
                    />
                    <Input
                      value={newEmojiUrl}
                      onChange={(e) => setNewEmojiUrl(e.target.value)}
                      className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                      placeholder="Image URL for emoji"
                    />
                    {newEmojiUrl && (
                      <div className="flex items-center gap-2 mt-1">
                        <img src={newEmojiUrl} alt="Preview" className="w-10 h-10 object-contain rounded bg-[#1E1F22] p-1" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                        <span className="text-sm text-gray-400">:{newEmojiName || 'name'}:</span>
                      </div>
                    )}
                    <Button onClick={handleAddEmoji} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={!newEmojiName.trim() || !newEmojiUrl.trim()}>
                      <Plus className="w-4 h-4 mr-1" /> Add Emoji
                    </Button>
                  </div>

                  <Separator className="bg-[#3F4147] my-3" />

                  <div className="grid grid-cols-4 gap-2">
                    {(server.customEmojis || []).map(emoji => (
                      <div key={emoji.id} className="bg-[#1E1F22] rounded-lg p-2 flex flex-col items-center gap-1 group relative">
                        <img src={emoji.imageUrl} alt={emoji.name} className="w-10 h-10 object-contain" />
                        <span className="text-[10px] text-gray-400 truncate">:{emoji.name}:</span>
                        <button
                          onClick={() => handleDeleteEmoji(emoji.id)}
                          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-400 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {(!server.customEmojis || server.customEmojis.length === 0) && (
                    <div className="text-center py-6 text-gray-500 text-sm">
                      No custom emojis yet. Add one above!
                    </div>
                  )}
                </div>
              </TabsContent>
            )}

            {canManage && (
              <TabsContent value="danger" className="space-y-4 mt-0">
                <div className="bg-red-900/20 border border-red-800 rounded-lg p-4">
                  <h3 className="text-red-300 font-semibold mb-2">Delete Server</h3>
                  <p className="text-red-400/70 text-sm mb-3">This will permanently delete this server and all its data. This action cannot be undone.</p>
                  <Button variant="destructive" onClick={handleDeleteServer} className="cursor-pointer">Delete Server</Button>
                </div>
              </TabsContent>
            )}
          </div>
        </Tabs>

        {!canManage && (
          <div className="mt-4 pt-4 border-t border-[#3F4147]">
            <Button variant="outline" onClick={handleLeaveServer} className="w-full border-red-500/50 text-red-400 hover:bg-red-900/20 hover:text-red-300 cursor-pointer">
              <LogOut className="w-4 h-4 mr-2" /> Leave Server
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// RoleCard component with member assignment
function RoleCard({ role, server, canManage, onUpdateRoleName, onUpdateRoleColor, onTogglePermission, onRemoveRole }: {
  role: Role;
  server: Server;
  canManage: boolean;
  onUpdateRoleName: (roleId: string, name: string) => void;
  onUpdateRoleColor: (roleId: string, color: string) => void;
  onTogglePermission: (roleId: string, permission: string) => void;
  onRemoveRole: (roleId: string) => void;
}) {
  const { user, allUsers, updateUser } = useAuth();
  const [showMemberManager, setShowMemberManager] = useState(false);
  const [showAddMember, setShowAddMember] = useState(false);

  // Get members with this role
  const membersWithRole = allUsers.filter(u =>
    u.memberRoleIds?.[server.id]?.includes(role.id)
  );

  // Get server members without this role
  const serverMembers = allUsers.filter(u =>
    server.members?.includes(u.id)
  );
  const availableMembers = serverMembers.filter(u =>
    !u.memberRoleIds?.[server.id]?.includes(role.id)
  );

  const handleAddMember = async (memberId: string) => {
    const member = allUsers.find(u => u.id === memberId);
    if (!member) return;
    const currentRoleIds = member.memberRoleIds?.[server.id] || [];
    const updatedMemberRoleIds = {
      ...(member.memberRoleIds || {}),
      [server.id]: [...currentRoleIds, role.id],
    };
    try {
      await setDoc(doc(db, 'users', memberId), { memberRoleIds: updatedMemberRoleIds }, { merge: true });
    } catch (err) {
      console.error('Failed to assign role:', err);
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    const member = allUsers.find(u => u.id === memberId);
    if (!member) return;
    const currentRoleIds = member.memberRoleIds?.[server.id] || [];
    const updatedMemberRoleIds = {
      ...(member.memberRoleIds || {}),
      [server.id]: currentRoleIds.filter(id => id !== role.id),
    };
    try {
      await setDoc(doc(db, 'users', memberId), { memberRoleIds: updatedMemberRoleIds }, { merge: true });
    } catch (err) {
      console.error('Failed to remove role from member:', err);
    }
  };

  return (
    <div className="bg-[#2B2D31] rounded-lg p-4">
      <div className="flex items-center gap-3 mb-3">
        <div className="w-4 h-4 rounded-full shrink-0" style={{ backgroundColor: role.color }} />
        {canManage ? (
          <>
            <Input
              value={role.name}
              onChange={(e) => onUpdateRoleName(role.id, e.target.value)}
              className="bg-[#1E1F22] border-[#3F4147] text-gray-100 flex-1 h-8"
            />
            <input
              type="color"
              value={role.color}
              onChange={(e) => onUpdateRoleColor(role.id, e.target.value)}
              className="w-8 h-8 rounded cursor-pointer bg-transparent border-none"
            />
            <Button variant="ghost" size="icon" onClick={() => onRemoveRole(role.id)} className="text-gray-400 hover:text-red-400 h-8 w-8 cursor-pointer">
              <Trash2 className="w-4 h-4" />
            </Button>
          </>
        ) : (
          <>
            <Shield className="w-4 h-4" style={{ color: role.color }} />
            <span className="text-gray-200 flex-1">{role.name}</span>
          </>
        )}
      </div>
      {canManage && (
        <div className="grid grid-cols-2 gap-2">
          {ALL_PERMISSIONS.map((perm) => (
            <label key={perm} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
              <input
                type="checkbox"
                checked={role.permissions.includes(perm)}
                onChange={() => onTogglePermission(role.id, perm)}
                className="rounded border-gray-600 accent-[#5865F2]"
              />
              <span className="text-xs">{perm.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
            </label>
          ))}
        </div>
      )}

      {/* Role Members Section */}
      <div className="mt-3 pt-3 border-t border-[#3F4147]">
        <button
          className="flex items-center justify-between w-full text-sm text-gray-300 hover:text-white cursor-pointer"
          onClick={() => setShowMemberManager(!showMemberManager)}
        >
          <span className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5" />
            Members with this role ({membersWithRole.length})
          </span>
          <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showMemberManager ? 'rotate-180' : ''}`} />
        </button>
        {showMemberManager && (
          <div className="mt-2 space-y-2">
            {membersWithRole.map(member => (
              <div key={member.id} className="flex items-center gap-2 py-1 px-2 rounded bg-[#1E1F22]">
                <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-[10px] font-semibold shrink-0 overflow-hidden">
                  {member.avatar ? (
                    <img src={member.avatar} alt="" className="w-full h-full object-cover rounded-full" />
                  ) : (
                    member.displayName[0]?.toUpperCase() || '?'
                  )}
                </div>
                <span className="text-sm text-gray-200 flex-1 truncate">{member.displayName}</span>
                {canManage && (
                  <button
                    onClick={() => handleRemoveMember(member.id)}
                    className="text-gray-500 hover:text-red-400 cursor-pointer shrink-0"
                    title="Remove from role"
                  >
                    <XIcon className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
            {membersWithRole.length === 0 && (
              <div className="text-xs text-gray-500 py-1.5 text-center">No members with this role</div>
            )}
            {canManage && availableMembers.length > 0 && (
              <div className="mt-2">
                {showAddMember ? (
                  <div className="space-y-1">
                    <div className="text-xs text-gray-400 mb-1">Add member to role:</div>
                    {availableMembers.slice(0, 10).map(member => (
                      <button
                        key={member.id}
                        onClick={() => { handleAddMember(member.id); }}
                        className="w-full flex items-center gap-2 py-1.5 px-2 rounded hover:bg-[#35373C] text-left cursor-pointer"
                      >
                        <div className="w-5 h-5 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-[8px] font-semibold shrink-0 overflow-hidden">
                          {member.avatar ? (
                            <img src={member.avatar} alt="" className="w-full h-full object-cover rounded-full" />
                          ) : (
                            member.displayName[0]?.toUpperCase() || '?'
                          )}
                        </div>
                        <span className="text-sm text-gray-200 truncate">{member.displayName}</span>
                      </button>
                    ))}
                    <button
                      onClick={() => setShowAddMember(false)}
                      className="text-xs text-gray-500 hover:text-gray-300 cursor-pointer"
                    >Cancel</button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowAddMember(true)}
                    className="w-full border-[#3F4147] text-gray-300 hover:text-white hover:bg-[#35373C] cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5 mr-1" /> Add Member
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
