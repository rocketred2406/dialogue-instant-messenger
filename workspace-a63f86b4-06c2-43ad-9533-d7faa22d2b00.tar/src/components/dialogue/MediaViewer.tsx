'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useApp } from '@/contexts/AppContext';
import { X, ZoomIn, ZoomOut, RotateCcw, Maximize, Minimize } from 'lucide-react';
import { Button } from '@/components/ui/button';

function MediaViewerContent({ url, type, onClose }: { url: string; type: 'image' | 'video'; onClose: () => void }) {
  const [zoom, setZoom] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const handleZoomIn = useCallback(() => {
    setZoom(prev => Math.min(prev + 0.25, 5));
  }, []);

  const handleZoomOut = useCallback(() => {
    setZoom(prev => Math.max(prev - 0.25, 0.25));
  }, []);

  const handleResetZoom = useCallback(() => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === '+' || e.key === '=') handleZoomIn();
      if (e.key === '-') handleZoomOut();
      if (e.key === '0') handleResetZoom();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, handleZoomIn, handleZoomOut, handleResetZoom]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setZoom(prev => Math.min(Math.max(prev + delta, 0.25), 5));
  }, []);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (zoom > 1) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  }, [zoom, pan]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (isDragging && zoom > 1) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  }, [isDragging, zoom, dragStart]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const toggleFullscreen = useCallback(() => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  }, []);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 bg-black/90 flex flex-col"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      {/* Top Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#1E1F22] shrink-0">
        <div className="text-gray-300 text-sm truncate">
          {type === 'image' ? 'Image Viewer' : 'Video Player'}
        </div>
        <div className="flex items-center gap-1">
          {type === 'image' && (
            <>
              <Button variant="ghost" size="icon" onClick={handleZoomOut} className="text-gray-300 hover:text-white hover:bg-[#313338] h-8 w-8">
                <ZoomOut className="w-4 h-4" />
              </Button>
              <span className="text-gray-400 text-xs min-w-[3rem] text-center">{Math.round(zoom * 100)}%</span>
              <Button variant="ghost" size="icon" onClick={handleZoomIn} className="text-gray-300 hover:text-white hover:bg-[#313338] h-8 w-8">
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleResetZoom} className="text-gray-300 hover:text-white hover:bg-[#313338] h-8 w-8">
                <RotateCcw className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={toggleFullscreen} className="text-gray-300 hover:text-white hover:bg-[#313338] h-8 w-8">
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </Button>
            </>
          )}
          <Button variant="ghost" size="icon" onClick={onClose} className="text-gray-300 hover:text-white hover:bg-[#313338] h-8 w-8">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Media Content */}
      <div
        className="flex-1 flex items-center justify-center overflow-hidden"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ cursor: zoom > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
      >
        {type === 'image' ? (
          <img
            src={url}
            alt="Media viewer"
            className="max-w-full max-h-full object-contain select-none"
            style={{
              transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`,
              transition: isDragging ? 'none' : 'transform 0.1s ease-out',
            }}
            draggable={false}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center p-8">
            <video
              src={url}
              controls
              autoPlay
              className="max-w-full max-h-full rounded-lg"
              style={{ width: '100%', maxWidth: '1200px' }}
            >
              Your browser does not support the video tag.
            </video>
          </div>
        )}
      </div>

      {/* Bottom hint for images */}
      {type === 'image' && (
        <div className="px-4 py-2 bg-[#1E1F22] text-center shrink-0">
          <span className="text-gray-500 text-xs">Scroll to zoom · Drag to pan · Press 0 to reset · ESC to close</span>
        </div>
      )}
    </div>
  );
}

export default function MediaViewer() {
  const { appState, closeMediaViewer } = useApp();

  if (!appState.showMediaViewer) return null;

  return (
    <MediaViewerContent
      key={appState.mediaViewerUrl}
      url={appState.mediaViewerUrl}
      type={appState.mediaViewerType}
      onClose={closeMediaViewer}
    />
  );
}
