'use client';

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { ALL_PERMISSIONS } from '@/lib/types';
import { addDoc, collection, doc, setDoc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2 } from 'lucide-react';

const ROLE_COLORS = [
  '#5865F2', '#57F287', '#FEE75C', '#EB459E', '#ED4245',
  '#F47B67', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5',
];

interface RoleForm {
  name: string;
  color: string;
  permissions: string[];
}

export default function CreateServerModal() {
  const { user } = useAuth();
  const { appState, setShowCreateServer, setCurrentServerId } = useApp();
  const [step, setStep] = useState(1);
  const [serverName, setServerName] = useState('');
  const [serverIcon, setServerIcon] = useState('');
  const [isPublic, setIsPublic] = useState(true);
  const [maxMembers, setMaxMembers] = useState(100);
  const [serverBio, setServerBio] = useState('');
  const [roles, setRoles] = useState<RoleForm[]>([
    { name: 'Admin', color: '#ED4245', permissions: [...ALL_PERMISSIONS] },
    { name: 'Moderator', color: '#57F287', permissions: ['send_messages', 'read_messages', 'kick_members', 'edit_messages', 'delete_messages', 'pin_messages', 'move_channels'] },
    { name: 'Member', color: '#5865F2', permissions: ['send_messages', 'read_messages'] },
  ]);
  const [isCreating, setIsCreating] = useState(false);

  // Fetch maxUsers from config collection
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const configDoc = await getDoc(doc(db, 'config', 'maxUsers'));
        if (configDoc.exists()) {
          const maxUsers = configDoc.data().value;
          if (typeof maxUsers === 'number' && maxUsers > 0) {
            setMaxMembers(maxUsers);
          }
        }
      } catch (err) {
        console.error('Failed to fetch config:', err);
      }
    };
    fetchConfig();
  }, []);

  const addRole = () => {
    setRoles([...roles, { name: '', color: ROLE_COLORS[roles.length % ROLE_COLORS.length], permissions: ['send_messages', 'read_messages'] }]);
  };

  const removeRole = (index: number) => {
    setRoles(roles.filter((_, i) => i !== index));
  };

  const updateRole = (index: number, field: keyof RoleForm, value: string | string[]) => {
    const updated = [...roles];
    updated[index] = { ...updated[index], [field]: value };
    setRoles(updated);
  };

  const togglePermission = (roleIndex: number, permission: string) => {
    const updated = [...roles];
    const perms = updated[roleIndex].permissions;
    if (perms.includes(permission)) {
      updated[roleIndex].permissions = perms.filter(p => p !== permission);
    } else {
      updated[roleIndex].permissions = [...perms, permission];
    }
    setRoles(updated);
  };

  const handleCreate = async () => {
    if (!user || !serverName.trim()) return;
    setIsCreating(true);
    try {
      const serverId = await addDoc(collection(db, 'servers'), {
        name: serverName.trim(),
        icon: serverIcon.trim(),
        ownerId: user.id,
        roles: roles.map((r, i) => ({
          id: `role_${i}`,
          name: r.name || `Role ${i + 1}`,
          color: r.color,
          permissions: r.permissions,
        })),
        members: [user.id],
        maxMembers,
        isPublic,
        createdAt: Date.now(),
        dialogueBoost: false, // RENAMED from dialoguePlus
        customEmojis: [],
        messageCooldown: 1000, // Default 1 second
        bio: serverBio.trim(),
        categories: [],
      });

      // Create default general channel
      await addDoc(collection(db, 'channels'), {
        name: 'general',
        type: 'text',
        serverId: serverId.id,
        createdAt: Date.now(),
        permissions: { _default: ['send_messages', 'read_messages'] },
        order: 0,
      });

      // Update user's server list
      const updatedServerIds = [...(user.serverIds || []), serverId.id];
      await setDoc(doc(db, 'users', user.id), { serverIds: updatedServerIds }, { merge: true });

      setCurrentServerId(serverId.id);
      setShowCreateServer(false);
      setStep(1);
      setServerName('');
      setServerIcon('');
      setRoles([
        { name: 'Admin', color: '#ED4245', permissions: [...ALL_PERMISSIONS] },
        { name: 'Moderator', color: '#57F287', permissions: ['send_messages', 'read_messages', 'kick_members', 'edit_messages', 'delete_messages', 'pin_messages', 'move_channels'] },
        { name: 'Member', color: '#5865F2', permissions: ['send_messages', 'read_messages'] },
      ]);
    } catch (err) {
      console.error('Failed to create server:', err);
    }
    setIsCreating(false);
  };

  return (
    <Dialog open={appState.showCreateServer} onOpenChange={setShowCreateServer}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">
            {step === 1 ? 'Create Your Server' : 'Set Up Roles'}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            {step === 1 ? 'Give your new server a personality with a name and an icon.' : 'Define roles and their permissions for your server.'}
          </DialogDescription>
        </DialogHeader>

        {step === 1 ? (
          <div className="space-y-4 mt-2">
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase text-gray-300">Server Name</Label>
              <Input
                value={serverName}
                onChange={(e) => setServerName(e.target.value)}
                className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                placeholder="My Awesome Server"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase text-gray-300">Server Icon URL</Label>
              <Input
                value={serverIcon}
                onChange={(e) => setServerIcon(e.target.value)}
                className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                placeholder="https://example.com/icon.png"
              />
              {serverIcon && (
                <div className="relative w-16 h-16 mt-2">
                  <img src={serverIcon} alt="Preview" className="w-16 h-16 rounded-xl object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase text-gray-300">Server Bio</Label>
              <textarea
                value={serverBio}
                onChange={(e) => setServerBio(e.target.value)}
                className="w-full bg-[#1E1F22] border border-[#3F4147] rounded-md px-3 py-2 text-gray-100 outline-none focus:border-[#5865F2] text-sm min-h-[60px] resize-y"
                placeholder="Describe your server..."
                maxLength={200}
              />
              <p className="text-[10px] text-gray-500 text-right">{serverBio.length}/200</p>
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-xs font-bold uppercase text-gray-300">Public Server</Label>
              <Switch checked={isPublic} onCheckedChange={setIsPublic} />
            </div>
            {isPublic && (
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Max Members</Label>
                <Input
                  type="number"
                  value={maxMembers}
                  onChange={(e) => setMaxMembers(parseInt(e.target.value) || 100)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  min={1}
                />
              </div>
            )}
            <Button onClick={() => setStep(2)} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={!serverName.trim()}>
              Next: Set Up Roles
            </Button>
          </div>
        ) : (
          <div className="space-y-4 mt-2">
            {roles.map((role, index) => (
              <div key={index} className="bg-[#2B2D31] rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-4 h-4 rounded-full shrink-0" style={{ backgroundColor: role.color }} />
                  <Input
                    value={role.name}
                    onChange={(e) => updateRole(index, 'name', e.target.value)}
                    className="bg-[#1E1F22] border-[#3F4147] text-gray-100 flex-1 h-8"
                    placeholder="Role name"
                  />
                  <input
                    type="color"
                    value={role.color}
                    onChange={(e) => updateRole(index, 'color', e.target.value)}
                    className="w-8 h-8 rounded cursor-pointer bg-transparent border-none"
                  />
                  <Button variant="ghost" size="icon" onClick={() => removeRole(index)} className="text-gray-400 hover:text-red-400 h-8 w-8 cursor-pointer">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {ALL_PERMISSIONS.map((perm) => (
                    <label key={perm} className="flex items-center gap-2 text-sm text-gray-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={role.permissions.includes(perm)}
                        onChange={() => togglePermission(index, perm)}
                        className="rounded border-gray-600 accent-[#5865F2]"
                      />
                      <span className="text-xs">{perm.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <Button variant="outline" onClick={addRole} className="w-full border-[#3F4147] text-gray-300 hover:text-white hover:bg-[#35373C] cursor-pointer">
              <Plus className="w-4 h-4 mr-2" /> Add Role
            </Button>
            <Separator className="bg-[#3F4147]" />
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)} className="flex-1 border-[#3F4147] text-gray-300 hover:text-white hover:bg-[#35373C] cursor-pointer">
                Back
              </Button>
              <Button onClick={handleCreate} className="flex-1 bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isCreating}>
                {isCreating ? 'Creating...' : 'Create Server'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
