'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { User, Server } from '@/lib/types';
import { onSnapshot, doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Crown, Shield, Clock } from 'lucide-react';
import Image from 'next/image';

function MemberListContent({ serverId }: { serverId: string }) {
  const { user } = useAuth();
  const { setShowProfileUserId } = useApp();
  const [server, setServer] = useState<Server | null>(null);
  const [members, setMembers] = useState<User[]>([]);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, 'servers', serverId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        // Backwards compatibility
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        setServer({ id: snap.id, ...data, dialogueBoost: isBoost } as Server);
      }
    });
    return () => unsub();
  }, [serverId]);

  useEffect(() => {
    if (!server?.members?.length) return;
    const fetchMembers = async () => {
      const memberList: User[] = [];
      for (const memberId of server.members!) {
        try {
          const userDoc = await getDoc(doc(db, 'users', memberId));
          if (userDoc.exists()) {
            memberList.push({ id: userDoc.id, ...userDoc.data() } as User);
          }
        } catch (e) {
          console.error('Failed to fetch member:', e);
        }
      }
      memberList.sort((a, b) => {
        if (a.id === server.ownerId) return -1;
        if (b.id === server.ownerId) return 1;
        if (a.status === 'online' && b.status !== 'online') return -1;
        if (b.status === 'online' && a.status !== 'online') return 1;
        if (a.status === 'idle' && b.status === 'offline') return -1;
        if (b.status === 'idle' && a.status === 'offline') return 1;
        return a.displayName.localeCompare(b.displayName);
      });
      setMembers(memberList);
    };
    fetchMembers();
    const interval = setInterval(fetchMembers, 15000);
    return () => clearInterval(interval);
  }, [server]);

  if (!server) return null;

  const now = Date.now();
  const isTimedOut = (member: User) => member.timeoutUntil && member.timeoutUntil > now;

  const onlineMembers = members.filter(m => m.status === 'online' || m.status === 'idle');
  const offlineMembers = members.filter(m => m.status === 'offline');

  return (
    <div className="w-60 bg-[#2B2D31] shrink-0 overflow-hidden flex flex-col">
      <ScrollArea className="flex-1">
        <div className="p-3">
          {onlineMembers.length > 0 && (
            <>
              <div className="text-[11px] font-semibold text-gray-400 uppercase tracking-wide mb-2 px-1">
                Online — {onlineMembers.length}
              </div>
              {onlineMembers.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center px-1 py-1.5 rounded hover:bg-[#35373C] cursor-pointer group"
                  onClick={() => setShowProfileUserId(member.id)}
                >
                  <div className="relative w-8 h-8 mr-3 shrink-0">
                    {member.avatar ? (
                      <Image src={member.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-xs font-semibold">
                        {member.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#2B2D31] ${
                      member.status === 'online' ? 'bg-[#23A559]' : 'bg-yellow-500'
                    }`} />
                  </div>
                  <span
                    className={`text-sm text-gray-200 group-hover:text-white truncate flex-1 ${member.gradient && member.dialoguePlus ? 'gradient-username' : ''}`}
                    style={member.gradient && member.dialoguePlus ? { backgroundImage: member.gradient } : {}}
                  >
                    {member.displayName}
                  </span>
                  {isTimedOut(member) && (
                    <Clock className="w-3 h-3 text-yellow-500 ml-1 shrink-0" title="Timed out" />
                  )}
                  {member.id === server?.ownerId && <Crown className="w-3.5 h-3.5 text-yellow-500 ml-1 shrink-0" />}
                  {member.isAdmin && member.id !== server?.ownerId && <Shield className="w-3.5 h-3.5 text-red-400 ml-1 shrink-0" />}
                </div>
              ))}
            </>
          )}

          {offlineMembers.length > 0 && (
            <>
              <div className="text-[11px] font-semibold text-gray-400 uppercase tracking-wide mb-2 mt-4 px-1">
                Offline — {offlineMembers.length}
              </div>
              {offlineMembers.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center px-1 py-1.5 rounded hover:bg-[#35373C] cursor-pointer group opacity-50"
                  onClick={() => setShowProfileUserId(member.id)}
                >
                  <div className="relative w-8 h-8 mr-3 shrink-0">
                    {member.avatar ? (
                      <Image src={member.avatar} alt="" width={32} height={32} className="rounded-full object-cover grayscale" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-white text-xs font-semibold">
                        {member.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#2B2D31] bg-gray-500" />
                  </div>
                  <span
                    className={`text-sm text-gray-400 group-hover:text-gray-200 truncate flex-1 ${member.gradient && member.dialoguePlus ? 'gradient-username' : ''}`}
                    style={member.gradient && member.dialoguePlus ? { backgroundImage: member.gradient } : {}}
                  >
                    {member.displayName}
                  </span>
                  {isTimedOut(member) && (
                    <Clock className="w-3 h-3 text-yellow-500 ml-1 shrink-0" title="Timed out" />
                  )}
                  {member.id === server?.ownerId && <Crown className="w-3.5 h-3.5 text-yellow-500 ml-1 shrink-0" />}
                </div>
              ))}
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

export default function MemberList() {
  const { appState } = useApp();

  if (appState.currentView !== 'server' || !appState.currentServerId) {
    return null;
  }

  return <MemberListContent key={appState.currentServerId} serverId={appState.currentServerId} />;
}
