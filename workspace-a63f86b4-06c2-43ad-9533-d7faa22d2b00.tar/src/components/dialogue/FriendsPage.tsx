'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { User, FriendRequest, DMConversation } from '@/lib/types';
import {
  collection, onSnapshot, query, where, doc, getDoc, setDoc,
  addDoc, updateDoc, deleteDoc, getDocs,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { UserPlus, UserCheck, UserX, MessageCircle, Search, Users } from 'lucide-react';
import Image from 'next/image';

export default function FriendsPage() {
  const { user, updateUser } = useAuth();
  const { setCurrentDMConversationId, setCurrentView, showConfirmDialog } = useApp();
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [friends, setFriends] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sendingRequest, setSendingRequest] = useState<string | null>(null);

  // Fetch all users
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
      const users: User[] = [];
      snapshot.forEach((d) => {
        users.push({ id: d.id, ...d.data() } as User);
      });
      setAllUsers(users);
    });
    return () => unsub();
  }, []);

  // Get online friends (online or idle)

  // Fetch friend requests
  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'friendRequests'), where('toId', '==', user.id));
    const unsub = onSnapshot(q, (snapshot) => {
      const requests: FriendRequest[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        if (data.status === 'pending') {
          requests.push({ id: d.id, ...data } as FriendRequest);
        }
      });
      setFriendRequests(requests);
    });
    return () => unsub();
  }, [user]);

  // Fetch sent friend requests
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  useEffect(() => {
    if (!user) return;
    const q = query(
      collection(db, 'friendRequests'),
      where('fromId', '==', user.id),
      where('status', '==', 'pending')
    );
    const unsub = onSnapshot(q, (snapshot) => {
      const requests: FriendRequest[] = [];
      snapshot.forEach((d) => {
        requests.push({ id: d.id, ...d.data() } as FriendRequest);
      });
      setSentRequests(requests);
    });
    return () => unsub();
  }, [user]);

  // Fetch friends
  useEffect(() => {
    if (!user?.friends?.length) {
      setFriends([]);
      return;
    }
    const fetchFriends = async () => {
      const friendList: User[] = [];
      for (const friendId of user.friends!) {
        try {
          const userDoc = await getDoc(doc(db, 'users', friendId));
          if (userDoc.exists()) {
            friendList.push({ id: userDoc.id, ...userDoc.data() } as User);
          }
        } catch (e) {
          console.error('Failed to fetch friend:', e);
        }
      }
      setFriends(friendList);
    };
    fetchFriends();
  }, [user?.friends]);

  const sendFriendRequest = async (toUser: User) => {
    if (!user || toUser.id === user.id) return;
    if (user.friends?.includes(toUser.id)) return;
    if (sentRequests.some(r => r.toId === toUser.id)) return;
    if (friendRequests.some(r => r.fromId === toUser.id)) return;

    setSendingRequest(toUser.id);
    try {
      await addDoc(collection(db, 'friendRequests'), {
        fromId: user.id,
        fromName: user.displayName,
        toId: toUser.id,
        toName: toUser.displayName,
        status: 'pending',
        createdAt: Date.now(),
      });
    } catch (err) {
      console.error('Failed to send friend request:', err);
    }
    setSendingRequest(null);
  };

  const acceptFriendRequest = async (request: FriendRequest) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'friendRequests', request.id), { status: 'accepted' });
      const userFriends = [...(user.friends || []), request.fromId];
      await setDoc(doc(db, 'users', user.id), { friends: userFriends }, { merge: true });
      const fromUserDoc = await getDoc(doc(db, 'users', request.fromId));
      const fromFriends = fromUserDoc.exists() ? [...(fromUserDoc.data().friends || []), user.id] : [user.id];
      await setDoc(doc(db, 'users', request.fromId), { friends: fromFriends }, { merge: true });
      await updateUser({ friends: userFriends });
    } catch (err) {
      console.error('Failed to accept friend request:', err);
    }
  };

  const rejectFriendRequest = async (request: FriendRequest) => {
    try {
      await deleteDoc(doc(db, 'friendRequests', request.id));
    } catch (err) {
      console.error('Failed to reject friend request:', err);
    }
  };

  const startDM = async (otherUser: User) => {
    if (!user) return;
    const q = query(collection(db, 'dmConversations'), where('participants', 'array-contains', user.id));
    const snapshot = await getDocs(q);
    let existingConvoId: string | null = null;
    snapshot.forEach((d) => {
      const data = d.data();
      if (data.participants.includes(otherUser.id)) {
        existingConvoId = d.id;
      }
    });
    if (existingConvoId) {
      setCurrentDMConversationId(existingConvoId);
      setCurrentView('dm');
      return;
    }
    const docRef = await addDoc(collection(db, 'dmConversations'), {
      participants: [user.id, otherUser.id],
      createdAt: Date.now(),
    });
    setCurrentDMConversationId(docRef.id);
    setCurrentView('dm');
  };

  const removeFriend = async (friendId: string) => {
    if (!user) return;
    showConfirmDialog('Remove Friend', 'Are you sure you want to remove this friend?', async () => {
      try {
        const userFriends = (user.friends || []).filter(id => id !== friendId);
        await setDoc(doc(db, 'users', user.id), { friends: userFriends }, { merge: true });
        const friendDoc = await getDoc(doc(db, 'users', friendId));
        if (friendDoc.exists()) {
          const friendFriends = (friendDoc.data().friends || []).filter(id => id !== user.id);
          await setDoc(doc(db, 'users', friendId), { friends: friendFriends }, { merge: true });
        }
        await updateUser({ friends: userFriends });
      } catch (err) {
        console.error('Failed to remove friend:', err);
      }
    });
  };

  const nonFriendUsers = allUsers.filter(u =>
    u.id !== user?.id &&
    !user?.friends?.includes(u.id) &&
    !sentRequests.some(r => r.toId === u.id) &&
    (u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="flex-1 bg-[#313338] flex flex-col">
      {/* Header */}
      <div className="h-12 px-4 flex items-center border-b border-[#1E1F22] shrink-0">
        <Users className="w-5 h-5 mr-2 text-gray-400" />
        <span className="font-semibold text-white">Friends</span>
        <Separator orientation="vertical" className="h-6 mx-4 bg-[#3F4147]" />
        {friendRequests.length > 0 && (
          <span className="text-sm text-red-400 font-medium">{friendRequests.length} pending request{friendRequests.length > 1 ? 's' : ''}</span>
        )}
      </div>

      <Tabs defaultValue="online" className="flex-1 flex flex-col">
        <div className="px-4 pt-4 shrink-0">
          <TabsList className="bg-[#2B2D31] w-full justify-start">
            <TabsTrigger value="online" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Online</TabsTrigger>
            <TabsTrigger value="all" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">All Friends</TabsTrigger>
            <TabsTrigger value="pending" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Pending</TabsTrigger>
            <TabsTrigger value="add" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">Add Friend</TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="flex-1">
          <TabsContent value="online" className="p-4 mt-0">
            {friends.filter(f => f.status === 'online' || f.status === 'idle').length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p>No friends online right now</p>
              </div>
            ) : (
              friends.filter(f => f.status === 'online' || f.status === 'idle').map(friend => (
                <div key={friend.id} className="flex items-center px-3 py-2 rounded hover:bg-[#35373C] group">
                  <div className="relative w-8 h-8 mr-3">
                    {friend.avatar ? (
                      <Image src={friend.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-sm font-semibold">
                        {friend.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#313338] bg-[#23A559]" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div
                      className="text-sm font-medium text-white"
                      style={friend.gradient && friend.dialoguePlus ? { backgroundImage: friend.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
                    >
                      {friend.displayName}
                    </div>
                    <div className="text-xs text-gray-400">@{friend.username}</div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" onClick={() => startDM(friend)} className="text-gray-400 hover:text-white h-8 w-8 cursor-pointer">
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="all" className="p-4 mt-0">
            {friends.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <UserCheck className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p>You haven&apos;t added any friends yet</p>
              </div>
            ) : (
              friends.map(friend => (
                <div key={friend.id} className="flex items-center px-3 py-2 rounded hover:bg-[#35373C] group">
                  <div className="relative w-8 h-8 mr-3">
                    {friend.avatar ? (
                      <Image src={friend.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-sm font-semibold">
                        {friend.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#313338] ${
                      friend.status === 'online' ? 'bg-[#23A559]' : friend.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div
                      className="text-sm font-medium text-white"
                      style={friend.gradient && friend.dialoguePlus ? { backgroundImage: friend.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
                    >
                      {friend.displayName}
                    </div>
                    <div className="text-xs text-gray-400">@{friend.username}</div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button variant="ghost" size="icon" onClick={() => startDM(friend)} className="text-gray-400 hover:text-white h-8 w-8 cursor-pointer">
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => removeFriend(friend.id)} className="text-gray-400 hover:text-red-400 h-8 w-8 cursor-pointer">
                      <UserX className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="pending" className="p-4 mt-0">
            {friendRequests.length === 0 && sentRequests.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <UserPlus className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p>No pending friend requests</p>
              </div>
            ) : (
              <>
                {friendRequests.length > 0 && (
                  <>
                    <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 px-3">
                      Incoming Requests — {friendRequests.length}
                    </div>
                    {friendRequests.map(request => (
                      <div key={request.id} className="flex items-center px-3 py-2 rounded hover:bg-[#35373C] group">
                        <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-sm font-semibold mr-3">
                          {request.fromName[0].toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-white">{request.fromName}</div>
                          <div className="text-xs text-gray-400">Incoming Friend Request</div>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button size="sm" onClick={() => acceptFriendRequest(request)} className="bg-[#23A559] hover:bg-[#1A8F47] text-white h-7 text-xs cursor-pointer">
                            <UserCheck className="w-3 h-3 mr-1" /> Accept
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => rejectFriendRequest(request)} className="text-gray-400 hover:text-red-400 h-7 text-xs cursor-pointer">
                            <UserX className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </>
                )}
                {sentRequests.length > 0 && (
                  <>
                    <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 mt-4 px-3">
                      Outgoing Requests — {sentRequests.length}
                    </div>
                    {sentRequests.map(request => (
                      <div key={request.id} className="flex items-center px-3 py-2 rounded hover:bg-[#35373C] group opacity-60">
                        <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center text-white text-sm font-semibold mr-3">
                          {request.toName[0].toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium text-white">{request.toName}</div>
                          <div className="text-xs text-gray-400">Outgoing Friend Request</div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </>
            )}
          </TabsContent>

          <TabsContent value="add" className="p-4 mt-0">
            <div className="mb-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search for users by username or display name..."
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100 pl-9"
                />
              </div>
            </div>
            {searchQuery && nonFriendUsers.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Search className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p>No users found matching &quot;{searchQuery}&quot;</p>
              </div>
            ) : searchQuery ? (
              nonFriendUsers.map(u => (
                <div key={u.id} className="flex items-center px-3 py-2 rounded hover:bg-[#35373C] group">
                  <div className="relative w-8 h-8 mr-3">
                    {u.avatar ? (
                      <Image src={u.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-sm font-semibold">
                        {u.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#313338] ${
                      u.status === 'online' ? 'bg-[#23A559]' : u.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white">{u.displayName}</div>
                    <div className="text-xs text-gray-400">@{u.username}</div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => sendFriendRequest(u)}
                    disabled={sendingRequest === u.id || user?.friends?.includes(u.id)}
                    className="bg-[#5865F2] hover:bg-[#4752C4] text-white h-7 text-xs cursor-pointer"
                  >
                    <UserPlus className="w-3 h-3 mr-1" />
                    {sendingRequest === u.id ? 'Sending...' : 'Add Friend'}
                  </Button>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <UserPlus className="w-10 h-10 mx-auto mb-2 opacity-50" />
                <p>Type a username to search for friends</p>
              </div>
            )}
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
