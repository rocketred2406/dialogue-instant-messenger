'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { User, Server } from '@/lib/types';
import { collection, onSnapshot, doc, setDoc, deleteDoc, getDoc, getDocs, updateDoc, arrayRemove } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Shield, Users, Trash2, UserX, Settings, Sparkles, Crown, Globe, Lock, Zap, Database, Star, Rocket } from 'lucide-react';
import Image from 'next/image';

export default function AdminPanel() {
  const { user, allUsers } = useAuth();
  const { appState, setShowAdminPanel, showConfirmDialog } = useApp();
  const [allServers, setAllServers] = useState<Server[]>([]);
  const [maxUsers, setMaxUsers] = useState(20);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'servers'), (snapshot) => {
      const servers: Server[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        // Backwards compatibility
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        servers.push({ id: d.id, ...data, dialogueBoost: isBoost } as Server);
      });
      setAllServers(servers);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const configDoc = await getDoc(doc(db, 'config', 'maxUsers'));
        if (configDoc.exists()) {
          const data = configDoc.data();
          setMaxUsers(data.value || data.maxUsers || 20);
        }
      } catch (e) {
        console.error('Failed to fetch config:', e);
      }
    };
    fetchConfig();
  }, []);

  if (!user?.isAdmin) return null;

  const handleSaveMaxUsers = async () => {
    setIsSaving(true);
    try {
      await setDoc(doc(db, 'config', 'maxUsers'), { value: maxUsers, updatedAt: Date.now() });
    } catch (err) {
      console.error('Failed to save config:', err);
    }
    setIsSaving(false);
  };

  const handleDeleteUser = async (targetUser: User) => {
    showConfirmDialog('Delete User', `Are you sure you want to delete user "${targetUser.displayName}" (@${targetUser.username})? This cannot be undone.`, async () => {
      try {
        for (const server of allServers) {
          if (server.members?.includes(targetUser.id)) {
            await updateDoc(doc(db, 'servers', server.id), {
              members: arrayRemove(targetUser.id),
            });
          }
        }
        await deleteDoc(doc(db, 'users', targetUser.id));
      } catch (err) {
        console.error('Failed to delete user:', err);
      }
    });
  };

  const handleKickFromServer = async (serverId: string, userId: string) => {
    try {
      await updateDoc(doc(db, 'servers', serverId), {
        members: arrayRemove(userId),
      });
    } catch (err) {
      console.error('Failed to kick user:', err);
    }
  };

  const handleDeleteServer = async (serverId: string, serverName: string) => {
    showConfirmDialog('Delete Server', `Are you sure you want to delete server "${serverName}"?`, async () => {
      try {
        await deleteDoc(doc(db, 'servers', serverId));
      } catch (err) {
        console.error('Failed to delete server:', err);
      }
    });
  };

  const handleToggleDialogueBoost = async (serverId: string, currentStatus: boolean) => {
    try {
      await setDoc(doc(db, 'servers', serverId), { dialogueBoost: !currentStatus }, { merge: true });
    } catch (err) {
      console.error('Failed to toggle Dialogue Boost:', err);
    }
  };

  const handleToggleDialoguePlus = async (userId: string, currentStatus: boolean) => {
    try {
      await setDoc(doc(db, 'users', userId), { dialoguePlus: !currentStatus }, { merge: true });
    } catch (err) {
      console.error('Failed to toggle Dialogue Plus:', err);
    }
  };

  return (
    <Dialog open={appState.showAdminPanel} onOpenChange={setShowAdminPanel}>
      <DialogContent className="bg-[#1E1F22] border-[#ED4245]/30 text-gray-100 max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#ED4245] to-[#FF6A00] flex items-center justify-center">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <span className="bg-gradient-to-r from-[#ED4245] to-[#FF6A00] bg-clip-text text-transparent font-bold">
              Super Admin Panel
            </span>
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Global administration controls — Only accessible by <span className="text-[#ED4245] font-medium">{user.displayName}</span>
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="config" className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="bg-[#2B2D31] w-full justify-start rounded-none border-b border-[#3F4147]">
            <TabsTrigger value="config" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Database className="w-3 h-3 mr-1" /> Config
            </TabsTrigger>
            <TabsTrigger value="users" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Users className="w-3 h-3 mr-1" /> Users
            </TabsTrigger>
            <TabsTrigger value="servers" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Globe className="w-3 h-3 mr-1" /> Servers
            </TabsTrigger>
            <TabsTrigger value="premium" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Sparkles className="w-3 h-3 mr-1" /> Premium
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#1E1F22 transparent' }}>
            <TabsContent value="config" className="space-y-4 mt-0">
              <div className="bg-[#2B2D31] rounded-lg p-4 border border-[#3F4147]">
                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <Settings className="w-4 h-4 text-[#ED4245]" /> Dialogue Configuration
                </h3>
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label className="text-xs font-bold uppercase text-gray-300">Max Number of Accounts</Label>
                    <Input
                      type="number"
                      value={maxUsers}
                      onChange={(e) => setMaxUsers(parseInt(e.target.value) || 20)}
                      className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                      min={1}
                    />
                    <p className="text-xs text-gray-500">Currently {allUsers.length} accounts registered</p>
                  </div>
                  <Button onClick={handleSaveMaxUsers} className="bg-[#ED4245] hover:bg-[#D83C3E] text-white cursor-pointer" disabled={isSaving}>
                    {isSaving ? 'Saving...' : 'Save Configuration'}
                  </Button>
                </div>
              </div>

              {/* System Stats */}
              <div className="bg-[#2B2D31] rounded-lg p-4 border border-[#3F4147]">
                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" /> System Stats
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-white">{allUsers.length}</div>
                    <div className="text-xs text-gray-400">Users</div>
                  </div>
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-white">{allServers.length}</div>
                    <div className="text-xs text-gray-400">Servers</div>
                  </div>
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-[#23A559]">{allUsers.filter(u => u.status === 'online').length}</div>
                    <div className="text-xs text-gray-400">Online</div>
                  </div>
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-yellow-400">{allServers.filter(s => s.dialogueBoost).length}</div>
                    <div className="text-xs text-gray-400">Boost Servers</div>
                  </div>
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-[#EB459E]">{allUsers.filter(u => u.dialoguePlus).length}</div>
                    <div className="text-xs text-gray-400">Plus Users</div>
                  </div>
                  <div className="bg-[#1E1F22] rounded-lg p-3 text-center">
                    <div className="text-2xl font-bold text-yellow-400">{allUsers.filter(u => u.status === 'idle').length}</div>
                    <div className="text-xs text-gray-400">Idle</div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="users" className="space-y-2 mt-0">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 px-1">
                All Users — {allUsers.length}
              </div>
              {allUsers.map(u => (
                <div key={u.id} className="flex items-center px-3 py-2 rounded bg-[#2B2D31] group border border-transparent hover:border-[#3F4147]">
                  <div className="relative w-8 h-8 mr-3 shrink-0">
                    {u.avatar ? (
                      <Image src={u.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-sm font-semibold">
                        {u.displayName[0].toUpperCase()}
                      </div>
                    )}
                    <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#2B2D31] ${
                      u.status === 'online' ? 'bg-[#23A559]' : u.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-white flex items-center gap-1">
                      <span style={u.gradient && u.dialoguePlus ? { backgroundImage: u.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}>
                        {u.displayName}
                      </span>
                      {u.isAdmin && <Crown className="w-3 h-3 text-yellow-500" />}
                      {u.dialoguePlus && <Star className="w-3 h-3 text-[#EB459E]" />}
                    </div>
                    <div className="text-xs text-gray-400">@{u.username} · {u.status}</div>
                  </div>
                  {u.id !== user.id && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteUser(u)}
                      className="text-gray-400 hover:text-red-400 h-7 text-xs opacity-0 group-hover:opacity-100 cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3 mr-1" /> Delete
                    </Button>
                  )}
                </div>
              ))}
            </TabsContent>

            <TabsContent value="servers" className="space-y-2 mt-0">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 px-1">
                All Servers — {allServers.length}
              </div>
              {allServers.map(server => (
                <div key={server.id} className="bg-[#2B2D31] rounded-lg p-3 border border-transparent hover:border-[#3F4147]">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 mr-3 rounded-full bg-[#5865F2] flex items-center justify-center text-white font-semibold text-sm shrink-0 overflow-hidden">
                      {server.icon ? (
                        <Image src={server.icon} alt="" width={40} height={40} className="object-cover" unoptimized />
                      ) : (
                        server.name.split(' ').map(w => w[0]).join('').substring(0, 3)
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-white truncate flex items-center gap-1">
                        {server.name}
                        {server.dialogueBoost && <Sparkles className="w-3 h-3 text-yellow-400" />}
                      </div>
                      <div className="text-xs text-gray-400 flex items-center gap-2">
                        <span>{server.members?.length || 0} members</span>
                        <span className="flex items-center gap-0.5">
                          {server.isPublic ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                          {server.isPublic ? 'Public' : 'Private'}
                        </span>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteServer(server.id, server.name)}
                      className="text-gray-400 hover:text-red-400 h-7 text-xs cursor-pointer"
                    >
                      <Trash2 className="w-3 h-3 mr-1" /> Delete
                    </Button>
                  </div>
                  {server.members && server.members.length > 0 && (
                    <div className="mt-2 pl-2 border-l-2 border-[#3F4147]">
                      <div className="text-xs text-gray-500 mb-1">Members:</div>
                      {server.members.map(memberId => {
                        const member = allUsers.find(u => u.id === memberId);
                        return (
                          <div key={memberId} className="flex items-center justify-between py-0.5">
                            <span className="text-xs text-gray-300">{member?.displayName || memberId.substring(0, 8)}</span>
                            {memberId !== user.id && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleKickFromServer(server.id, memberId)}
                                className="text-gray-500 hover:text-red-400 h-5 text-[10px] px-1 cursor-pointer"
                              >
                                <UserX className="w-2.5 h-2.5 mr-0.5" /> Kick
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </TabsContent>

            {/* Combined Premium tab */}
            <TabsContent value="premium" className="space-y-4 mt-0">
              <div className="bg-gradient-to-r from-[#5865F2]/20 via-[#EB459E]/20 to-[#FFD200]/20 rounded-lg p-4 border border-[#EB459E]/30">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-5 h-5 text-yellow-400" />
                  <h3 className="text-white font-semibold text-lg">Premium Management</h3>
                </div>
                <p className="text-gray-300 text-sm">
                  Manage all premium features: Dialogue Plus for users and Dialogue Boost for servers.
                </p>
              </div>

              {/* Dialogue Boost for Servers */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 px-1 flex items-center gap-1.5">
                  <Rocket className="w-3 h-3 text-yellow-400" />
                  Dialogue Boost — Servers
                </div>
                <p className="text-xs text-gray-500 px-1 mb-2">Grant servers Dialogue Boost to unlock: custom emojis, discover page images, and exclusive aesthetics.</p>
                {allServers.map(server => (
                  <div key={server.id} className="flex items-center gap-3 bg-[#2B2D31] rounded-lg p-3 border border-transparent hover:border-[#3F4147]">
                    <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-xs font-semibold shrink-0 overflow-hidden">
                      {server.icon ? (
                        <Image src={server.icon} alt="" width={32} height={32} className="object-cover" unoptimized />
                      ) : (
                        server.name.split(' ').map(w => w[0]).join('').substring(0, 2)
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-white font-medium truncate">{server.name}</div>
                      <div className="text-xs text-gray-400">{server.members?.length || 0} members</div>
                    </div>
                    <Button
                      onClick={() => handleToggleDialogueBoost(server.id, !!server.dialogueBoost)}
                      className={`cursor-pointer ${
                        server.dialogueBoost
                          ? 'bg-gradient-to-r from-[#5865F2] to-[#EB459E] text-white hover:opacity-90'
                          : 'bg-[#4752C4] text-gray-200 hover:bg-[#5865F2]'
                      }`}
                      size="sm"
                    >
                      <Rocket className="w-3 h-3 mr-1" />
                      {server.dialogueBoost ? 'Boost Active' : 'Grant Boost'}
                    </Button>
                  </div>
                ))}
              </div>

              <Separator className="bg-[#3F4147]" />

              {/* Dialogue Plus for Users */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2 px-1 flex items-center gap-1.5">
                  <Star className="w-3 h-3 text-[#EB459E]" />
                  Dialogue Plus — Users
                </div>
                <p className="text-xs text-gray-500 px-1 mb-2">Grant users Dialogue Plus to unlock: gradient usernames, custom emoji usage across servers, and profile backgrounds.</p>
                {allUsers.map(u => (
                  <div key={u.id} className="flex items-center gap-3 bg-[#2B2D31] rounded-lg p-3 border border-transparent hover:border-[#3F4147]">
                    <div className="relative w-8 h-8 shrink-0">
                      {u.avatar ? (
                        <Image src={u.avatar} alt="" width={32} height={32} className="rounded-full object-cover" unoptimized />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-xs font-semibold">
                          {u.displayName[0].toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-white font-medium truncate flex items-center gap-1">
                        {u.displayName}
                        {u.isAdmin && <Crown className="w-3 h-3 text-yellow-500" />}
                      </div>
                      <div className="text-xs text-gray-400">@{u.username}</div>
                    </div>
                    <Button
                      onClick={() => handleToggleDialoguePlus(u.id, !!u.dialoguePlus)}
                      className={`cursor-pointer ${
                        u.dialoguePlus
                          ? 'bg-gradient-to-r from-[#EB459E] to-[#FFD200] text-white hover:opacity-90'
                          : 'bg-[#4752C4] text-gray-200 hover:bg-[#5865F2]'
                      }`}
                      size="sm"
                    >
                      <Star className="w-3 h-3 mr-1" />
                      {u.dialoguePlus ? 'Plus Active' : 'Grant Plus'}
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
