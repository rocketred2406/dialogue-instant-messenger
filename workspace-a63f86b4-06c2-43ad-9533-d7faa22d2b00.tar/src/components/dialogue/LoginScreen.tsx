'use client';

import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, ShieldAlert } from 'lucide-react';
import Image from 'next/image';

export default function LoginScreen() {
  const { login, register, firebaseReady, firebaseError } = useAuth();
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regDisplayName, setRegDisplayName] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    const result = await login(loginUsername, loginPassword);
    if (!result.success) {
      setError(result.error || 'Login failed');
    }
    setIsLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (regUsername.length < 2) {
      setError('Username must be at least 2 characters');
      return;
    }
    if (regPassword.length < 4) {
      setError('Password must be at least 4 characters');
      return;
    }
    if (regDisplayName.length < 1) {
      setError('Display name is required');
      return;
    }
    setIsLoading(true);
    const result = await register(regUsername, regPassword, regDisplayName);
    if (!result.success) {
      setError(result.error || 'Registration failed');
    }
    setIsLoading(false);
  };

  const isPermissionError = error.includes('permission denied') || error.includes('security rules');
  const isConnectionError = error.includes('timed out') || error.includes('not found') || error.includes('unavailable');

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#313338] p-4">
      <Card className="w-full max-w-md bg-[#1E1F22] border-[#313338] text-gray-100">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <div className="relative w-20 h-20">
              <Image
                src="/Dialogue.png"
                alt="Dialogue"
                fill
                sizes="80px"
                className="object-contain"
                priority
              />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-white">Welcome to Dialogue</CardTitle>
          <CardDescription className="text-gray-400">Connect with your friends and communities</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Firebase connection warning */}
          {!firebaseReady && firebaseError && (
            <Alert className="mb-4 bg-yellow-900/30 border-yellow-700 text-yellow-200">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-xs">
                {firebaseError}
              </AlertDescription>
            </Alert>
          )}

          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-[#2B2D31] mb-4">
              <TabsTrigger value="login" className="text-gray-300 data-[state=active]:bg-[#5865F2] data-[state=active]:text-white">Log In</TabsTrigger>
              <TabsTrigger value="register" className="text-gray-300 data-[state=active]:bg-[#5865F2] data-[state=active]:text-white">Register</TabsTrigger>
            </TabsList>

            {error && (
              <Alert variant="destructive" className={`mb-4 ${isPermissionError ? 'bg-orange-900/30 border-orange-700 text-orange-200' : isConnectionError ? 'bg-yellow-900/30 border-yellow-700 text-yellow-200' : 'bg-red-900/30 border-red-800 text-red-200'}`}>
                {isPermissionError ? <ShieldAlert className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                <AlertDescription className="text-xs">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username" className="text-xs font-bold uppercase text-gray-300">Username</Label>
                  <Input
                    id="login-username"
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    className="bg-[#1E1F22] border-[#313338] text-gray-100 focus-visible:ring-[#5865F2]"
                    placeholder="Enter your username"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-xs font-bold uppercase text-gray-300">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="bg-[#1E1F22] border-[#313338] text-gray-100 focus-visible:ring-[#5865F2]"
                    placeholder="Enter your password"
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white" disabled={isLoading}>
                  {isLoading ? 'Logging in...' : 'Log In'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="register">
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-displayname" className="text-xs font-bold uppercase text-gray-300">Display Name</Label>
                  <Input
                    id="reg-displayname"
                    value={regDisplayName}
                    onChange={(e) => setRegDisplayName(e.target.value)}
                    className="bg-[#1E1F22] border-[#313338] text-gray-100 focus-visible:ring-[#5865F2]"
                    placeholder="What should people call you?"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-username" className="text-xs font-bold uppercase text-gray-300">Username</Label>
                  <Input
                    id="reg-username"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    className="bg-[#1E1F22] border-[#313338] text-gray-100 focus-visible:ring-[#5865F2]"
                    placeholder="Choose a unique username"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-password" className="text-xs font-bold uppercase text-gray-300">Password</Label>
                  <Input
                    id="reg-password"
                    type="password"
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    className="bg-[#1E1F22] border-[#313338] text-gray-100 focus-visible:ring-[#5865F2]"
                    placeholder="Choose a strong password"
                    required
                  />
                </div>
                <Button type="submit" className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white" disabled={isLoading}>
                  {isLoading ? 'Creating account...' : 'Register'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
