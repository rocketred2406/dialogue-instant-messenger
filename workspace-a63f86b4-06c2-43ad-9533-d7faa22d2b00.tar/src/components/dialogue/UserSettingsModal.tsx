'use client';

import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { GRADIENT_PRESETS } from '@/lib/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Key, Palette, Save, Check, Plus, X, Shuffle, Sparkles } from 'lucide-react';
import Image from 'next/image';

function buildGradientFromColors(colors: string[]): string {
  if (colors.length < 2) return '';
  return `linear-gradient(135deg, ${colors.join(', ')})`;
}

export default function UserSettingsModal() {
  const { user, updateUser, changePassword } = useAuth();
  const { appState, setShowUserSettings } = useApp();

  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [username, setUsername] = useState(user?.username || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [gradient, setGradient] = useState(user?.gradient || '');
  const [gradientColors, setGradientColors] = useState<string[]>(user?.gradientColors || []);
  const [profileBackground, setProfileBackground] = useState(user?.profileBackground || '');

  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [isSavingPassword, setIsSavingPassword] = useState(false);
  const [profileMessage, setProfileMessage] = useState('');
  const [passwordMessage, setPasswordMessage] = useState('');

  if (!user) return null;

  const isDialoguePlus = !!user.dialoguePlus;

  const handleSaveProfile = async () => {
    setIsSavingProfile(true);
    setProfileMessage('');

    if (displayName.trim().length < 1) {
      setProfileMessage('Display name is required');
      setIsSavingProfile(false);
      return;
    }

    try {
      const updates: Record<string, unknown> = {
        displayName: displayName.trim(),
        username: username.trim() || user.username,
        avatar: avatar.trim(),
        bio: bio.trim(),
        profileBackground: isDialoguePlus ? profileBackground.trim() : (user.profileBackground || ''),
      };

      // Gradient is only available for Dialogue Plus users
      if (isDialoguePlus) {
        updates.gradient = gradient;
        updates.gradientColors = gradientColors;
      }

      await updateUser(updates as Partial<typeof user>);
      setProfileMessage('Profile saved! All your messages have been updated.');
      setTimeout(() => setProfileMessage(''), 3000);
    } catch {
      setProfileMessage('Failed to save profile');
    }
    setIsSavingProfile(false);
  };

  const handleChangePassword = async () => {
    setPasswordMessage('');

    if (newPassword.length < 4) {
      setPasswordMessage('New password must be at least 4 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordMessage('Passwords do not match');
      return;
    }

    setIsSavingPassword(true);
    const result = await changePassword(oldPassword, newPassword);
    if (result.success) {
      setPasswordMessage('Password changed successfully!');
      setOldPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordMessage(''), 3000);
    } else {
      setPasswordMessage(result.error || 'Failed to change password');
    }
    setIsSavingPassword(false);
  };

  const addGradientColor = () => {
    const newColors = [...gradientColors, '#5865F2'];
    setGradientColors(newColors);
    setGradient(buildGradientFromColors(newColors));
  };

  const removeGradientColor = (index: number) => {
    const newColors = gradientColors.filter((_, i) => i !== index);
    setGradientColors(newColors);
    setGradient(newColors.length >= 2 ? buildGradientFromColors(newColors) : '');
  };

  const updateGradientColor = (index: number, color: string) => {
    const newColors = [...gradientColors];
    newColors[index] = color;
    setGradientColors(newColors);
    setGradient(newColors.length >= 2 ? buildGradientFromColors(newColors) : '');
  };

  const applyPreset = (preset: typeof GRADIENT_PRESETS[number]) => {
    setGradientColors([...preset.colors]);
    setGradient(preset.gradient);
  };

  const clearGradient = () => {
    setGradientColors([]);
    setGradient('');
  };

  const shuffleGradient = () => {
    const shuffled = [...gradientColors].sort(() => Math.random() - 0.5);
    setGradientColors(shuffled);
    setGradient(buildGradientFromColors(shuffled));
  };

  const currentGradientPreview = gradient || buildGradientFromColors(gradientColors);

  return (
    <Dialog open={appState.showUserSettings} onOpenChange={setShowUserSettings}>
      <DialogContent className="bg-[#313338] border-[#3F4147] text-gray-100 max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-white text-xl flex items-center gap-2">
            <User className="w-5 h-5" /> User Settings
            {isDialoguePlus && (
              <span className="text-xs font-semibold bg-gradient-to-r from-[#5865F2] to-[#EB459E] bg-clip-text text-transparent flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-yellow-400" /> Dialogue Plus
              </span>
            )}
          </DialogTitle>
          <DialogDescription className="text-gray-400">Manage your profile and account</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="profile" className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="bg-[#2B2D31] w-full justify-start rounded-none border-b border-[#3F4147]">
            <TabsTrigger value="profile" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <User className="w-3 h-3 mr-1" /> Profile
            </TabsTrigger>
            <TabsTrigger value="password" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Key className="w-3 h-3 mr-1" /> Password
            </TabsTrigger>
            <TabsTrigger value="appearance" className="text-gray-300 data-[state=active]:bg-[#404249] data-[state=active]:text-white cursor-pointer">
              <Palette className="w-3 h-3 mr-1" /> Appearance
            </TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4" style={{ scrollbarWidth: 'thin', scrollbarColor: '#1E1F22 transparent' }}>
            <TabsContent value="profile" className="space-y-4 mt-0">
              {/* Avatar Preview */}
              <div className="flex items-center gap-4 mb-4">
                <div className="relative w-20 h-20 shrink-0">
                  {avatar ? (
                    <Image src={avatar} alt="" fill className="rounded-full object-cover" unoptimized />
                  ) : (
                    <div className="w-20 h-20 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-2xl font-semibold">
                      {displayName[0]?.toUpperCase() || '?'}
                    </div>
                  )}
                </div>
                <div>
                  <div
                    className="text-white font-semibold text-lg gradient-username"
                    style={currentGradientPreview && isDialoguePlus ? { backgroundImage: currentGradientPreview } : {}}
                  >
                    {displayName || 'Your Name'}
                  </div>
                  <div className="text-gray-400 text-sm">@{username || user.username}</div>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Display Name</Label>
                <Input
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="Your display name"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Username</Label>
                <Input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="Your unique username"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Avatar Image URL</Label>
                <Input
                  value={avatar}
                  onChange={(e) => setAvatar(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="https://example.com/avatar.png"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">About Me / Bio</Label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full bg-[#1E1F22] border border-[#3F4147] rounded-md px-3 py-2 text-gray-100 outline-none focus:border-[#5865F2] text-sm min-h-[80px] resize-y"
                  placeholder="Tell people about yourself..."
                  maxLength={190}
                />
                <p className="text-[10px] text-gray-500 text-right">{bio.length}/190</p>
              </div>

              {/* Profile Background - Dialogue Plus only */}
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1">
                  Profile Background URL
                  {!isDialoguePlus && <span className="text-yellow-400 text-[10px]">(Dialogue Plus only)</span>}
                </Label>
                <Input
                  value={profileBackground}
                  onChange={(e) => setProfileBackground(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="https://example.com/background.jpg"
                  disabled={!isDialoguePlus}
                />
                {isDialoguePlus && profileBackground && (
                  <div className="relative w-full h-16 rounded-lg overflow-hidden mt-1">
                    <Image src={profileBackground} alt="Background preview" fill className="object-cover" unoptimized />
                  </div>
                )}
              </div>

              {profileMessage && (
                <div className={`text-sm px-3 py-2 rounded ${profileMessage.includes('success') || profileMessage.includes('saved') || profileMessage.includes('updated') ? 'bg-green-900/30 text-green-300' : 'bg-red-900/30 text-red-300'}`}>
                  {profileMessage}
                </div>
              )}

              <Button onClick={handleSaveProfile} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSavingProfile}>
                <Save className="w-4 h-4 mr-2" /> {isSavingProfile ? 'Saving...' : 'Save Profile'}
              </Button>
            </TabsContent>

            <TabsContent value="password" className="space-y-4 mt-0">
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Current Password</Label>
                <Input
                  type="password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="Enter current password"
                />
              </div>
              <Separator className="bg-[#3F4147]" />
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">New Password</Label>
                <Input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="Enter new password (min 4 characters)"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300">Confirm New Password</Label>
                <Input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-[#1E1F22] border-[#3F4147] text-gray-100"
                  placeholder="Confirm new password"
                />
              </div>

              {passwordMessage && (
                <div className={`text-sm px-3 py-2 rounded ${passwordMessage.includes('success') ? 'bg-green-900/30 text-green-300' : 'bg-red-900/30 text-red-300'}`}>
                  {passwordMessage}
                </div>
              )}

              <Button onClick={handleChangePassword} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSavingPassword || !oldPassword || !newPassword || !confirmPassword}>
                <Key className="w-4 h-4 mr-2" /> {isSavingPassword ? 'Changing...' : 'Change Password'}
              </Button>
            </TabsContent>

            <TabsContent value="appearance" className="space-y-4 mt-0">
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-gray-300 flex items-center gap-1">
                  Username Gradient
                  {!isDialoguePlus && <span className="text-yellow-400 text-[10px]">(Dialogue Plus only)</span>}
                </Label>
                <p className="text-xs text-gray-500">Choose a gradient style for your username. Hover over it to see the carousel animation!</p>
              </div>

              {!isDialoguePlus && (
                <div className="bg-yellow-900/20 border border-yellow-800/30 rounded-lg p-3 text-sm text-yellow-300">
                  <Sparkles className="w-4 h-4 inline mr-1" /> Upgrade to Dialogue Plus to unlock gradient usernames and more!
                </div>
              )}

              {/* Current gradient preview */}
              <div className="bg-[#2B2D31] rounded-lg p-4 flex items-center gap-3">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-white text-lg font-bold bg-[#5865F2]">
                  {displayName[0]?.toUpperCase() || '?'}
                </div>
                <div>
                  <div
                    className="text-white font-semibold gradient-username"
                    style={currentGradientPreview && isDialoguePlus ? { backgroundImage: currentGradientPreview } : {}}
                  >
                    {displayName || user.displayName}
                  </div>
                  <div className="text-gray-400 text-xs">@{username || user.username}</div>
                </div>
                {currentGradientPreview && isDialoguePlus && (
                  <Button variant="ghost" size="sm" onClick={clearGradient} className="ml-auto text-gray-400 hover:text-red-400 cursor-pointer">
                    <X className="w-3 h-3 mr-1" /> Clear
                  </Button>
                )}
              </div>

              {isDialoguePlus && (
                <>
                  <Separator className="bg-[#3F4147]" />

                  {/* Gradient presets */}
                  <div className="space-y-2">
                    <Label className="text-xs font-bold uppercase text-gray-300">Presets</Label>
                    <div className="grid grid-cols-4 gap-2">
                      {/* None option */}
                      <button
                        onClick={clearGradient}
                        className={`h-10 rounded-lg border-2 flex items-center justify-center cursor-pointer transition-all ${!currentGradientPreview ? 'border-white' : 'border-[#3F4147] hover:border-gray-500'}`}
                        style={{ backgroundColor: '#5865F2' }}
                      >
                        {!currentGradientPreview && <Check className="w-4 h-4 text-white" />}
                      </button>
                      {GRADIENT_PRESETS.map((preset, i) => (
                        <button
                          key={i}
                          onClick={() => applyPreset(preset)}
                          className={`h-10 rounded-lg border-2 flex items-center justify-center cursor-pointer transition-all ${gradient === preset.gradient ? 'border-white' : 'border-[#3F4147] hover:border-gray-500'}`}
                          style={{ background: preset.gradient, backgroundSize: '200% 200%' }}
                          title={preset.name}
                        >
                          {gradient === preset.gradient && <Check className="w-4 h-4 text-white" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <Separator className="bg-[#3F4147]" />

                  {/* Custom hex color editor */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-xs font-bold uppercase text-gray-300">Custom Colors</Label>
                      <div className="flex gap-2">
                        {gradientColors.length >= 2 && (
                          <Button variant="ghost" size="sm" onClick={shuffleGradient} className="text-gray-400 hover:text-white h-7 text-xs cursor-pointer">
                            <Shuffle className="w-3 h-3 mr-1" /> Shuffle
                          </Button>
                        )}
                        <Button variant="outline" size="sm" onClick={addGradientColor} className="border-[#3F4147] text-gray-300 hover:text-white h-7 text-xs cursor-pointer">
                          <Plus className="w-3 h-3 mr-1" /> Add Color
                        </Button>
                      </div>
                    </div>

                    <p className="text-xs text-gray-500">Use hex colors or the color picker to create a custom gradient. Minimum 2 colors required.</p>

                    {gradientColors.length > 0 && (
                      <div className="space-y-2">
                        {gradientColors.map((color, index) => (
                          <div key={index} className="flex items-center gap-2 bg-[#2B2D31] rounded-lg p-2">
                            <input
                              type="color"
                              value={color}
                              onChange={(e) => updateGradientColor(index, e.target.value)}
                              className="w-8 h-8 rounded cursor-pointer bg-transparent border-none"
                            />
                            <Input
                              value={color}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateGradientColor(index, val.startsWith('#') ? val : `#${val}`);
                              }}
                              className="bg-[#1E1F22] border-[#3F4147] text-gray-100 flex-1 h-8 font-mono text-sm"
                              placeholder="#FF6B6B"
                              maxLength={7}
                            />
                            <div className="w-6 h-6 rounded-full shrink-0" style={{ backgroundColor: color }} />
                            {gradientColors.length > 2 && (
                              <Button variant="ghost" size="icon" onClick={() => removeGradientColor(index)} className="text-gray-400 hover:text-red-400 h-7 w-7 cursor-pointer shrink-0">
                                <X className="w-3 h-3" />
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {gradientColors.length < 2 && gradientColors.length > 0 && (
                      <p className="text-xs text-yellow-400">Add at least one more color to create a gradient.</p>
                    )}

                    {/* Custom gradient preview */}
                    {gradientColors.length >= 2 && (
                      <div className="bg-[#2B2D31] rounded-lg p-3">
                        <div className="text-xs text-gray-400 mb-2">Preview</div>
                        <div
                          className="h-8 rounded-lg"
                          style={{ background: buildGradientFromColors(gradientColors), backgroundSize: '200% 200%' }}
                        />
                        <div
                          className="text-lg font-bold mt-2 gradient-username"
                          style={{ backgroundImage: buildGradientFromColors(gradientColors) }}
                        >
                          {displayName || user.displayName}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              )}

              <Button onClick={handleSaveProfile} className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white cursor-pointer" disabled={isSavingProfile}>
                <Save className="w-4 h-4 mr-2" /> Save Appearance
              </Button>
            </TabsContent>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
