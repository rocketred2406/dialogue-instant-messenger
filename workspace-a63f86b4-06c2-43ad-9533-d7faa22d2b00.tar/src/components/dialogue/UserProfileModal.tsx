'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { User, Server } from '@/lib/types';
import { doc, getDoc, collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { MessageCircle, UserPlus, UserX, Users, Server as ServerIcon, MapPin, Calendar, Shield, Crown, Sparkles } from 'lucide-react';
import Image from 'next/image';

export default function UserProfileModal() {
  const { user, allUsers, getUserById } = useAuth();
  const { appState, setShowProfileUserId, setCurrentDMConversationId, setCurrentView, setCurrentServerId } = useApp();
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [mutualFriends, setMutualFriends] = useState<User[]>([]);
  const [mutualServers, setMutualServers] = useState<Server[]>([]);
  const [allServers, setAllServers] = useState<Server[]>([]);

  const profileUserId = appState.showProfileUserId;

  // Fetch all servers
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'servers'), (snapshot) => {
      const servers: Server[] = [];
      snapshot.forEach((d) => {
        const data = d.data();
        // Backwards compatibility
        const isBoost = data.dialogueBoost !== undefined ? data.dialogueBoost : !!data.dialoguePlus;
        servers.push({ id: d.id, ...data, dialogueBoost: isBoost } as Server);
      });
      setAllServers(servers);
    });
    return () => unsub();
  }, []);

  // Fetch profile user data
  useEffect(() => {
    if (!profileUserId) {
      setProfileUser(null);
      return;
    }

    // First check if user is in allUsers cache
    const cached = getUserById(profileUserId);
    if (cached) {
      setProfileUser(cached);
    }

    // Also fetch fresh data
    const fetchUser = async () => {
      try {
        const userDoc = await getDoc(doc(db, 'users', profileUserId));
        if (userDoc.exists()) {
          setProfileUser({ id: userDoc.id, ...userDoc.data() } as User);
        }
      } catch (err) {
        console.error('Failed to fetch profile user:', err);
      }
    };
    fetchUser();
  }, [profileUserId, getUserById]);

  // Calculate mutual friends and servers
  useEffect(() => {
    if (!profileUser || !user) {
      setMutualFriends([]);
      setMutualServers([]);
      return;
    }

    // Mutual friends
    const myFriends = user.friends || [];
    const theirFriends = profileUser.friends || [];
    const mutualIds = myFriends.filter(id => theirFriends.includes(id));
    const mutualFriendList = allUsers.filter(u => mutualIds.includes(u.id));
    setMutualFriends(mutualFriendList);

    // Mutual servers - also ensure Dialogue IM is included
    const myServers = user.serverIds || [];
    const theirServers = profileUser.serverIds || [];
    const mutualServerIds = myServers.filter(id => theirServers.includes(id));
    const mutualServerList = allServers.filter(s => mutualServerIds.includes(s.id));
    setMutualServers(mutualServerList);
  }, [profileUser, user, allUsers, allServers]);

  if (!profileUserId || !profileUser) return null;

  const isOwnProfile = profileUser.id === user?.id;
  const isFriend = user?.friends?.includes(profileUser.id);
  const friendUser = allUsers.find(u => u.id === profileUser.id) || profileUser;

  const handleSendMessage = async () => {
    if (!user || isOwnProfile) return;
    // Find or create DM
    try {
      const { getDocs, addDoc } = await import('firebase/firestore');
      const q2 = query(collection(db, 'dmConversations'), where('participants', 'array-contains', user.id));
      const snapshot = await getDocs(q2);
      let existingConvoId: string | null = null;
      snapshot.forEach((d) => {
        const data = d.data();
        if (data.participants.includes(profileUser.id)) {
          existingConvoId = d.id;
        }
      });
      if (existingConvoId) {
        setCurrentDMConversationId(existingConvoId);
      } else {
        const docRef = await addDoc(collection(db, 'dmConversations'), {
          participants: [user.id, profileUser.id],
          createdAt: Date.now(),
        });
        setCurrentDMConversationId(docRef.id);
      }
      setCurrentView('dm');
      setShowProfileUserId(null);
    } catch (err) {
      console.error('Failed to start DM:', err);
    }
  };

  const getDaysSince = (timestamp: number) => {
    const diff = Date.now() - timestamp;
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  // Determine banner background: profileBackground for Plus users, otherwise gradient
  const bannerStyle = friendUser.profileBackground && friendUser.dialoguePlus
    ? { backgroundImage: `url(${friendUser.profileBackground})`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : { background: friendUser.gradient || 'linear-gradient(135deg, #5865F2, #4752C4)', backgroundSize: '200% 200%' };

  return (
    <Dialog open={!!profileUserId} onOpenChange={(open) => { if (!open) setShowProfileUserId(null); }}>
      <DialogContent className="bg-[#232428] border-[#3F4147] text-gray-100 max-w-lg p-0 overflow-hidden">
        {/* Banner with gradient or profile background */}
        <div className="relative h-28">
          <div
            className="absolute inset-0 rounded-t-lg overflow-hidden"
            style={bannerStyle}
          />
        </div>

        {/* Avatar overlapping the banner - in front of everything */}
        <div className="relative -mt-10 left-4 z-20 w-fit">
          <div className="relative w-20 h-20 rounded-full border-4 border-[#232428] bg-[#2B2D31]">
            {friendUser.avatar ? (
              <Image src={friendUser.avatar} alt="" fill className="rounded-full object-cover" unoptimized />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-white text-2xl font-bold rounded-full bg-[#5865F2]">
                {friendUser.displayName[0]?.toUpperCase() || '?'}
              </div>
            )}
            <div className={`absolute bottom-0.5 right-0.5 w-4 h-4 rounded-full border-2 border-[#232428] ${
              friendUser.status === 'online' ? 'bg-[#23A559]' : friendUser.status === 'idle' ? 'bg-yellow-500' : 'bg-gray-500'
            }`} />
          </div>
        </div>

        {/* Profile content */}
        <div className="px-4 pb-4">
          {/* Name and username */}
          <div className="mb-3">
            <div className="flex items-center gap-2">
              <h2
                className="text-xl font-bold text-white"
                style={friendUser.gradient && friendUser.dialoguePlus ? { backgroundImage: friendUser.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
              >
                {friendUser.displayName}
              </h2>
              {friendUser.isAdmin && <Shield className="w-4 h-4 text-red-400" />}
              {friendUser.dialoguePlus && <Sparkles className="w-4 h-4 text-yellow-400" title="Dialogue Plus" />}
            </div>
            <div className="text-sm text-gray-400">@{friendUser.username}</div>
          </div>

          {/* Action buttons */}
          {!isOwnProfile && (
            <div className="flex gap-2 mb-3">
              <Button
                onClick={handleSendMessage}
                className="bg-[#5865F2] hover:bg-[#4752C4] text-white flex-1 cursor-pointer"
                size="sm"
              >
                <MessageCircle className="w-4 h-4 mr-1.5" /> Send Message
              </Button>
            </div>
          )}

          <Separator className="bg-[#3F4147] my-3" />

          {/* About section */}
          {(friendUser.bio || isOwnProfile) && (
            <div className="mb-3">
              <h3 className="text-xs font-bold uppercase text-gray-300 mb-1">About Me</h3>
              <div className="bg-[#1E1F22] rounded-lg p-3 text-sm text-gray-200 min-h-[2rem]">
                {friendUser.bio || (isOwnProfile ? 'Click settings to add a bio!' : 'No bio yet.')}
              </div>
            </div>
          )}

          {/* Member since */}
          <div className="flex items-center gap-2 text-xs text-gray-400 mb-3">
            <Calendar className="w-3.5 h-3.5" />
            <span>Joined {new Date(friendUser.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
            <span className="text-gray-600">·</span>
            <span>{getDaysSince(friendUser.createdAt)} days ago</span>
          </div>

          {/* Mutual Servers */}
          {mutualServers.length > 0 && (
            <div className="mb-3">
              <h3 className="text-xs font-bold uppercase text-gray-300 mb-1.5">
                <ServerIcon className="w-3 h-3 inline mr-1" />
                Mutual Servers — {mutualServers.length}
              </h3>
              <ScrollArea className="max-h-32">
                <div className="space-y-1">
                  {mutualServers.map(server => (
                    <div key={server.id} className="flex items-center gap-2 py-1 px-2 rounded hover:bg-[#2B2D31] cursor-pointer" onClick={() => { setCurrentServerId(server.id); setShowProfileUserId(null); }}>
                      <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-[10px] font-semibold shrink-0 overflow-hidden">
                        {server.icon ? (
                          <Image src={server.icon} alt="" width={24} height={24} className="object-cover" unoptimized />
                        ) : (
                          server.name.split(' ').map(w => w[0]).join('').substring(0, 2)
                        )}
                      </div>
                      <span className="text-sm text-gray-200 truncate">{server.name}</span>
                      {server.dialogueBoost && <span className="text-[10px] text-yellow-400">✨</span>}
                      {server.ownerId === profileUser.id && <Crown className="w-3 h-3 text-yellow-500 ml-auto shrink-0" />}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Mutual Friends */}
          {mutualFriends.length > 0 && (
            <div className="mb-3">
              <h3 className="text-xs font-bold uppercase text-gray-300 mb-1.5">
                <Users className="w-3 h-3 inline mr-1" />
                Mutual Friends — {mutualFriends.length}
              </h3>
              <ScrollArea className="max-h-32">
                <div className="space-y-1">
                  {mutualFriends.map(friend => (
                    <div
                      key={friend.id}
                      className="flex items-center gap-2 py-1 px-2 rounded hover:bg-[#2B2D31] cursor-pointer"
                      onClick={() => setShowProfileUserId(friend.id)}
                    >
                      <div className="relative w-6 h-6 shrink-0">
                        {friend.avatar ? (
                          <Image src={friend.avatar} alt="" width={24} height={24} className="rounded-full object-cover" unoptimized />
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-[#5865F2] flex items-center justify-center text-white text-[10px] font-semibold">
                            {friend.displayName[0]?.toUpperCase()}
                          </div>
                        )}
                        <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-[#232428] ${
                          friend.status === 'online' ? 'bg-[#23A559]' : 'bg-gray-500'
                        }`} />
                      </div>
                      <span
                        className="text-sm text-gray-200 truncate"
                        style={friend.gradient && friend.dialoguePlus ? { backgroundImage: friend.gradient, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' } : {}}
                      >
                        {friend.displayName}
                      </span>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* No mutuals message */}
          {mutualFriends.length === 0 && mutualServers.length === 0 && !isOwnProfile && (
            <div className="text-center py-4 text-gray-500 text-sm">
              No mutual servers or friends
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
