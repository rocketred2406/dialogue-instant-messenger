'use client';

import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import ServerSidebar from './ServerSidebar';
import ChannelSidebar from './ChannelSidebar';
import ChatArea from './ChatArea';
import MemberList from './MemberList';
import DiscoverPage from './DiscoverPage';
import FriendsPage from './FriendsPage';
import CreateServerModal from './CreateServerModal';
import ServerSettings from './ServerSettings';
import AdminPanel from './AdminPanel';
import MediaViewer from './MediaViewer';
import UserSettingsModal from './UserSettingsModal';
import UserProfileModal from './UserProfileModal';
import { ConfirmDialog, PromptDialog, AlertDialog } from './CustomDialogs';

export default function AppLayout() {
  const { user } = useAuth();
  const { appState } = useApp();

  if (!user) return null;

  return (
    <div className="h-screen w-screen flex overflow-hidden bg-[#313338]">
      {/* Server Sidebar */}
      <ServerSidebar />

      {/* Channel Sidebar */}
      <ChannelSidebar />

      {/* Main Content Area */}
      {appState.currentView === 'discover' ? (
        <DiscoverPage />
      ) : appState.currentView === 'friends' ? (
        <FriendsPage />
      ) : (
        <ChatArea />
      )}

      {/* Member List (only in server view) */}
      {appState.currentView === 'server' && <MemberList />}

      {/* Modals */}
      <CreateServerModal />
      {/* Server Settings - always available for server admins */}
      <ServerSettings />
      {/* Admin Panel - only for Little_Timmy, separate from server settings */}
      <AdminPanel />
      <MediaViewer />
      <UserSettingsModal />
      <UserProfileModal />
      <ConfirmDialog />
      <PromptDialog />
      <AlertDialog />
    </div>
  );
}
