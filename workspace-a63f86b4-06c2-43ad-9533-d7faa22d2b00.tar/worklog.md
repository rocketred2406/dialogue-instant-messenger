# Work Log - Dialogue Website Major Update

## Task 1: Fix Permission System & Core Bugs

### Critical Fix: Permission System
- **Root cause:** `hasPermission()` checked ALL roles on the server instead of user's assigned roles
- **Fix:** Moved `hasPermission` to shared export in `src/lib/types.ts`
- Now checks `user.memberRoleIds[server.id]` to only evaluate the user's assigned roles
- Falls back to channel `_default` permissions for users without specific roles
- Updated all files (ChatArea, ChannelSidebar, ServerSettings) to import the fixed shared function

### Fixed Edit/Delete/Pin Permissions
- Users can only edit/delete their **own** messages unless they have `edit_messages`/`delete_messages` role permission
- Pin requires `pin_messages` permission specifically
- All checks now pass the current `channel` context for channel-level override support

### Fixed Channel Permission Enforcement
- Channel-level permission overrides are checked first (role-specific → `_default`)
- Users with role-specific channel overrides don't fall through to server-level
- Users without roles get `_default` channel permissions as fallback

### SHIFT+ENTER for Newlines
- Replaced `<input>` with `<textarea>` — Enter sends, Shift+Enter adds newline
- Auto-resizes from 1 to ~5 lines with scrolling
- Already works with existing `<br>` in `parseMarkdown()`

### Default to Dialogue IM Server After Login
- Default view changed from `'dm'` to `'server'`
- Custom event `dialogue-login-navigate` dispatched after login/register
- AppContext navigates to the Dialogue IM server automatically

### Click Mutual Server on Profile
- Clicking a mutual server in UserProfileModal now navigates to that server and closes the modal

### Role Assignment UI
- New `RoleCard` component in ServerSettings with expandable member management
- Shows members with each role, allows adding/removing members
- Persists via `user.memberRoleIds` in Firestore

### Chat Commands
- `?kick [username] [reason]` — requires `kick_members` permission
- `?permban [username] [reason]` — requires `ban_members` permission
- `?timeout [username] [time] [reason]` — requires `kick_members` permission (time: 30s, 5m, 1h, 1d)
- System messages posted for actions, errors shown inline

### Fixed Emoji Reactions
- Emoji picker stays open when selecting (don't close after each selection)
- Only closes on X button or Escape
- Server emojis tab appears in both servers and DMs

### Max Server Members from Config
- CreateServerModal fetches `config/maxUsers` from Firestore for default maxMembers

### Timeout System
- Added `timeoutUntil` and `timeoutReason` to User type
- Timed-out users can't send messages in servers
- Timeout indicator shown in member list

---

## Task 2: Drag-and-Drop, Categories, and Discord-like Improvements

### Drag-and-Drop Channel Reordering
- Added `order` field to Channel interface
- Implemented HTML5 drag-and-drop in ChannelSidebar (no external library)
- Grip handle appears next to channels when user has `move_channels` permission
- Visual feedback: opacity-50 on drag, blue border on drop target
- On drop, updates `order` field in Firestore for all affected channels

### Custom Categories for Channels
- Added `Category` interface and `categoryId` to Channel, `categories` to Server
- In ServerSettings, "Categories" tab where admins can create/rename/delete/reorder categories
- In ChannelSidebar, channels grouped by category when custom categories exist
- Channels without a category go into "Uncategorized"
- Falls back to type-based grouping when no custom categories

### Drag-and-Drop Role Reordering
- Added drag handles next to each role in the Roles tab
- Uses HTML5 drag-and-drop
- Higher roles shown first take priority
- On reorder, saves updated roles array to Firestore immediately

### Max Server Members = Little_Timmy's Max Users
- CreateServerModal fetches from `config/maxUsers` on mount
- Admin can still override the default value

### Additional Discord-like Improvements
- "Create your first channel" prompt when server has no channels
- Channels management tab in ServerSettings (list, rename, delete channels)
- Channel type icon in ChatArea header
- Timeout indicator on timed-out users in MemberList
- "No Access" message when user can't read messages in a channel
- canReadMessages check hides message content and input

---

## Files Modified (All Tasks)
- `src/lib/types.ts` — Added Category, order, categoryId, timeoutUntil/timeoutReason, shared hasPermission
- `src/contexts/AuthContext.tsx` — Login navigation, timeout fields, Dialogue IM server updates
- `src/contexts/AppContext.tsx` — Default view to 'server', login navigate event listener
- `src/components/dialogue/ChatArea.tsx` — Permission fixes, textarea, chat commands, emoji fix, canReadMessages
- `src/components/dialogue/ChannelSidebar.tsx` — Permission fix, drag-and-drop channels, categories
- `src/components/dialogue/ServerSettings.tsx` — RoleCard with member assignment, drag-and-drop roles/categories, categories tab, channels tab
- `src/components/dialogue/UserProfileModal.tsx` — Mutual server click navigation
- `src/components/dialogue/CreateServerModal.tsx` — Config maxMembers fetch
- `src/components/dialogue/AdminPanel.tsx` — Fixed config document ID
- `src/components/dialogue/MemberList.tsx` — Timeout indicator
